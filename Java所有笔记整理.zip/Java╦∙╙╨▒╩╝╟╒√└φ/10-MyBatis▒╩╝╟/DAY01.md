### 1. MyBatis框架的作用

简化数据库编程。

使用MyBatis开发增删改查功能时，每个功能只需要写出抽象方法与对应的SQL语句即可！

### 2. 创建项目

创建**Maven Project**，创建过程中勾选**Create a simple project**，**Group Id**为`cn.tedu`，**Artifact Id**为`mybatis`，**Packaging**为`war`(不必选择`war`，也可以是`jar`)。

创建成功后，生成**web.xml**，在项目属性中勾选Tomcat，从前序项目中复制Spring的配置文件到当前项目中，从前序项目中复制**web.xml**中关于`DispatcherServlet`和`CharacterEncodingFilter`的配置到当前项目中，从前序项目的**pom.xml**文件中复制依赖到当前项目中。

在使用MyBatis框架时，需要先添加`mybatis`的依赖：

	<!-- MyBatis框架的依赖 -->
	<!-- 可选版本：3.5.0~3.5.3 -->
	<dependency>
		<groupId>org.mybatis</groupId>
		<artifactId>mybatis</artifactId>
		<version>3.5.3</version>
	</dependency>

MyBatis框架本身可以直接单独使用，但是配置比较麻烦，整合Spring后可以简化许多，所以，还应该添加MyBatis整合Spring框架的`mybatis-spring`的依赖：

	<!-- MyBaits整合Spring的依赖 -->
	<!-- 可选版本：2.0.0~2.0.3 -->
	<dependency>
		<groupId>org.mybatis</groupId>
		<artifactId>mybatis-spring</artifactId>
		<version>2.0.3</version>
	</dependency>

由于底层实现依然使用了JDBC技术，需要添加`spring-jdbc`的依赖，添加的这个依赖的版本必须与正在使用的`spring-webmvc`的一致（也可以理解为：同一个项目中，添加的所有以`spring-`为前缀的依赖必须是完全相同的版本）！

结合数据库编程，原理上还是得先连接到数据库，所以，需要添加`commons-dbcp`数据库连接池的依赖：

	<!-- 数据库连接池 -->
	<dependency>
		<groupId>commons-dbcp</groupId>
		<artifactId>commons-dbcp</artifactId>
		<version>1.4</version>
	</dependency>

由于使用的是MySQL数据库，还需要添加数据库连接的依赖`mysql-connector-java`：

	<!-- 数据库连接驱动 -->
	<!-- 可选版本：5.1.40~5.1.48 -->
	<!-- 可选版本：8.0.11~8.0.18 -->
	<dependency>
		<groupId>mysql</groupId>
		<artifactId>mysql-connector-java</artifactId>
		<version>8.0.18</version>
	</dependency>

最后，为了检测编程效果，还应该保证已经添加了单元测试`junit`的依赖：

	<dependency>
		<groupId>junit</groupId>
		<artifactId>junit</artifactId>
		<version>4.12</version>
	</dependency>

### 3. 连接数据库

首先，在**src/main/resources**下创建**db.properties**配置文件，在该文件中配置连接数据库的相关信息：

	url=jdbc:mysql://localhost:3306/tedu_ums?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Chongqing
	driver=com.mysql.cj.jdbc.Driver
	username=root
	password=root
	initialSize=2
	maxActive=5

将原有的**spring-mvc.xml**复制，粘贴得到**spring-dao.xml**，并删除原有的配置，然后在**spring-dao.xml**添加本次所需的配置！

先读取以上**db.properties**文件：

	<!-- 读取db.properties中的配置 -->
	<util:properties 
		location="classpath:db.properties"></util:properties>

然后，配置`BasicDataSource`（注意：是`commons-dbcp`中的类，不是Tomcat中的类）：

	<!-- 配置数据源BasicDataSource -->	
	<bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource">
		<property name="url" value="#{config.url}" />
		<property name="driverClassName" value="#{config.driver}" />
		<property name="username" value="#{config.username}" />
		<property name="password" value="#{config.password}" />
		<property name="initialSize" value="#{config.initialSize}" />
		<property name="maxActive" value="#{config.maxActive}" />
	</bean>

最后，编写并执行单元测试：

	public class Tests {
	
		BasicDataSource ds;
		ClassPathXmlApplicationContext ac;
		
		@Before
		public void doBefore() {
			ac = new ClassPathXmlApplicationContext(
				"spring-dao.xml");
		}
		
		@Test
		public void getConnection() throws SQLException {
			ds = ac.getBean("dataSource", BasicDataSource.class);
			Connection conn = ds.getConnection();
			System.out.println(conn);
		}
		
		@After
		public void doAfter() {
			ac.close();
		}
		
	}

### 4. 编写抽象方法

目标：向`t_user`数据表中插入1条用户数据。

MyBatis要求抽象方法必须定义在接口中！则需要先创建`cn.tedu.mybatis.UserMapper`接口：

	public interface UserMapper {
	}

然后，在接口中添加抽象方法，关于抽象方法的声明原则：

1. 如果将要执行的SQL语句是增、删、改类型的，则使用`Integer`作为返回值类型，表示“受影响的行数”，也可以使用`void`作为返回值类型，表示“不关心操作结果”；如果将要执行的SQL语句是查询类型的，返回值的类型可以按需设计；

2. 方法的名称可以自定义；

3. 参数列表可以按需设计。

以增加用户数据为例，需要执行的SQL语句大致是：

	insert into t_user (username, password, age, phone, email) values (?, ?, ?, ?, ?);

则关于“增加用户数据”的抽象方法可以设计为：

	Integer addnew(String username, String password, Integer age, String phone, String email);

当然，也可以将这些参数封装在一个`User`类中：

	public class User {
		// ...
	}

然后，将抽象方法改为：

	Integer addnew(User user);

接下来，还需要在**spring-dao.xml**中补充关于`MapperScannerConfigurer`配置，使得框架知道接口文件在哪里：

	<!-- 配置接口文件的位置 -->
	<bean class="org.mybatis.spring.mapper.MapperScannerConfigurer">
		<property name="basePackage"
			value="cn.tedu.mybatis" />
	</bean>

注意：如果没有正确的配置接口文件的位置，后续，尝试获取对象时，将出现错误，无法获取对象！

### 5. 配置SQL语句

下载`http://doc.tedu.cn/config/mybatis-mapper.zip`，解压得到**SomeMapper.xml**文件，重命名为**UserMapper.xml**。

在项目的**src/main/resources**下新建**mappers**文件夹，并将**UserMapper.xml**复制到这个文件夹下！

这个**UserMapper.xml**就是用于配置SQL语句的文件！

这种配置SQL语句的XML文件的根节点是`<mapper>`，需要在根节点配置`namespace`属性，取值为之对应的接口的全名：

	<mapper namespace="cn.tedu.mybatis.UserMapper">
	
	</mapper>

接下来，根据需要执行的SQL语句的种类，从`<insert>`、`<delete>`、`<update>`、`<select>`中选择对应的子节点，节点的`id`属性就是对应的抽象方法的名称，然后在节点内部配置SQL语句：

	<mapper namespace="cn.tedu.mybatis.UserMapper">
	
		<insert id="addnew">
			INSERT INTO t_user (
				username, password,
				age, phone,
				email
			) VALUES (
				#{username}, #{password},
				#{age}, #{phone},
				#{email}
			)
		</insert>
	
	</mapper>

注意：如果配置的是`<select>`节点，必须在该节点配置`resultType`或`resultMap`属性！

最后，还需要配置`SqlSessionFactoryBean`，以指定XML文件的位置，及框架在执行时将使用的数据源：

	<!-- 配置XML文件的位置和数据源 -->
	<bean class="org.mybatis.spring.SqlSessionFactoryBean">
		<property name="mapperLocations"
			value="classpath:mappers/*.xml" />
		<property name="dataSource"
			ref="dataSource" />
	</bean>

全部完成后，编写并执行单元测试：

	@Test
	public void addnew() {
		User user = new User();
		user.setUsername("spring");
		user.setPassword("123456");
		user.setAge(19);
		user.setPhone("13800138002");
		user.setEmail("spring@163.com");
		Integer rows = userMapper.addnew(user);
		System.out.println("rows=" + rows);
	}

### 6. 插入数据时获取自增的id

在配置`<insert>`时，添加配置`useGeneratedKeys="true"`和`keyProperty="属性名"`即可，例如：

	<insert id="addnew"
		useGeneratedKeys="true"
		keyProperty="id">
		INSERT INTO t_user (
			username, password,
			age, phone,
			email
		) VALUES (
			#{username}, #{password},
			#{age}, #{phone},
			#{email}
		)
	</insert>

注意：以上`keyProperty`属性的值表示“得到了自增的id后封装到哪个属性中”，以上的取值`id`表示“放到`User`类的`id`属性中”。

### 7. 关于#{}内的名称

当抽象方法的参数是一个对象，并且，在SQL语句需要使用对象中的属性时，`#{}`中写的是属性名，例如：

	<insert id="addnew"
		useGeneratedKeys="true"
		keyProperty="id">
		INSERT INTO t_user (
			username, password,
			age, phone,
			email
		) VALUES (
			#{username}, #{password},
			#{age}, #{phone},
			#{email}
		)
	</insert>

以上`#{username}`就是抽象方法的参数`User`类型的对象中的`username`属性的值！

如果抽象方法的参数只有1个，且这个参数直接作为SQL语句中的参数值，则`#{}`里可以随便写！