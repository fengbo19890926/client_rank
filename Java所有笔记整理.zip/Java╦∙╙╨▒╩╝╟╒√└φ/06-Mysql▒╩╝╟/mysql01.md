###数据库
- 以前通过IO技术对数据进行增删改查,相当于自己写的数据库软件,只不过功能和性能非常低,如果说每次开发一个新的项目都写一遍数据增删改查相关的代码,开发效率低并且不能保证性能问题,数据库软件就是用于解决此问题.
- DBMS: DataBase(数据库) Management(管理) System(系统) 俗称数据库软件, 常见的DBMS有:
	1. MySQL: Oracle公司产品, 08年被Sun公司收购,09年Sun公司被Oracle收购, 开源产品,   原MySQL团队从Oracle离职创建MariaDB , 市场占有率第一.
	2. Oracle:闭源产品,Oracle公司产品,拉里.埃里森 32岁创业. 市场占有率第二. 性能最高 价格最贵
	3. SQLServer: 微软公司产品,闭源,市场占有率第三,主要应用在微软整套解决方案中.
	4. DB2: IBM公司产品, 闭源产品, 应用在IBM公司的整套解决方案中 
	5. SQLite: 轻量级数据库,主要应用在移动设备(手机)和嵌入式设备中(各种智能设备) 安装包只有几十k

	开发网站需要用到哪些东西:  开发语言+Web服务软件+操作系统+数据库软件
- 开源和闭源:
	1. 开源: 开放源代码, 盈利方式: 靠卖服务, 开源产品有技术大拿无偿升级维护.
	2. 闭源: 不开放源代码, 盈利方式: 靠卖产品+卖服务, 有技术大拿攻击,但是会养一帮人维护升级.
###SQL 
- Structured结构化 Query查询 Language语言, 负责程序员和数据库软件之间的沟通.  
###如何连接数据库软件
- Linux: 桌面空白右键打开终端
	mysql -uroot -p   回车   输入密码   回车   
- Windows: 开始菜单->所有程序->MySQL->MySQL Client
	
- 退出: exit;

###DDL 数据定义语言
- 数据库软件中保存数据需要先建库再建表.
####数据库相关SQL
1. 查询所有数据库
- 格式: show databases;
2. 创建数据库
- 格式: create database 数据库名 character set utf8/gbk;
	create database db1 character set utf8;
3. 查询数据库详情
- 格式: show create database 数据库名;
	show create database db1;
4. 删除数据库  
- 格式: drop database 数据库名;
	drop database db2;
5. 使用数据库
- 格式: use 数据库名;
	use db1;
###数据库相关练习
	1. 分别创建mydb1和mydb2  第一个是gbk  第二个是utf8
		create database mydb1 character set gbk;
		create database mydb2 character set utf8;
	2. 创建完查询所有数据库 检查是否存在
		show databases;
	3. 分别查询每个数据库的字符集是否正确
		show create database mydb1;
		show create database mydb2;
	4. 先使用mydb1再使用mydb2
		use mydb1;
		use mydb2;
	5. 删除两个数据库 
		drop database mydb1;
		drop database mydb2;
####表相关
- 操作表相关的SQL 必须使用了某个数据库,不然提示以下错误
	No database selected
1. 查询所有表
- 格式: show tables;
2. 创建表 
- 格式: create table 表名(字段1名 类型,字段2名 类型......) charset=gbk/utf8;
		create table person(name varchar(10),age int)charset=utf8;
		show tables; 检查是否出现了person表
- 创建学生表student 字段姓名 年龄 语文chinese 数学math  英语english  字符集gbk
	    create table student(name varchar(10),age int,chinese int,math int,english int)charset=gbk;
2. 查看表详情
- 格式: show create table 表名;
		show create table person;
3. 查看表字段
- 格式: desc 表名;
		desc student;
4. 删除表
- 格式: drop table 表名;
		drop table student;
5. 添加表字段
- 最后添加格式: alter table 表名 add 字段名 字段类型;
- 最前面添加格式: alter table 表名 add 字段名 字段类型 first;
- 在xxx字段的后面: alter table 表名 add 字段名 字段类型 after xxx;
	alter table person add gender varchar(10);
	alter table person add id int first;
	alter table person add salary int after name;
6. 修改表名
- 格式: rename table 原名 to 新名;
	rename table person to persons;
7. 删除表字段
- 格式: alter table 表名 drop 字段名;
	alter table persons drop gender;
8. 修改表字段
- 格式: alter table 表名 change 原名 新名 新类型;
	alter table persons change salary gender varchar(10);
####数据库和表相关练习：
1. 创建数据库mydb1 字符集为utf8  并使用该数据库	
	create database mydb1 character set utf8;
	use mydb1;
2. 在mydb1中创建员工表emp 字段有name 字符集为utf8	 
	create table emp(name varchar(10))charset=utf8;
3. 添加表字段age在最后面
	alter table emp add age int;
4. 添加id字段在最前面
	alter table emp add id int first;
5. 添加sal字段在name的后面
	alter table emp add sal int after name;
6. 修改字段sal为salary
	alter table emp change sal salary int;
7. 删除age字段  
	alter table emp drop age;
8. 删除emp表 
	drop table emp;
9. 删除数据库 
	drop database mydb1;
###DML  数据操作语言 
create database mydb1 character set utf8;
use mydb1;
create table person(id int,name varchar(10),age int)charset=utf8;

1. 插入数据
- 全表插入格式:insert into 表名 values(值1,值2,值3....);
	要求值得数量和顺序必须和表字段一致
	insert into person values(1,'Tom',18);

- 指定字段格式:insert into 表名(字段1,字段2) values(值1,值2);
	要求值得数量和顺序和前面指定的一样
	insert into person(id,name) values(2,'Jerry');
- 批量插入:
	insert into person values(10,'aaa',18),(11,'bbb',19),(12,'ccc',20);
	insert into person(name) values('xxx'),('yyy'),('zzz');
- 中文问题: 
	insert into person values(20,'刘德华',55);
	如果执行报错: set names gbk;
2. 查询数据
- 格式: select 字段信息 from 表名 where 条件;
	select name from person;   
	select name,age from person where id<10;
	select * from person;
3. 修改数据
- 格式: update 表名 set xxx=xxx,xxx=xxx where 条件;
	update person set age=30 where name='Jerry';
	update person set id=13 where name='xxx';
4. 删除数据
- 格式: delete from 表名 where 条件;
	delete from person where name='Tom';
	删除年龄大于20岁的
	delete from person where age>20;
####练习：
1. 创建英雄hero表 id  名字name  类型type  价格money  字符集为utf8
	create table hero(id int,name varchar(10),type varchar(10),money int)charset=utf8;
2. 保存以下数据:
	insert into hero values
	 (1, '诸葛亮', '法师', 18888) ,(2, '周瑜' ,'法师', 13888), 
	 (3, '孙悟空', '打野', 18888) ,(4, '小乔', '法师', 13888), 
	 (5, '黄忠', '射手', 8888),    (6, '刘备', '战士', 6888);
3. 修改所有18888为28888
	update hero set money=28888 where money=18888;
4. 修改所有法师为战士
	update hero set type='战士' where type='法师';
5. 删除价格为6888的英雄 
	delete from hero where money=6888;
6. 修改小乔为猪八戒  
	update hero set name='猪八戒' where name='小乔';
7. 删除价格低于15000的英雄
	delete from hero where money<15000;
8. 添加性别gender字段在name的后面 
	alter table hero add gender varchar(10) after name;
9. 修改所有英雄的性别为男  
	update hero set gender='男';
10. 删除所有数据   
	delete from hero;
11. 删除表 
	drop table hero;

###数据类型
1. 整数:  int 和 bigint(等效Java中的long)
2. 浮点数: double(m,d) m代表总长度 d代表小数长度   23.567  m=5 d=3	超高精度的浮点数decimal(m,d), 只有涉及到超高精度运算时使用
3. 字符串
- char(m):  固定长度, m=10  "abc"  占10, 执行效率较高 ,最大长度255
- varchar(m): 可变长度,m=10 "abc"  占3,更节省资源 ,最大长度65535但是超过255建议使用text
- text(m):  可变长度  最大65535.
4. 日期
- date: 只能保存年月日
- time: 只能保存时分秒
- datetime: 默认值为null,最大值:9999-12-31
- timestamp(时间戳):默认值为当前系统时间,最大值2038-1-19  
	create table t_date(t1 date,t2 time,t3 datetime,t4 timestamp);
	insert into t_date values("2019-12-12",null,null,null);
	insert into t_date values
	(null,"17:37:30","2019-12-12 17:37:30",null);

