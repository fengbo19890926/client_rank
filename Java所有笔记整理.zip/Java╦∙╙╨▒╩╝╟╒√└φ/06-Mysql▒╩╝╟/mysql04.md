###数据库连接池DBCP
- DBCP:DataBase Connection Pool 
- 使用数据库连接池可以大大降低web服务器和数据库服务器之间的连接次数从而提高执行效率
- 如何使用:
	1. 在pom文件中添加相关jar包坐标



###实现登录功能
create table user(id int primary key auto_increment,username varchar(15),password varchar(15));

insert into user values(null,'libai','admin'),(null,'lisi',123456);

- 登录SQL: 
	select count(*) from user where username='libai' and password='admin';
	select count(*) from user 
	where username='sdfsdf' and password='' or '1'='1'
- SQL注入:在写值的位置写进去了SQL语句导致原有逻辑发生改变
- 使用预编译的SQL执行对象解决SQL注入问题.
	创建SQL执行对象时逻辑就已经锁死,替换?的值时逻辑不会被改变 从而避免了SQL注入问题,
- 登录功能实现步骤:
1. 创建Demo044.java  添加main方法,通过Scanner获取用户输入的username和password
2. 通过模板代表获取连接对象
3. 创建查询的SQL语句,里面的变量用?表示
4. 通过已经创建好的SQL语句创建预编译的SQL执行对象
5. 将用户输入的用户名和密码替换掉SQL中的?
6. 执行SQL语句得到resultset对象
7. while循环遍历resultset对象
8. 获取查询到的数量 如果大于0输出登录成功 否则输出登录失败. 

###批量操作
- 将多条SQL语句的多次数据传输合并成一次数据传输,从而提高执行效率
- 代码参考Demo5和Demo06
###获取自增主键值 代码参考Demo08

###元数据
- 数据库元数据
- 表元数据


###代码介绍
1. Demo01  作业
2. Demo02  读取properties配置文件
3. Demo03  数据库连接池 
4. Demo04  登录 SQL注入   接触了预编译SQL执行对象 
5. Demo05  Statement的批量操作
6. Demo06  PreparedStatement的批量操作
7. Demo07  分页查询练习
8. Demo08  获取自增主键值  
9. Demo09  获取元数据 
 
