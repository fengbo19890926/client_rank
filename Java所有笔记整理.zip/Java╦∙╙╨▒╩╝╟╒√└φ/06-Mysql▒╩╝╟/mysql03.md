###课程回顾
1. 主键约束  primary key
	主键: 表示数据唯一性的字段
	约束: 给表字段添加的限制条件
	唯一且非空
2. 自增 auto_increment   ,规则: 历史最大值+1   只增不减
3. 导入 *.sql文件     source 路径;
4. is null 和 is not null 
5. 比较运算符 > < >= <= = !=和<>
6. and 和 or
7. not between x and y  在x和y之间 
8. not in(x,y,z) 
9. 模糊查询  like     %代表0或多个未知字符   _代表1个未知字符
10. 排序   order by 字段名 asc/desc,字段名;
11. 分页查询 limit 跳过的条数和请求的条数
12. 运算符 + - * / %
13. 聚合函数   平均值avg()  最大值max()  最小值min() 求和sum() 计数count()
14. 分组查询  group by 字段名
15. having 写聚合函数的条件
16. 各个关键字顺序   select .... from 表名 where ..... group by....having..... order by.... limit;


###综合练习
1. 查询没有上级领导的员工编号empno，姓名，工资
	select empno,ename,sal from emp where mgr is null;
2. 查询有奖金的员工姓名和奖金
	select ename,comm from emp where comm>0;
3. 查询名字中包含精的员工姓名和工资
	select ename,sal from emp where ename like '%精%';
4. 查询名字中第二个字是八的员工信息
	select * from emp where ename like '_八%';
5. 查询1号部门工资大于2000的员工信息
	select * from emp where deptno=1 and sal>2000;
6. 查询2号部门或者工资低于1500的员工信息
	select * from emp where deptno=2 or sal<1500;

7. 查询工资为3000，1500，5000的员工信息按照工资升序排序
	select * from emp where sal in(3000,1500,5000) order by sal;
8. 查询3号部门的工资总和
	select sum(sal) from emp where deptno=3;
9. 查询每个部门工资大于1000的员工人数，按照人数升序排序
	select deptno,count(*) c from emp 
	where sal>1000 group by deptno order by c;
10. 查询每种工作中有领导的员工人数按照人数降序排序
	select job,count(*) c from emp 
	where mgr is not null group by job order by c desc;
11. 查询所有员工信息，按照部门编号升序排序，如果部门编号一致则工资降序
	select * from emp order by deptno,sal desc;
12. 查询有领导的员工，每个部门的编号和最高工资
	select deptno,max(sal) from emp 
	where mgr is not null group by deptno;
13. 查询有领导的员工，按照工资升序排序，第3页的2条数据
	select * from emp 
	where mgr is not null order by sal limit 4,2;
14. 查询每个部门的工资总和，只查询有上级领导的员工并且要求工资总和大于5400，最后按照工资总和降序排序,只查询结果中的第一条数据
	select deptno,sum(sal) s from emp where mgr is not null group by deptno having s>5400 order by s desc limit 0,1;
###子查询(嵌套查询)
1. 查询工资高于1号部门平均工资的员工信息
	select avg(sal) from emp where deptno=1;
	select * from emp where sal>(select avg(sal) from emp where deptno=1);
2. 查询工资最高的员工信息
	select max(sal) from emp;
	select * from emp where sal=(select max(sal) from emp);
3. 查询工资高于2号部门最低工资的员工信息
	select min(sal) from emp where deptno=2;
	select * from emp where sal>(select min(sal) from emp where deptno=2);
4. 查询和孙悟空相同工作的其它员工信息
	select job from emp where ename='孙悟空';
	select * from emp where job=(select job from emp where ename='孙悟空') and ename!='孙悟空';
5. 查询白骨精的部门信息(需要用到部门表) 
	select deptno from emp where ename='白骨精';
	select * from dept where deptno=(select deptno from emp where ename='白骨精');
6. 查询所有员工的部门信息(想办法过滤掉4号部门 因为4号部门没员工)
	select distinct deptno from emp;
	select * from dept where deptno in(select distinct deptno from emp);
###关联关系
- 创建表时,表与表之间存在的业务关系
- 有哪些关系?
1. 1对1:有AB两张表,A表中1条数据对应B表中1条,同时B表1条也对应A表中1条.
2. 1对多:有AB两张表,A表中1条数据对应B表中多条,同时B表1条对应A表中1条
3. 多对多:有AB两张表,A表中1条数据对应B表中多条,同时B表1条对应A表中多条. 
###关联查询
- 同时查询多张表的数据的查询方式称为关联查询

- 关联查询必须写关联关系,如果不写则会得到两种表数据的乘积, 这个乘积被称为笛卡尔积, 这是一个错误的查询结果,在工作中要避免出现.
- 关联查询的方式有三种
####等值连接
- 格式: select 字段信息 from A,B where 关联关系 and 其它条件

1. 查询每个员工的姓名和对应的部门名 
	select e.ename,d.dname
	from emp e,dept d
	where e.deptno=d.deptno;
2. 查询1号部门的员工姓名,工资,部门名,部门地址
	select e.ename,e.sal,d.dname,d.loc
	from emp e,dept d
	where e.deptno=d.deptno and d.deptno=1;
####内连接(建议使用) 
- 格式: select 字段信息 from A join B on 关联关系 where 条件
1. 查询每个员工的姓名和对应的部门名 
	select e.ename,d.dname
	from emp e join dept d
	on e.deptno=d.deptno;
2. 查询1号部门的员工姓名,工资,部门名,部门地址
	select e.ename,e.sal,d.dname,d.loc
	from emp e join dept d
	on e.deptno=d.deptno where e.deptno=1;
###外连接
- 查询一张表的全部数据和另外一张表的交集数据
- 格式: select 字段信息 from A left/right join B on 关联关系 where 条件
1. 查询所有部门的名称和对应的员工名
	select d.dname,e.ename
	from emp e right join dept d
	on e.deptno=d.deptno;
2. 查询所有员工姓名和对应的部门信息 
	insert into emp (empno,ename) values(100,'灭霸');
	
	select e.ename,d.*
	from emp e left join dept d
	on e.deptno=d.deptno;

####关联查询总结
- 三种查询方式: 等值连接,内连接,外连接
- 如果需要查询两张表的交集数据使用等值连接和内连接(推荐)
- 如果查询一张表的全部和另外一张表的交集则使用外连接

###JDBC
- Java DataBase Connectivity: Java数据库连接, JDBC是Sun公司提供用于Java和数据连接的编程接口. 
###如何使用JDBC
1. 创建maven工程
2. 在pom.xml文件中添加以下代码
	
	  <dependencies>
	  	<dependency>
	  		<groupId>mysql</groupId>
	  		<artifactId>mysql-connector-java</artifactId>
	  		<version>5.1.6</version>
	  	</dependency>
	  </dependencies>
3. 创建Demo01 书写以下代码

		//1. 注册驱动
		//Class.forName("com.mysql.jdbc.Driver");
		//2. 获取连接对象 
		//导包时选择java.sql
		Connection conn = 
				DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/newdb3",
				"root", "root");
		System.out.println(conn);
		//3. 创建SQL执行对象
		Statement s = conn.createStatement();
		//4. 执行SQL
		String sql = 
				"create table jdbct1"
				+ "(id int,name varchar(10))";
		s.execute(sql);
		System.out.println("执行完成!");
		//5. 释放资源
		conn.close();
####SQL执行对象 Statement
- execute(sql)  此方法可以执行任意的SQL语句,但是建议执行DDL包括create,drop,alter等
- executeUpdate(sql) 此方法用于执行增删改的SQL语句
- executeQuery(sql) 此方法用于执行查询的SQL






	