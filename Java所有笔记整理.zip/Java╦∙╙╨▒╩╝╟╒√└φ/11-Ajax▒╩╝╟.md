### 1. 服务器端向客户端的响应方式

服务器端的控制器处理完请求后，可以使用转发或重定向的方式向客户端进行响应！在当下主流的开发模式中，已经不推荐使用这些响应方式了，因为无论是转发，还是重定向，最终，都会给客户端某个页面，但是，现在客户端的种类比较多，不同种类的客户端有不同的硬件特性，例如手机、智能音箱、智能手表等设备就存在“屏幕小”的特点，所以，如果这些设备也向服务器端发出请求，而服务器端也响应整个页面给这些设备，就是非常不合适的！

目前，推荐的做法是：**服务器端只向客户端响应操作结果及相关的数据**！例如用户登录时，服务器端只向客户端响应1个`1`表示成功，或响应1个`2`表示用户名错误，或响应1个`3`表示密码错误，至于页面的处理，交给客户端技术去完成！

这是一种“前后端分离”的做法！其中，前端指的就是客户端，后端指的就是服务器端！使用这种做法，更加明确了各种不同技术方向的开发人员的工作职责！

使用这种响应的做法，传输的数据量会更少，还可以减少流量的消耗，传输耗时更短，用户体验更好！

### 2. 服务器端向客户端响应正文

在SpringMVC框架中，在处理请求的方法之前，添加`@ResponseBody`注解，就表示**响应正文**，则处理请求的方法的返回值就不再表示转发或重定向，而是表示**响应给客户端的结果**！

例如：

	@Controller
	public class UserController {
	
		@RequestMapping("login.do")
		@ResponseBody
		public String login(String username, String password) {
			// 假设root/1234是正确的用户名/密码
			if ("root".equals(username)) {
				if ("1234".equals(password)) {
					return "1"; // 1-用户名密码均正确
				} else {
					return "3"; // 3-密码错
				}
			} else {
				return "2"; // 2-用户名错
			}
		}
		
	}

测试：将项目部署到Tomcat中，然后，打开浏览器，输入`http://localhost:8080/ajax/login.do?username=root&password=1234`

注意：默认情况下，响应正文时，响应头(Response Headers)中会设置`Content-Type`值为`text/html; charset=ISO-8859-1`，所以，是不可以正常使用中文等非ASCII码字符的！

### 3. 响应的数据的格式

响应正文时，不能只是单纯的把某个数字或者数据直接响应给客户端！例如，需要向客户端响应某个用户的信息时，用户信息中包含用户名、密码、年龄、手机号码、电子邮箱，如果只是单纯的把这些数据给到客户端，可能是：

	root12342513800138000root@163.com

服务器端的返回结果就只是1个数据而已，如果需要使用1个数据来表示多项数据含义，这些数据项必须有规则的区分开来，否则，即使客户端收到了整个数据，也无法从中获取到所需的每一项！

例如，可以使用XML语法组织以上数据：

	<user>
		<username>root</username>
		<password>1234</password>
		<age>25</age>
		<phone>13800138000</phone>
		<email>root@163.com</email>
	</user>

把以上XML源代码作为1个字符串响应给客户端，然后，客户端收到这段XML语法组织的内容后，就可以使用XML解析技术，从中获取所需的每项数据！

目前，常见的组织数据的方式并不是XML，而是使用JSON数据格式，以上数据如果使用JSON语法来组织，会是：

	{
		"username":"root",
		"password":"1234",
		"age":25,
		"phone":"13800138000",
		"email":"root@163.com"
	}

### 4. JSON数据格式

> JSON(JavaScript Object Notation, JS对象简谱)是一种轻量级的数据交换格式。它基于ECMAScript(欧洲计算机协会制定的js规范)的一个子集，采用完全独立于编程语言的文本格式来存储和表示数据。简洁和清晰的层次结构使得JSON成为理想的数据交换语言。易于人阅读和编写，同时也易于机器解析和生成，并有效地提升网络传输效率。

JSON格式组织的数据，相比XML语法组织的数据而言：

1. 简单，易懂；

2. 占用字节数更少(数据体积更小)；

3. 解析技术简单； 

关于JSON的语法格式：

1. 整个数据是一个JSON对象，JSON对象是使用一对大括号`{}`框住的；

2. JSON对象中可以配置若干条属性与对应的值，各属性与值的数据项之间使用逗号`,`进行分隔；

3. 每个属性与值之间使用冒号`:`进行分隔；

4. 所有的属性名都是字符串，应该使用引号框住，在JavaScript中，使用一对双引号`""`或一对单引号`''`都可以；

5. 属性值如果是数值型，或布尔类型的，则值并不需要使用引号框住，如果属性值是字符串类型的，也需要使用引号框住；

6. 属性值的类型还可以是数组类型的，整个值使用中括号`[]`框住即可，后续在JavaScript中处理数据时，还可以通过该数据的`length`属性获取数组的长度，甚至结合循环语法进行遍历；

7. 属性值的类型还可以是另一个JSON对象，依然使用一对大括号`{}`表示对象；

8. 属性的值的类型可以灵活组织，例如某个属性的值是数组，而数组的元素的类型又是一个JSON对象，而这些JSON对象中的属性里还可以有数组，数组中还可以有对象……

所以，某个JSON数据可以是：

	let json = {
		'username':"root",
		"password":"1234",
		'age':25,
		"phone":"13800138000",
		"email":"root@163.com",
		"skills":["Java", "SQL", "JavaScript"],
		"department": {
			"id":6,
			"name":"软件研发部"
		}
	};
	
	console.log(json.username);
	console.log(json.skills);
	console.log(json.skills.length);
	for (let i = 0; i < json.skills.length; i++) {
		console.log(json.skills[i]);
	}
	console.log(json.department.id);
	console.log(json.department.name);

### 5. 服务器端向客户端响应JSON格式的数据

首先，需要在**pom.xml**中添加新的依赖：

	<!-- Jackson：服务器端向客户端响应JSON数据的依赖 -->
	<!-- 备选版本：2.9.3~2.9.10 -->
	<dependency>
		<groupId>com.fasterxml.jackson.core</groupId>
		<artifactId>jackson-databind</artifactId>
		<version>2.9.7</version>
	</dependency>

然后，在服务器端，定义一个用于封装返回结果的类：

	public class JsonResult {
		private Integer result;
		private String username;
		// SET/GET
	}

并且，将这个类作为处理请求的方法的返回值类型！例如：

	@RequestMapping("login.do")
	@ResponseBody
	public JsonResult login(String username, String password) {
		// 假设root/1234是正确的用户名/密码
		JsonResult jsonResult = new JsonResult();
		if ("root".equals(username)) {
			if ("1234".equals(password)) {
				jsonResult.setResult(1); // 1-用户名密码均正确
				jsonResult.setUsername(username);
			} else {
				jsonResult.setResult(3); // 3-密码错
			}
		} else {
			jsonResult.setResult(2); // 2-用户名错
		}
		return jsonResult;
	}

另外，还需要在Spring的配置文件中开启注解驱动：

	<!-- 注解驱动 -->
	<mvc:annotation-driven />

完成后，即可访问服务器，响应结果就是JSON格式的数据！

当处理请求的方法添加了`@ResponseBody`注解后，表示**响应正文**，SpringMVC框架在处理时，会使用某种转换器(Converter)，转换器的作用就是将方法的返回值转换为响应给客户端的结果，SpringMVC框架本身有多种转换器，返回值不同，使用的转换器也不同，例如返回值类型是`String`时，使用的是`StringHttpMessageConverter`转换器，如果是其它已知类型，也有对应的转换器，如果返回值类型是SpringMVC框架默认并不识别的，就会使用Jackson框架中的转换器，而Jackson框架中的转换器的工作方式就是将响应结果转换为JSON格式的字符串！

从编程的角度出发，需要做的事情就是：**添加Jackson依赖，在Spring的配置文件中添加注解驱动，创建一个自定义的数据类型，将需要响应的属性声明在这个类中，最后，在处理请求的方法之前添加`@ResponseBody`，并使用自定义的数据类型作为方法的返回值类型！**

另外，Jackson框架还会将响应头(Response Headers)中的`Content-Type`设置为`application/json; charset=utf-8`，所以，是可以正常使用各种字符的！

### 6. AJAX

> Ajax即“Asynchronous Javascript And XML”（异步JavaScript和XML），是指一种创建交互式网页应用的网页开发技术。

> Ajax = 异步JavaScript和XML或者是HTML（标准通用标记语言的子集）。

> Ajax是一种用于创建快速动态网页的技术。

> Ajax是一种在无需重新加载整个网页的情况下，能够更新部分网页的技术。

> 通过在后台与服务器进行少量数据交换，Ajax可以使网页实现异步更新。
 
> 传统的网页（不使用Ajax）如果需要更新内容，必须重载整个网页页面。

为了避免出现兼容问题，通常，会使用jQuery中的`$.ajax()`函数来提交请求并处理结果，所以，首先需要在项目中添加jQuery的文件，并在HTML页面中引用jQuery文件：

	<script type="text/javascript" src="jquery-3.4.1.min.js"></script>

然后，在处理按钮的点击时，调用`$.ajax()`函数进行处理：

	function login() {
		console.log("准备提交登录……");
		// $.ajax()函数就是发出AJAX请求并处理响应结果的函数
		// $.ajax()函数的参数是一个JSON对象
		// 参数JSON对象需要配置至少5个属性：
		// url：将请求提交到哪里去
		// data：需要提交给服务器的请求参数
		// type：请求方式的类型
		// dataType：服务器端响应的数据类型，取值可以是text/xml/json，取决于服务器响应时响应头(Response Header)中的Content-Type值
		// success：服务器端成功响应时(HTTP响应码是200)的回调(callback)函数，函数的参数就是服务器端响应的结果
		$.ajax({
			"url":"login.do",
			"data":$("#form-login").serialize(),
			"type":"post",
			"dataType":"json",
			"success":function(json) {
				if (json.result == 1) {
					alert("登录成功！");
				} else if (json.result == 2) {
					alert(json.message);
					$("#username").val("");
				} else if (json.result == 3) {
					alert(json.message);
					$("#password").val("");
				}
			}
		});
	}