###英雄表增删查功能练习
drop table hero;
create table hero(id int primary key auto_increment,name varchar(20),type varchar(10),money int)charset=utf8;


cn.tedu.controller 存放所有的servlet
cn.tedu.dao  存放所有的dao
cn.tedu.utils 存放所有的工具类
cn.tedu.entity  存放所有的实体类


##### 实现添加英雄步骤:
1. 创建add.html页面  准备表单 往AddHeroServlet发请求 里面有三个文本框和提交按钮
2. 在controller包创建AddHeroServlet  留下doGet方法 方法中获取三个传递过来的参数
3. 在entity包下面创建Hero实体类 里面有 id name type money 四个属性,提供set/get方法 构造方法  toString方法
4. 在dao包创建HeroDao,里面提供insert方法参数为Hero 在方法里面获取数据库连接创建SQL语句 把传递过来Hero对象中的数据保存到hero表中 
5. 在AddHeroServlet中把获取到的三个信息封装到Hero对象中,创建HeroDao并且调用insert方法把Hero传递进去 
##### 实现查询功能步骤:
1. 创建一个home.html页面 里面添加一个超链接   英雄列表 连接地址为:ListServlet
2. 创建ListServlet 留下doGet方法,在方法中创建HeroDao 调用dao里面的findAll方法 返回值为List集合里面装Hero对象, 此时没有findAll方法 让Eclipse自动生成findAll方法
3. 在findAll方法中创建ArrayList 返回值改成创建的ArrayList对象,创建完集合后获取连接,然后写查询代码 参考上午EmpDao中的findAll方法
4. 在ListServlet里面得到返回的集合后遍历集合同时给页面返回一个表格,代码参考上午工程中的ListServlet
##### 实现删除功能步骤:
1. 在ListServlet中添加一个操作的表头然后在每一行里面的最后添加一个td里面显示删除 href 值为    DeleteServlet?id=    id值为hero.getId()
2. controller包中创建DeleteServlet 留下doGet方法 在方法里面获取传递过来的id,创建HeroDao 调用dao里面的deleteById的方法 把id传递过去
3. 生成dao里面的deleteById的方法 在方法里面获取连接 准备删除的sql语句,删除传递过来id对应的数据代码参考上午EmpDao里面的删除方法
4. 在DeleteServlet里面调用完dao的方法后,重定向到ListServlet



###乱码问题
1. 中文出现??? 检查jdbc.properties 中的url后面需要添加
?useUnicode=true&characterEncoding=UTF-8
2. 中文时乱码 在中断里面  执行 set names gbk;



###作业:
1. 创建明星表
create table star(id int,name varchar(10),age int,type varchar(10))charset=utf8;
2. 创建朋友表
create table friends(id int,name varchar(10),age int,job varchar(10))charset=utf8;
3. 创建学生表
create table students(id int,name varchar(10),chinese int,math int,english int)charset=utf8;
4. 创建电影movie表 字段:id,名字name,导演actor,主演star
5. 创建水果fruit表 字段:id,名字name,价格price
6. 创建商品item表:id,商品标题title,价格price,库存num
7. 创建部门dept表:id,name,loc,人数count
8. 创建老师teacher表:id,name,age,体重weight
9. 创建蔬菜vegetables表:id,name,price,类型type
10. 创建游戏game表:id,name,年代year