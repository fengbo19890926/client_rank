###网络架构CS和BS
- CS: Client Server客户端服务器,客户端指:PC客户端 手机客户端 
	优点: 执行效率略高,有丰富的展示效果 
- BS: Browser Server浏览器服务器
	优点: 节省设备内存,跨平台,版本更新便利
###什么是服务器
- 服务器就是一台高性能的电脑
- web服务器:在高性能电脑上安装了提供web服务的软件
- 邮件服务器:在高性能电脑上安装了提供邮件收发服务的软件
- 数据库服务器:在高性能电脑上安装了提供数据服务的软件(MySQL/Oracle..)
- ftp服务器:在高性能电脑上安装了提供文件上传下载服务的软件
###Web服务软件做了什么事儿?
- 负责建立底层的网络连接,负责将客户端请求的文件返回给客户端
- 负责根据请求的路径找到对应的Servlet(负责扩展web服务软件功能的组件)
- web服务软件也称为web容器,用于装各种Servlet
###如何使用Tomcat
- 以后开发web工程需要在Project Explorer视图下,如果没有从window->show view->other中搜索
- 将Tomcat和Eclipse进行关联
	1. 下载Tomcat安装包和源代码   doc.tedu.cn
	2. 将下载的两个压缩包放到d:java文件夹下(linux系统放到/home/java/) 解压在当前文件夹
	3. 配置Eclipse:
		eclipse->window->prefrences->server->runtime Enviroments->清空里面的内容->add->找到Tomcat 7.0->Browse找到java文件夹下apache-tomcat-7.0.96 完成即可!
	4. 在servers窗口中点击超链接 添加Tomcat7.0  选中7.0直接ok即可
	5. 添加完之后双击添加的Tomcat7.0 修改单选为中间的一个 保存关闭
	6. 在Tomcat7.0上右键 Start 启动服务器
	7. 地址栏中访问 localhost:8080   
		如果能看见一只猫则说明成功!
- 删除Tomcat
	1. 在servers中 Tomcat 7.0 上右键 Delete
	2. eclipse->window->prefrences->server->runtime Enviroments->清空里面的内容
	3. 把java文件夹中的apache-tomcat-7.0.96文件夹删除 重新解压一份

###Servlet
- Servlet是用于扩展Tomcat业务功能的组件规范,Servlet用于处理用户发过来各种请求,每一种请求都需要对应一个单独的Servlet.

###如何创建web工程
1. 创建maven工程 把jar改war
2. 解决错: 在工程中文件名最长的上面右键点击最长的(实际上是添加了web.xml配置文件)
3. 让工程和Tomcat关联,在工程上右键最后一个 选择Targeted runtimes 勾选Tomcat7.0 关闭
4. 在Java Resources里面src/main/java上面右键新建一个Servlet 名字为HelloServlet
5. 在工程上右键Run as-> Run on Servler
6. 在浏览器中访问以下路径
localhost:8080/servlet_1_1/HelloServlet

###Servlet响应流程
1. 请求从客户端浏览器发出 
2. 请求被Tomcat拦截到, 得到请求的子路径去web.xml中找到对应的Servlet完整类名
3. 得到类名后通过反射技术将该Servlet实例化
4. 实例化后调用对象中的service方法

###浏览器发出请求的方式:
1. 浏览器地址栏中写请求路径 回车后发出请求    get
2. 在页面中通过超链接发出请求     get
3. 在页面中通过表单发出请求    默认get     get/post
###请求方式
1. get:请求参数在请求地址的后面
2. post:请求参数在请求体里面
###get请求参数中出现中文解决方案

- 找到Servers工程中的server.xml文件 找到65行 添加以下内容
	 <Connector URIEncoding="UTF-8" 
- Tomcat版本8.0及以上版本不存在此问题

###BMI体脂率
- 体重/身高的平方
- 小于18.5 偏瘦
- 18.5到24 正常
- 24到28   超重
- 大于28   肥胖 


