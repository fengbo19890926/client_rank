###求和练习步骤
1. 在webapp下创建add.html页面
2. 在页面中添加表单 提交地址为AddServlet   里面两个输入框和提交按钮
3. 创建AddServlet 删除里面无用代码, 重写service方法
4. 删除service方法里面的代码,获取传递过来的两个参数
5. 将得到的两个字符串参数转成int类型 并进行加法运算 得到结果
6. 把得到的结果返回给浏览器
###请求方式get和post



###实现注册和登录功能

use newdb3;
delete from user;
//如果没有user表的创建一个
create table user(id int primary key auto_increment,username varchar(15),password varchar(15))charset=utf-8;
- 注册实现步骤:
	1. 创建reg.html页面 



###工程中需要使用数据库必做的几件事
1. 把数据库相关的jar包坐标复制到工程中
2. 把DBUtils赋值到工程中
3. 把jdbc.properties配置文件复制到工程中
4. 当工程改成1.7时 会报错,但是此错误不影响执行 如何解决:
	工程名上右键->Properties->Project Facets->Java 把1.5改成1.7


###创建一个操作数据库的web工程步骤:
1. 创建maven工程 jar改war
2. 改错  最长上面右键最长
3. 工程和Tomcat关联  
4. 把数据库相关的jar包坐标添加到新工程
5. 把DBUtils类复制到新工程
6. 把jdbc.properties配置文件复制到新工程
7. 把工程改成1.7时 需要手动把Java1.5改成1.7
	工程名上右键->Properties->Project Facets->Java 把1.5改成1.7

###登录功能步骤
1. 创建login.html页面 页面中添加form表单 表单提交地址LoginServlet 其它内容和注册的一样
2. 创建LoginServlet,留下doPost方法
3. 在doPost方法中获取传递过来的用户名和密码 并在控制台输出 此时重启工程运行 测试是否接收到了参数
4. 获取到参数后获取数据库连接,模板代码中创建登录的SQL语句,登录的SQL参考jdbc02工程中的Demo04.java
5. 在判断登录成功的位置给浏览器输出 登录成功  登录失败的位置输出 用户名或密码错误!

###DAO
- Data Access Object 数据访问对象


###添加员工工程步骤:
1. 创建maven工程 把jar改war
2. 改错: 最长上面最长
3. 把Tomcat和工程关联
4. 把上个工程中的jar包坐标复制到自己工程的pom.xml中
5. 把DBUtils复制到自己工程中
6. 把jdbc.properties 赋值到自己工程中
7. 创建add.html页面 准备表单 里面三个文本输入框和一个提交按钮,提交地址为AddEmpServlet
8. 创建AddEmpServlet 获取传递过来的三个参数 并在控制台输出,运行测试
9. 创建Emp实体类  里面有empno,ename,sal三个属性 添加set/get方法和构造方法
10. 创建EmpDao类,添加insert方法,参数为Emp对象,在方法里面获取连接并且把emp对象里面的三个数据 保存到emp表中 
11. 在AddEmpServlet中先把得到的三个参数封装到Emp对象中,然后创建EmpDao 并且调用empDao里面的insert方法,把封装好的emp对象传递过去.





