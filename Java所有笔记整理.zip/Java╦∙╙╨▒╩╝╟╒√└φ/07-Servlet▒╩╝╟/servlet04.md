###Thymeleaf
- Thymeleaf是一个目前比较流行的框架之一,功能是将html页面作为一个模板,并根据页面中的特殊标记,对页面中的内容进行修改或替换.
###如何使用Thymeleaf
1. 添加相关的jar包坐标




###博客项目步骤:
1. 下载blog.zip解压  
- 把blog.sql导入    
	windows:  source 路径;  source d:/blog.sql;
	linux:  source /home/soft01/桌面/blog.sql;
	执行 select * from article; 如果出现乱码执行 set names gbk;
2. 创建新工程名字Blog ,jar改war, 改错,关联Tomcat,jar包坐标,创建四个包分别为cn.tedu.controller/entity/dao/utils
3. 复制servlet_4_1里面的两个工具类 DBUtils和ThUtils到工程中,复制jdbc.properties到新工程中 修改url中的newdb3为smartblogs

4. 把第一步解压出来的bootstrap/css/images三个文件夹复制到新工程的webapp目录下, 把blog文件夹复制到src/main/resources目录下和jdbc.properties在同一目录
5. 创建HomeServlet 添加以下代码
		//显示首页页面
		Context context = new Context();
		ThUtils.write("blog/index", context, response);
6. 去掉index.html页面中的所有../   通过快捷键ctrl+f   
	为什么需要去掉../ 因为显示页面的方式发生了改变,以前是直接访问页面文件 相对路径相对于的是文件所在位置,而显示页面是通过Servlet中转显示的 相对路径相对的是Servlet所在位置,而Servlet所在位置是工程的根目录http://localhost:8080/TBlog/ 此时如果还有../会把工程名称弄掉导致找不到资源文件.

