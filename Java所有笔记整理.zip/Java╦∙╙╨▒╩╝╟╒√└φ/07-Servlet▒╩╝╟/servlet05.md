###查询首页8篇文章的SQL
select a.oId,a.title,a.abstract,a.commentCount,a.viewCount,
a.content,a.putTop,a.created,a.imgName,u.userName
from article a join user u
on a.authorId=u.oId
order by a.putTop desc,a.created desc
limit 0,8;
###通过文章id查询标签信息
select t.oId,t.referenceCount,t.title
from tag t join tag_article ta
on t.oId=ta.tag_oId
where ta.article_oId=10;

###实现友情连接步骤：
1. 创建Link实体(title,address)  
2. 创建LinkDao 提供findAll方法返回集合
3. 在当前位置创建dao 并获取集合 
4. 把集合传递到页面中，在页面中控制显示
