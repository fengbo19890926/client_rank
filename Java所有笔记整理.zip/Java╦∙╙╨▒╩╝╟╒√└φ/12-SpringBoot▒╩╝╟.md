### 1. SpringBoot框架

SpringBoot是一个默认就集成了大量的常规依赖，并完成了大量的常规配置的SpringMVC框架！

SpringBoot的核心思想有“约定大于配置”，所以，在学习使用SpringBoot时，需要了解它默认完成的配置是怎样的！

### 2. 创建SpringBoot项目

创建SpringBoot项目可以基于SpringBoot父级项目来创建，也可以通过开发工具(例如Intellij IDEA)来创建，或者，通过SpringBoot网站创建并下载项目，最后在开发工具中导入。

如果通过网站来创建，则应该打开`https://start.spring.io`

下载得到项目的压缩包后，解压得到项目文件夹，先将该文件夹剪切到Workspace中(为了便于后续管理代码)，然后通过Eclipse的**Import**的**Existing Maven Projects**来导入项目，默认导入的项目结构并不完整，需要保证当前电脑能够连接到Maven服务器，然后Eclipse会自动下载该项目所需的依赖的jar包，如果没有开始下载，则可以对项目点右键，选择**Maven** > **Update Project**强制更新项目，更新完成后，项目结构就是完整的了！

注意：建议使用4.10或以上版本的Eclipse，如果使用的Eclipse版本较低，则内置的Maven环境版本也较低，会在**pom.xml**中提示错误！但是，该错误并不影响开发和运行项目，只要更新了Eclipse就能解决！

### 3. 启动SpringBoot项目

在项目中，默认就已经存在例如`cn.tedu.sample`包，这个包的名字是创建项目时填写的**Group**和**Artifact**决定的，并且，这个包就是项目组件扫描的包！所以，后续创建的组件类(需要被Spring创建并管理对象的类，例如控制器类)都必须放在这个包或其子包下！

在以上包中，默认就存在`SampleApplication`类，这个类的名字也是由创建项目时填写的**Artifact**决定的，如果创建项目时**Artifact**填写的是`demo`，则该类的名字就会是`DemoApplication`！这个类是整个项目的启动类，当需要将项目部署到Tomcat运行时，直接启动这个类的`main()`方法即可，SpringBoot项目是内置Tomcat的，所以会自动将项目部署到内置的Tomcat并启动Tomcat！

由于SpringBoot项目启动时会启动Tomcat，所以，务必要保证端口没有被占用，并且，已经启动项目的情况下，不要反复启动，否则会导致端口被占用的错误，后续的启动都会失败！

### 4. 在项目中添加静态页面

在SpringBoot项目的**src/main/resources**下，默认就存在**static**文件夹，该文件夹就是用于存放静态资源的，例如html文件、css文件、js文件、图片文件等需要能够被HTTP协议直接访问的文件(在浏览器中输入网址就可以访问的文件)！

所以，可以在**static**下创建**index.html**(页面内容随意设计)，然后，启动整个项目(执行启动类中的`main()`方法)，打开浏览器，输入`http://localhost:8080/`即可访问到该页面！

由于**index.html**是默认的页面，所以，访问这个页面时，不需要在URL中显式的体现文件名！

SpringBoot启动Tomcat时，可以看到`Tomcat started on port(s): 8080 (http) with context path ''`，也就是SpringBoot项目部署到Tomcat时，使用的`Context Path`是空字符串，所以，在URL中并不需要加上项目名称！

在**src/main/resources**下的**application.properties**文件是整个项目的配置文件，可以在该文件中配置所使用的端口号，例如：

	server.port=80

注意：如果使用Linux / MacOS时，这些操作系统对80端口是敏感的，需要开放权限后才可以使用！

### 5. 使用控制器接收客户端的请求

由于SpringBoot项目默认已经将`cn.tedu.sample`(根据创建项目时填写的**Group**和**Artifact**决定的包名)设置为了组件扫描的根包，所以，控制器类必须放在这个包或其子包中！

在`cn.tedu.sample.controller`包(自行创建出子级包)下创建`HelloController`类，在类之前添加`@Controller`注解，并在类中添加处理请求的方法，处理后将响应正文，所以，在方法还需要添加`@ResponseBody`注解：

	@Controller
	public class HelloController {
	
		@ResponseBody
		@RequestMapping("hello")
		public String hello() {
			return "Hello, SpringBoot!";
		}
		
	}

完成后，重新启动项目，在浏览器中输入`http://localhost:8080/hello`即可访问！

在SpringBoot项目中，默认已经将`DispatcherServlet`映射的路径配置为`/*`，所以，在设计请求路径时，不需要使用`.do`作为后缀！同时，也意味着所有请求都会被框架所处理！

在SpringBoot项目中，还可以使用`@RestController`取代`@Controller`，这个新的注解表示当前控制器类中所有处理请求的方法都将**响应正文**，所以，每个处理请求的方法之前就不需要添加`@ResponseBody`注解了，也会响应正文！如果某些请求的处理最终需要转发或重定向，则不应该使用`@RestController`，或者，使用`@RestController`同时，使用`ModelAndView`作为处理请求的方法的返回值类型！

> 这里使用的`@RestController`注解并不是SpringBoot框架添加的新注解，而是SpringMVC框架中就已经有的注解，但是，在SpringMVC框架中如果要使用这个注解，必须额外配置，默认是不识别的！

SpringBoot框架默认已经将所有能设置的编码都设置成了`UTF-8`，所以，一般不需要考虑编码的问题，除非自行添加了其它依赖！

在SpringBoot框架中，在配置请求路径时，还可以使用`@GetMapping`，它相当于`@RequestMapping(method=RequestMethod.GET)`，即**将请求类型限制为GET类型**！与之类似的还有`@PostMapping`等！这些注解也是SpringMVC中就已经有的注解，同样，也是需要额外配置才可以使用的注解！

如果希望控制器最终能响应JSON格式的数据，应该先创建封装响应结果的类：

	public class JsonResult {

		private Integer state;
		private String message;
	
		// GET/SET
	
	}

然后，使用以上类型作为处理请求的方法的返回值类型：

	@GetMapping("hello")
	public JsonResult hello() {
		JsonResult jsonResult = new JsonResult();
		jsonResult.setState(1);
		jsonResult.setMessage("欢迎使用SpringBoot！！！");
		return jsonResult;
	}

### 6. 结合MyBatis实现数据库编程--连接数据库

默认情况下，SpringBoot项目并没有集成数据库相关依赖，必须先在**pom.xml**的`<dependencies>`节点之下添加数据库编程所需的依赖：

	<dependency>
		<groupId>org.mybatis.spring.boot</groupId>
		<artifactId>mybatis-spring-boot-starter</artifactId>
		<version>2.1.1</version>
	</dependency>

	<dependency>
		<groupId>mysql</groupId>
		<artifactId>mysql-connector-java</artifactId>
		<scope>runtime</scope>
	</dependency>

> 由于SpringBoot框架会自动管理相关依赖的jar包的版本，所以，添加`mysql-connector-java`时，不需要指定版本号，默认会使用较高的且稳定的版本，如果该版本不可用，也可以自行添加`<version>`节点来配置所需的版本！

当添加以上依赖后，如果直接启动项目，会报错，因为SpringBoot框架会自动读取连接数据库的配置信息，如果没有配置信息，就会出错！所以，需要在**application.properties**中添加配置信息：

	# spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
	spring.datasource.url=jdbc:mysql://localhost:3306/tedu_ums?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai
	spring.datasource.username=root
	spring.datasource.password=root

接下来，应该检查以上配置信息是否正确(无论以上配置值是否正确，只要配置了值，并且值的格式无误，就可以成功启动项目)！

在SpringBoot项目中，在**src/test/java**下默认也有`cn.tedu.sample`包，并在该包中还有一个测试类，代码如下：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class SampleApplicationTests {
	
		@Test
		public void contextLoads() {
		}
	
	}

首先，应该将以上方法体中无代码的`contextLoads()`方法执行单元测试！该测试应该是可以通过的，如果报错，一定是相关依赖的jar包文件损坏了，则需要重新jar包！

注意：SpringBoot的测试类也是必须放在**src/test/java**的`cn.tedu.sample`包或子包中的！否则将无法正常执行！并且，每个测试类之前都需要添加相应的注解！

SpringBoot的单元测试，在执行时，会加载整个项目的环境，例如加载Spring容器、读取**application.properties**中的配置等！

接下来，直接在现有的单元测试类中添加测试数据库连接的测试方法：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class SampleApplicationTests {
	
		@Test
		public void contextLoads() {
		}
		
		@Autowired
		private DataSource dataSource;
		
		@Test
		public void getConnection() throws SQLException {
			Connection conn = dataSource.getConnection();
			System.err.println(conn);
		}
	
	}
	
注意：由于SpringBoot项目执行单元测试时，会加载Spring环境，所以，在传统的SpringMVC项目中可以`getBean()`获取的对象，在SpringBoot的单元测试中，都可以通过自动装配来注入值！

### 7. 结合MyBatis实现数据库编程--实现用户注册

首先，应该先创建`cn.tedu.sample.entity.User`类：

	public class User {
	
		private Integer id;
		private String username;
		private String password;
		private Integer age;
		private String phone;
		private String email;
	
		// SET/GET
	
	}

再创建`cn.tedu.sample.mapper.UserMapper`接口，并在接口中添加“用户注册”的抽象方法：

	Integer addnew(User user);

然后，需要使得MyBatis框架知道接口文件的位置，可以选择在接口的声明之前添加`@Mapper`注解：

	@Mapper
	public interface UserMapper {
	
		Integer addnew(User user);
		
	}

然后，需要配置抽象方法对应的SQL语句！可以在抽象方法之前添加`@Insert`或相应的`@Delete`等注解来配置SQL语句，例如：

	@Mapper
	public interface UserMapper {
	
		@Insert("insert into t_user ("
				+ "username,password,age"
				+ ") values ("
				+ "#{username}, #{password}, #{age}"
				+ ")")
		Integer addnew(User user);
		
	}

最后，编写并执行单元测试：

	@Autowired
	UserMapper userMapper;
	
	@Test
	public void addnew() {
		User user = new User();
		user.setUsername("springboot");
		user.setPassword("888888");
		Integer rows = userMapper.addnew(user);
		System.err.println("rows=" + rows);
	}

由于需要配置接口文件的位置，所以，在接口的声明之前添加了`@Mapper`注解，但是，使用这种做法的话，在同一个项目中，如果创建更多的接口，则每个接口之前都需要添加该注解，也可以选择在启动类的声明之前添加`@MapperScan`注解，用于配置接口文件的位置，则每个接口之前就不必添加`@Mapper`注解了，例如：

	@SpringBootApplication
	@MapperScan("cn.tedu.sample.mapper")
	public class SampleApplication {
	
		public static void main(String[] args) {
			SpringApplication.run(SampleApplication.class, args);
		}
	
	}

以上`@MapperScan`中配置的就是接口文件所在的包！

另外，虽然可以使用`@Insert`等注解来配置SQL语句，但是，并不推荐这样处理，因为存在问题：可能需要使用较多注解，较长的SQL语句不易于阅读，所以，并不推荐使用注解来配置！

> 使用注解配置SQL语句并不是SpringBoot特有的做法，而是MyBatis框架本身就支持这么做，只不过，需要额外添加配置！

所以，在配置SQL语句，仍应该使用XML文件进行配置！则先在**src/main/resources**下创建**mappers**文件夹用于存放相关的XML文件，然后，复制得到**UserMapper.xml**文件，并在这个文件是配置对应的接口与抽象方法映射的SQL语句：

	<?xml version="1.0" encoding="UTF-8" ?>  
	<!DOCTYPE mapper PUBLIC "-//ibatis.apache.org//DTD Mapper 3.0//EN"      
	 "http://ibatis.apache.org/dtd/ibatis-3-mapper.dtd">
	
	<mapper namespace="cn.tedu.sample.mapper.UserMapper">
	
		<insert id="addnew"
			useGeneratedKeys="true"
			keyProperty="id">
			INSERT INTO t_user (
				username, password,
				age, phone,
				email
			) VALUES (
				#{username}, #{password},
				#{age}, #{phone},
				#{email}
			)
		</insert>
	
	</mapper>

完成后，依然需要配置XML文件的位置，所以，需要在**application.properties**中进行配置：

	mybatis.mapper-locations=classpath:mappers/*.xml

由于在设计数据表时，为`username`字段添加了`unique`约束，所以，用户名是不可以重复的！如果尝试插入已经存在的用户名，就会出现`DuplicateKeyException`，可以在执行插入数据之前，先检查该用户名是否已经存在，如果不存在，则插入数据，如果已经存在，则不执行插入数据操作即可！则还应该开发“根据用户名查询用户数据”的功能，所以，在接口中添加抽象方法：

	User findByUsername(String username);

然后，配置该方法对应的SQL语句：

	<select id="findByUsername" 
		resultType="cn.tedu.sample.entity.User">
		SELECT * FROM t_user WHERE username=#{username}
	</select>

最后，也测试一下这个功能：

	@Test
	public void findByUsername() {
		String username = "mybatis";
		User user = userMapper.findByUsername(username);
		System.err.println(user);
	}
	
	@Test
	public void reg() {
		// 尝试注册的用户信息
		User user = new User();
		user.setUsername("newuser");
		user.setPassword("888888");
		user.setAge(28);
		user.setPhone("13900139008");
		user.setEmail("newuser@tedu.cn");
		// 检查用户名是否被注册
		User result = userMapper.findByUsername(user.getUsername());
		if (result == null) {
			// 查不到对应的用户数据，则未被注册，允许注册
			Integer rows = userMapper.addnew(user);
			System.err.println("rows=" + rows);
		} else {
			// 查到了对应的用户数据，则用户名已被占用，不执行注册，直接提示错误
			System.err.println("注册失败！用户名已经被占用！");
		}
	}

	