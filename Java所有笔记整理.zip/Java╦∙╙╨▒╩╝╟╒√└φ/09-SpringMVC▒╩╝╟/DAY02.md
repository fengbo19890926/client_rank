### 1. 关于@RequestMapping注解

在注解的源代码中有：

	RequestMethod[] method() default {};

以上`method`属性用于限制请求方式的！例如配置为：

	@RequestMapping(path="handle_login.do", method=RequestMethod.POST)

或配置为：

	@RequestMapping(path="handle_login.do", method= {RequestMethod.POST, RequestMethod.GET})

> 当在注解中配置多个属性时，每个属性的配置，都必须显式的定义属性名与属性值！

如果请求方式不匹配，则会出现405错误：

	HTTP Status 405 – Method Not Allowed

	Message : Request method 'GET' not supported

另外，该注解也可以添加在类的声明之前！例如配置为：

	@RequestMapping("user")
	@Controller
	public class UserController {
	
	}

则在`UserController`控制器类中配置的所有请求路径都需要添加`user`这一层路径，即原本`/reg.do`就要改为`/user/reg.do`……

通常，建议为每一个控制器类都配置该注解！

当类和方法之前都配置了该注解后，请求路径就是由类的配置值和方法的配置值共同拼接得到的！

### 2. 重定向

在处理请求的方法中，返回`redirect:路径`格式的字符串，表示“重定向”，例如：

	return "redirect:index.do";

重定向：当前处理完请求后，让客户端自动的继续向下一个路径再次发出请求！

### 3. 使用Session

在处理请求的方法的参数列表中，添加`HttpSession`类型的参数，即可使用Session！

### 4. 拦截器(Interceptor)

在SpringMVC框架中，拦截器(Interceptor)组件可以对若干种请求路径进行拦截，在处理拦截时，可以选择阻止继续执行，或选择放行！

使用拦截器时，首先，需要自定义类，实现`HandlerInterceptor`接口：

	public class LoginInterceptor implements HandlerInterceptor {
	
		public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
				throws Exception {
			System.out.println("LoginInterceptor.preHandle()");
			return false;
		}
	
		public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
				ModelAndView modelAndView) throws Exception {
			System.out.println("LoginInterceptor.postHandle()");
		}
	
		public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
				throws Exception {
			System.out.println("LoginInterceptor.afterCompletion()");
		}
	
	}

写好了拦截器类之后，还需要在Spring的配置文件中进行配置：

	<!-- 配置拦截器链 -->
	<mvc:interceptors>
		<!-- 配置第1个拦截器 -->
		<mvc:interceptor>
			<!-- 拦截路径 -->
			<mvc:mapping path="/main/index.do"/>
			<!-- 拦截器 -->
			<bean class="cn.tedu.spring.LoginInterceptor"></bean>
		</mvc:interceptor>
	</mvc:interceptors>

在拦截器中，只有`preHandle()`才是具有拦截效果的，该方法返回`true`表示“放行”，返回`false`表示“阻止”：

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		System.out.println("LoginInterceptor.preHandle()");
		
		// 判断用户是否登录
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
			response.sendRedirect(request.getContextPath() + "/user/login.do");
			return false;
		}
		
		return true; // true-放行; false-阻止
	}

关于拦截器的配置，如果需要拦截多个路径，则配置时，可以添加多个`<mvc:mapping />`节点进行配置：

	<mvc:mapping path="/main/index.do"/>
	<mvc:mapping path="/user/password.do"/>
	<mvc:mapping path="/blog/addnew.do"/>

甚至还可以使用星号`*`作为通配符：

	<mvc:mapping path="/blog/*"/>

则客户端的请求是`/blog/addnew.do`、`/blog/delete.do`、`/blog/edit.do`都会匹配上`/blog/*`！

需要注意的是：使用1个星号`*`时，只能通配一层路径下的资源，例如`/blog/*`可以通配以上列举的路径，但是，不可以匹配上`/blog/2019/list.do`，如果一定要通配多层路径，需要使用2个星号`**`，即配置为`/blog/**`，则可以匹配上`/blog/list.do`、`/blog/2019/list.do`、`/blog/2019/12/list.do`……

另外，还可以在`<mvc:mapping />`的下方，添加`<mvc:exclude-mapping />`配置例外，例如：

	<mvc:mapping path="/user/**" />
	<mvc:exclude-mapping path="/user/reg.do" />
	<mvc:exclude-mapping path="/user/login.do" />

则以上配置表示`/user/**`都将被拦截，但是，`/user/reg.do`和`/user/login.do`是例外，不会被拦截(拦截器不处理)！

可以把“拦截路径”理解为“黑名单”，而“例外路径”就是“白名单”。

### 5. 关于POST请求的乱码问题

在SpringMVC框架中，已经创建好了`CharacterEncodingFilter`字符编码过滤器类，只需要配置这个类，并指定所需要使用的编码即可，在**web.xml**中补充配置：

	<filter>
		<filter-name>CharacterEncodingFilter</filter-name>
		<filter-class>org.springframework.web.filter.CharacterEncodingFilter</filter-class>
		<init-param>
			<param-name>encoding</param-name>
			<param-value>utf-8</param-value>
		</init-param>
	</filter>
	
	<filter-mapping>
		<filter-name>CharacterEncodingFilter</filter-name>
		<url-pattern>/*</url-pattern>
	</filter-mapping>

### 6. SpringMVC小结

1. 认识SpringMVC框架的五大核心组件，理解SpringMVC框架的核心执行流程；

2. 了解SpringMVC框架的作用；

3. 认识SpringMVC框架的相关配置，包含在**web.xml**中关于`DispatcherServlet`的配置，在Spring的配置文件中关于组件扫描、视图解析器的配置；

4. 掌握使用控制器接收客户端提交的请求；

5. 掌握接收请求参数的做法(2种推荐的做法)；

6. 掌握封装转发的数据；

7. 掌握重定向的使用方式；

8. 掌握Session的使用，关于HttpSession的常用API有：`setAttribute` / `getAttribute` / `invalidate`；

9. 掌握拦截器的使用与配置；

10. 掌握`@RequestMapping`注解的使用。

### 7. 数据库练习

1. 创建`tedu_ums`数据库，并使用该数据库；

	CREATE DATABASE tedu_ums;

	USE tedu_ums;

2. 创建`t_user`数据表，在该表至少包含id、用户名(username)、密码(password)、年龄(age)、手机号码(phone)、邮箱(email)这6个字段，数据类型和约束可自行设计；

	CREATE TABLE t_user (
		id INT AUTO_INCREMENT COMMENT '用户id',
		username VARCHAR(20) NOT NULL UNIQUE COMMENT '用户名',
		password VARCHAR(20) NOT NULL COMMENT '密码',
		age INT COMMENT '年龄',
		phone VARCHAR(20) COMMENT '手机号码',
		email VARCHAR(50) COMMENT '电子邮箱',
		PRIMARY KEY (id)
	) DEFAULT CHARSET=UTF8MB4;

3. 向数据表中插入不少于10条记录；

4. 删除id=?的记录；

5. 一次性删除id=?、id=?、id=?的记录；

6. 将id=?的电子邮箱改为?；

7. 将所有用户的密码改为?；

8. 统计当前表中用户的数量；

9. 查询id=?的用户的信息；

10. 查询用户名=?的用户的信息；

11. 查询所有用户的信息；

12. 假设每个用户的年龄都不同，查询年龄最大的那1个用户的信息；


















### ---------------------------------------------------

### 附1：关于GET与POST请求方式的区别

使用GET方式提交请求时，请求参数会体现在URL中，所以，不适合用于提交敏感信息(涉及安全、隐私等)，同时，请求参数的长度还会受到限制，通常，限制值是由浏览器和服务器端的限制值共同决定的！

使用POST方式提交请求时，请求参数会被封装在请求体中，不会体现在URL中，由于不能被直接看到，所以，相对安全性较高，并且提交的请求参数的长度没有限制！

尽管POST方式优点较多，但是，GET方式也具有易于收藏、分享的优点是不可取代的！另外，GET请求的处理速度比POST请求更快！

### 附2：关于转发与重定向

无论是转发，还是重定向，都可以使得浏览器显示某个指定的页面。

转发时，客户端只发出过1次请求；重定向时，客户端会发出2次请求！

由于在转发时，服务器端的处理过程中可能涉及控制器和页面等多个组件，是在处理同一次请求时执行的，所以，这些组件之间可以传递、共享数据，具体表现为“控制器中的数据可以转发到页面中，由页面完成显示”；由于在重定向时，客户端发出了2次请求，在服务器端，处理第1次请求时产生的数据，无法直接在处理第2次请求时使用！

由于在转发时，客户端只发出了1次请求，所以，在客户端的浏览器的地址栏中，只会显示第1次请求的路径；由于在重定向时，客户端发出了2次请求，所以，在客户端的浏览器的地址栏中，显示的是最后一次请求的路径。

### 附3：关于拦截器(Interceptor)与过滤器(Filter)的区别

拦截器和过滤器都可以对若干种请求进行“拦截”或“过滤”，使得处理这些请求时都会执行相同的一段代码，并且，最终都可以选择“阻止”或“放行”，这类组件都可以形成“链”。

过滤器是Java EE中的组件，而拦截器是SpringMVC中的组件，所以，只要使用Java EE技术开发服务器端应用程序，无论是否使用框架技术，都可以使用过滤器，而只有使用了SpringMVC框架，才可以使用拦截器，并且，只要被SpringMVC框架处理的请求，才可能被拦截器处理。

过滤器的配置相对比较繁琐，拦截器的配置既有黑名单，又有白名单，也支持使用通配符，所以，配置非常灵活！

过滤器是执行在所有的`Servlet`组件之前的！而拦截器在处理1个请求时最多可能执行3次，其中，第1次是在`DispatcherServlet`之前、在`Controller`之前执行的！

### 附4：关于字符编码

计算机能够直接识别并处理的只有二进制，每一个二进制中的`0`或`1`占1个二进制位(bit)，每1个字节(byte)占8个二进制位。

由于1个字节只占8位，除去最高位作为符号位，实际可用位数只有7位，只能表示128种不同的组合！

在ASCII码中约定了1个字节能表示的二进制的序列与常用字符的对应关系，例如使用`110 0001`(97)对应`a`……

由于汉字的种类较多，使用1个字节只能表示128种，则需要更多的字节数才能表示汉字！在Java语言中，每个字符都是占2字节的，使用的是Unicode编码。

Unicode编码只能在内存中使用，如果数据需要传输，例如`1111 1010 1111 0101 1010 1110 1011 1100`在网络中传输，接收方就无法明确这到底4个英文，还是2个汉字，或是1个字母+1汉字+1字母，或2字母+1汉字，或1汉字+2字母。所以，为了解决传输过程中无法识别(正确的断开)的问题，就产生了UTF-8编码。

UTF-8其实是Unicode的传输编码。它使用了特定的二进制位表示特定的意义，如果某个字符是由2个字节所组成的，它的编码一定是：

	110 xxxxx	10 xxxxxx

如果某个字符是由3个字节组成的，它的编码一定是：

	1110 xxxx	10 xxxxxx	10 xxxxxx

如果某个字符是由4个字节组成的，它的编码一定是：

	11110 xxx	10 xxxxxx	10 xxxxxx	10 xxxxxx

