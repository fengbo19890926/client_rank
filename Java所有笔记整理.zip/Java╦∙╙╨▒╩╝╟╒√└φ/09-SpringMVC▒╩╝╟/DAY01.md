### 1. 课程安排

SpringMVC(2) + MyBatis(2) + AJAX(1) + SpringBoot(1) + Project(12+)

### 2. SpringMVC框架的作用

MVC = Model(数据模型) + View(视图) + Controller(控制器)

解决了V与C的交互问题,其中,V表示视图,即软件的界面,通常是在客户端运行和呈现的,而C表示控制器,在传统的Java EE体系中,表现为各个Servlet组件,是运行在服务器端的,所以,SpringMVC框架解决的问题也可以理解为"客户端与服务器端的交互问题,即客户端如何把请求提交给服务器,服务器如何接受客户端的请求,并响应结果".

SpringMVC与M(Model)完全没有关系.

### 3. SpringMVC框架的核心组件

- `DispatcherServlet`:前端控制器,用于接收所有请求,将请求分发给各个`Controller`组件,并组织整个处理流程;

- `HandlerMapping`:记录请求路径与处理请求的控制器的对应关系;

- `Controller`:具体处理请求的组件;

- `ModelAndView`:`Controller`组件处理完请求后的处理结果,包含`Model`(数据)和`View`(视图名称);

- `ViewResolver`:视图解析器,可以根据视图名称确定具体的视图组件.

![](01.png)

### 4. SpringMVC HelloWorld

#### 4.1. 案例目标

在浏览器中输入`http://localhost:8080/项目名称/hello.do`,可以使得服务器端的控制器运行,并显示页面.

#### 4.2. 创建项目

创建**Maven Project**,创建过程中,勾选**Create a simple project ...**,**Group Id**为`cn.tedu`,**Artifact Id**为`springmvc2`,**Packaging**选择`war`.

创建好的项目默认报错,需要先生成**web.xml**文件.

对项目点右键,设置属性,在**Targeted Runtimes**勾选Tomcat运行环境.

在**pom.xml**中添加`spring-webmvc`的依赖:

	<dependencies>
		<dependency>
			<groupId>org.springframework</groupId>
			<artifactId>spring-webmvc</artifactId>
			<version>4.3.24.RELEASE</version>
		</dependency>
	</dependencies>

> 如果当前版本不可用,或者下载的jar包损坏了,可以替换为`4.3.1`~`4.3.25`之间的任意版本,在学习时,只需要保证使用的是`4.2`或以上版本即可.

最后,从前序项目中复制Spring的配置文件到当前项目的**src/main/resources**下.

#### 4.3. 通过DispatcherServlet接收所有请求

在SpringMVC框架中，已经内置了`DispatcherServlet`，所以，无需开发这个类，只需要配置即可，所以，应该在**web.xml**中进行配置：

	<servlet>
		<servlet-name>SpringMVC</servlet-name>
		<servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
	</servlet>

	<servlet-mapping>
		<servlet-name>SpringMVC</servlet-name>
		<url-pattern>*.do</url-pattern>
	</servlet-mapping>
	
在`DispatcherServlet`的父类`FrameworkServlet`中定义了`contextConfigLocation`属性，该属性的值应该是Spring配置文件的位置，当指定了该属性值后，当创建`DispatcherServlet`时，就会加载Spring的配置文件！

所以，可以为`DispatcherServlet`配置初始化参数，以加载Spring的配置文件：

	<servlet>
		<servlet-name>SpringMVC</servlet-name>
		<servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
		<init-param>
			<param-name>contextConfigLocation</param-name>
			<param-value>classpath:spring-mvc.xml</param-value>
		</init-param>
	</servlet>

	<servlet-mapping>
		<servlet-name>SpringMVC</servlet-name>
		<url-pattern>*.do</url-pattern>
	</servlet-mapping>

最后，还可以将`DispatcherServlet`设置为**启动时即初始化**：

	<servlet>
		<servlet-name>SpringMVC</servlet-name>
		<servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
		<init-param>
			<param-name>contextConfigLocation</param-name>
			<param-value>classpath:spring-mvc.xml</param-value>
		</init-param>
		<load-on-startup>1</load-on-startup>
	</servlet>

	<servlet-mapping>
		<servlet-name>SpringMVC</servlet-name>
		<url-pattern>*.do</url-pattern>
	</servlet-mapping>

至此，关于`DispatcherServlet`的配置就已经完成！

后续，如果将项目部署到Tomcat，并启动Tomcat，由于配置了`<load-on-startup>1</load-on-startup>`，所以，在启动Tomcat时就会创建`DispatcherServlet`的对象，同时，由于配置了`<init-param>`，就会为`contextConfigLocation`属性赋值，该值的作用就是指定Spring配置文件的位置，所以，框架还会读取**spring-mvc.xml**文件！

基于以上特点，可以检测配置是否正确！首先，自定义某个类，例如创建`cn.tedu.spring`包，并在包中创建`Tests`类，在类的声明之前添加`@Component`注解，在类中自行编写无参数的构造方法：

	@Component
	public class Tests {
		
		public Tests() {
			System.out.println("创建了Tests类的对象！");
		}
	
	}

然后，在**spring-mvc.xml**中配置组件扫描，扫描`cn.tedu.spring`包：

	<context:component-scan base-package="cn.tedu.spring" />

最后，启动Tomcat，就会创建`DispatcherServlet`对象，进而读取**spring-mvc.xml**的配置，执行组件扫描，扫到`Tests`类时，由于该类添加了注解，就会调用无参数构造方法来创建对象，从而输出构造方法中的内容！简单的说，就是启动Tomcat时，就会输出构造方法中的内容！

#### 4.4. 开发控制器接收客户端提交的请求

通常，并不会配置`HandlerMapping`，而是通过`@RequestMapping`注解来配置请求路径与处理请求的方法的对应关系！

接下来，应该在组件扫描的`cn.tedu.spring`包下创建`HelloController`控制器类，并在类之前添加`@Controller`注解：

	@Controller
	public class HelloController {
	}

**注意：此次添加在类之前的注解必须是`@Controller`，不可以是`@Component`或其它注解！**

然后，在控制器类中添加处理请求的方法，关于方法的声明：

1. 应该使用`public`权限；

2. 暂时使用`String`作为返回值类型；

3. 方法的名称可以自定义；

4. 参数列表可以为空，或按需设计；

所以，在控制器类中添加处理请求的方法，并在方法之前添加`@RequestMapping`，以配置请求路径与处理请求的方法的对应关系：

	@RequestMapping("hello.do")
	public String showHello() {
		System.out.println("HelloController.showHello()");
		return null;
	}

完成后，重新部署项目，在浏览器中访问`http://localhost:8080/springmvc2/hello.do`，在浏览器中会显示404错误页面，但是，在Eclipse的控制台可以看到以上方法输出的内容，并且，在浏览器中刷新页面时，控制器中会多次出现输出语句。

#### 4.5. 显示页面

当控制器中处理请求的方法返回`String`时，默认情况下，就表示**视图名称**，所以，需要确定显示视图的方案，并选取匹配的视图解析器(`ViewResolver`)！

如果使用Thymeleaf，首先，需要在**pom.xml**中添加相关依赖：

	<dependency>
		<groupId>org.thymeleaf</groupId>
		<artifactId>thymeleaf-spring4</artifactId>
		<version>3.0.11.RELEASE</version>
	</dependency>

	<dependency>
		<groupId>org.thymeleaf</groupId>
		<artifactId>thymeleaf</artifactId>
		<version>3.0.11.RELEASE</version>
	</dependency>

> 备选版本：`3.0.7`~`3.0.11`。

当使用Thymeleaf时，需要使用`ThymeleafViewResolver`视图解析器，该视图解析器工作时，需要配置`SpringTemplateEngine`模版引擎，而该模版引擎工作时需要配置`ClassLoaderTemplateResolver`模版解析器！所以，需要在**spring-mvc.xml**中配置以上3个类：

	<bean id="templateResolver" 
		class="org.thymeleaf.templateresolver.ClassLoaderTemplateResolver">
		<property name="prefix" 
			value="/templates/" />
		<property name="suffix" 
			value=".html" />
		<property name="characterEncoding" 
			value="utf-8" />
		<property name="templateMode" 
			value="HTML" />
		<property name="cacheable" 
			value="false" />
	</bean>
	
	<bean id="templateEngine" 
		class="org.thymeleaf.spring4.SpringTemplateEngine">
		<property name="templateResolver" 
			ref="templateResolver" />
	</bean>
	
	<bean class="org.thymeleaf.spring4.view.ThymeleafViewResolver">
		<property name="templateEngine" 
			ref="templateEngine" />
		<property name="characterEncoding" 
			value="utf-8" />
	</bean>

当使用`ClassLoaderViewResolver`时，框架将项目的**src/main/resources/**作为存放HTML页面文件的根目录，然后通过“前缀 + 处理请求的方法的返回值 + 后缀”来确定具体的页面！

假设页面是**resources**文件夹下的**templates**文件夹下的**hello.html**，则关于前缀、方法的返回值、后缀的配置可以是：

	前缀						方法的返回值		后缀
	/templates/hello.html	""				""
	/templates/				hello.html
	/templates/				hello			.html

配置完成后，再次启动项目，在浏览器中访问`http://localhost:8080/springmvc2/hello.do`即可看到所创建的页面。

另外，还可以使用`ServletContextTemplateResolver`取代`ClassLoaderTemplateResolver`，两者的区别在于：`ServletContextTemplateResolver`默认在项目的**webapp**文件夹下查找视图文件，`ClassLoaderTemplateResolver`默认在项目的**src/main/resources**下查找视图文件。

然后，关于处理请求的方法的返回值，如果返回`null`，等同于返回与请求路径匹配的字符串，如果配置的请求路径是`hello.do`，则返回`null`等同于返回`"hello"`，但是，并不推荐返回`null`。

### 5. 获取请求参数

#### 5.1. 通过HttpServletRequest获取请求参数【不推荐】

可以在处理请求的方法的参数列表中添加`HttpServletRequest`类型的参数，然后，再调用该参数对象的`getParameter()`方法即可获取请求参数：

	@RequestMapping("handle_reg.do")
	public String handleReg(HttpServletRequest request) {
		System.out.println("UserController.handleReg()");
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String age = request.getParameter("age");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		
		System.out.println("\tusername=" + username);
		System.out.println("\tpassword=" + password);
		System.out.println("\tage=" + age);
		System.out.println("\tphone=" + phone);
		System.out.println("\temail=" + email);
		
		return null;
	}

通常，并不推荐使用这种做法，主要原因：

1. 获取参数的过程比较麻烦；

2. 需要自行考虑数据类型的问题，并自行转换数据类型；

3. 不便于执行单元测试；

4. `HttpServletRequest`是一种重量级的数据类型。

#### 5.2. 将请求参数声明为处理请求的方法的参数【推荐】

将客户端提交的请求参数一一声明为彼得请求的方法的参数，甚至可以将这些参数声明为所期望的数据类型：

	@RequestMapping("handle_reg.do")
	public String handleReg(String username, String password, 
			Integer age, String phone, String email) {
		System.out.println("UserController.handleReg()");
		
		System.out.println("\tusername=" + username);
		System.out.println("\tpassword=" + password);
		System.out.println("\tage=" + age);
		System.out.println("\tphone=" + phone);
		System.out.println("\temail=" + email);
		
		return null;
	}

使用这种做法时，默认情况下，需要保证请求参数的名称与处理请求的方法的参数名称是一致的！否则，参数值将是`null`。

这种做法的缺陷在于：不适用于请求参数过多的应用场景！

#### 5.3. 使用封装的数据类型接收多个请求参数【推荐】

可以将各请求参数封装到自定义的数据类型中：

	public class User {
		
		private String username;
		private String password;
		private Integer age;
		private String phone;
		private String email;

		// 保留无参数构造方法
		// 添加SET/GET方法
	
	}

然后，将自定义的数据类型作为处理请求的方法的参数即可：

	@RequestMapping("handle_reg.do")
	public String handleReg(User user) {
		System.out.println("UserController.handleReg()");
		
		System.out.println(user);
		
		return null;
	}

使用这种做法，必须保证封装的`User`类中存在无参数构造方法，并且，各属性有规范的SET/GET方法！

#### 5.4. 小结

始终不推荐使用第1种做法(使用`HttpServletRequest`)！

当请求参数的数量较少且固定时，优先使用第2种做法(逐一添加请求参数作为处理请求的方法参数)；

当请求参数的数量较多或可能变化时，优先使用第3种做法(封装)！

以上第2种做法和第3种做法可以同时使用！

### 6. 转发：在页面中显示数据

#### 6.1. 使用HttpServletRequest封装转发的数据【不推荐】

在处理请求的方法的参数列表中添加`HttpServletRequest`类型的参数，当需要转发数据时，调用参数对象的`setAttribute()`方法封装数据即可：

	@RequestMapping("handle_login.do")
	public String handleLogin(String username, String password,
			HttpServletRequest request) {
		System.out.println("UserController.handleLogin()");
		
		System.out.println("\tusername=" + username);
		System.out.println("\tpassword=" + password);
		
		// 假设root/1234是正确的用户名/密码
		// 判断用户名
		if ("root".equals(username)) {
			// 用户名正确，需要判断密码
			if ("1234".equals(password)) {
				// 密码也正确，登录成功
			} else {
				// 密码错误
				request.setAttribute("errorMessage", "登录失败！密码错误！");
				return "error";
			}
		} else {
			// 用户名错误
			request.setAttribute("errorMessage", "登录失败！用户名不存在！");
			return "error";
		}
		
		return null;
	}

后续，在页面中，通过Thymeleaf表达式即可显示数据，例如：

	<h3 th:text="${errorMessage}">xxxxxxxxxxxx</h3>

#### 6.2. 使用ModelMap封装转发的数据【推荐】

使用方式可以完全参数使用`HttpServletRequest`的做法！

	@RequestMapping("handle_login.do")
	public String handleLogin(String username, String password,
			ModelMap modelMap) {
		System.out.println("UserController.handleLogin()");
		
		System.out.println("\tusername=" + username);
		System.out.println("\tpassword=" + password);
		
		// 假设root/1234是正确的用户名/密码
		// 判断用户名
		if ("root".equals(username)) {
			// 用户名正确，需要判断密码
			if ("1234".equals(password)) {
				// 密码也正确，登录成功
			} else {
				// 密码错误
				modelMap.addAttribute("errorMessage", "登录失败！密码错误！");
				return "error";
			}
		} else {
			// 用户名错误
			modelMap.addAttribute("errorMessage", "登录失败！用户名不存在！");
			return "error";
		}
		
		return null;
	}

#### 6.3. 使用ModelAndView作为处理请求的方法的返回值【不推荐】

可以使用`ModelAndView`作为处理请求的方法的返回值类型，当需要转发时，使用`ModelAndView`封装需要转发的数据与视图名：

	@RequestMapping("handle_login.do")
	public ModelAndView handleLogin(String username, String password) {
		System.out.println("UserController.handleLogin()");
		
		System.out.println("\tusername=" + username);
		System.out.println("\tpassword=" + password);
		
		// 假设root/1234是正确的用户名/密码
		// 判断用户名
		if ("root".equals(username)) {
			// 用户名正确，需要判断密码
			if ("1234".equals(password)) {
				// 密码也正确，登录成功
			} else {
				// 密码错误
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("errorMessage", "ModelAndView：登录失败！密码错误！");
				ModelAndView mav = new ModelAndView("error", model);
				return mav;
			}
		} else {
			// 用户名错误
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("errorMessage", "ModelAndView：登录失败！用户名不存在！");
			ModelAndView mav = new ModelAndView("error", model);
			return mav;
		}
		
		return null;
	}

### 7. 关于@RequestMapping注解

在处理请求的方法之前添加该注解，可以绑定请求路径与处理请求的方法的映射关系！

在`@RequestMapping`的源代码中有：

	@AliasFor("path")
	String[] value() default {};

`value`是注解的默认属性，当需要配置该属性的值时，如果在注解中只配置1个属性，则不需要显式的声明属性名，即：

	@RequestMapping(value="1")
	@RequestMapping("1")

以上2种配置是等效的！

`value`属性的值是`String[]`类型的，在配置时，可以使用`String`或`String[]`类型的值，例如：

	@RequestMapping(value="1")
	@RequestMapping(value={"1", "2", "3"})

以上2种配置都是正确的！

`value`属性就是用于配置映射的路径的！假设需要配置的路径是`login.do`，则可以配置为：

	@RequestMapping("login.do")
	@RequestMapping(value="login.do")
	@RequestMapping({"login.do"})
	@RequestMapping(value={"login.do"})

以上4种配置是等效的！

如果希望将多个路径映射到同一个方法，就必须使用数组格式来配置，例如：

	@RequestMapping({"reg.do", "register.do", "zhuce.do", "zc.do"})

`value`属性的源代码上方的`@AliasFor("path")`表示另有别为为`path`，在配置时，如果需要显式的写出属性名，则写为`value`或`path`都是可以的！