### 23. 用户-上传头像-控制器层

在控制器层中，关于上传头像的代码：

	/**
	 * 允许上传的文件大小的上限值，以字节为单位
	 */
	private static final long AVATAR_MAX_SIZE = 101 * 1024;
	/**
	 * 允许上传的文件类型的集合
	 */
	private static final List<String> AVATAR_TYPES = new ArrayList<>();
	
	static {
		AVATAR_TYPES.add("image/jpeg");
		AVATAR_TYPES.add("image/png");
		AVATAR_TYPES.add("image/gif");
		AVATAR_TYPES.add("image/bmp");
	}
	
	@PostMapping("avatar/change")
	public JsonResult<String> changeAvatar(
		MultipartFile file, HttpSession session) {
		// 日志
		System.err.println("UserController.changeAvatar()");
		
		// 判断文件是否为空
		boolean isEmpty = file.isEmpty();
		System.err.println("\tisEmpty=" + isEmpty);
		if (isEmpty) {
			// 上传的文件为空，则抛出异常
			throw new FileEmptyException(
				"上传失败！请选择您要上传的文件！");
		}
		
		// 获取文件大小
		long size = file.getSize();
		System.err.println("\tsize=" + size);
		if (size > AVATAR_MAX_SIZE) {
			throw new FileSizeException(
				"上传失败！不允许上传超过" + 
					(AVATAR_MAX_SIZE / 1024) + "KB的文件！");
		}
		
		// 获取文件的MIME类型
		String contentType = file.getContentType();
		System.err.println("\tcontentType=" + contentType);
		// 判断上传的文件类型是否符合：image/jpeg，image/png，image/gif，image/bmp
		if (!AVATAR_TYPES.contains(contentType)) {
			throw new FileTypeException(
				"上传失败！仅允许上传以下类型的文件：" + AVATAR_TYPES);
		}
		
		// 获取原始文件名(客户端设备中的文件名)
		String originalFilename 
			= file.getOriginalFilename();
		System.err.println("\toriginalFilename=" + originalFilename);
		
		// 将文件上传到哪个文件夹
		String parent = session
			.getServletContext().getRealPath("upload");
		System.err.println("\tupload path=" + parent);
		File dir = new File(parent);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		
		// 保存上传的文件时使用的文件名
		String filename = "" 
				+ System.currentTimeMillis() 
				+ System.nanoTime();
		String suffix = "";
		int beginIndex = originalFilename
				.lastIndexOf(".");
		if (beginIndex >= 1) {
			suffix = originalFilename
				.substring(beginIndex);
		}
		String child = filename + suffix;
		
		// 将客户端上传的文件保存到服务器端
		File dest = new File(parent, child);
		try {
			file.transferTo(dest);
		} catch (IllegalStateException e) {
			throw new FileUploadStateException(
				"上传失败！您的文件的状态异常！");
		} catch (IOException e) {
			throw new FileUploadIOException(
				"上传失败！读写文件时出现错误，请重新上传！");
		}
		
		// 将保存的文件的路径记录到数据库中
		String avatar = "/upload/" + child;
		System.err.println("\tavatar path=" + avatar);
		Integer uid = getUidFromSession(session);
		String username = getUsernameFromSession(session);
		userService.changeAvatar(uid, avatar, username);
		
		// 返回
		return new JsonResult<>(OK, avatar);
	}

### 24. 用户-上传头像-前端页面

如果需要使用`$.ajax()`函数实现上传，在配置该函数的参数时，参数JSON对象的使用相对一般的数据提交有所区别，在于：

1. `data`属性的值不再是`$("表单").serialize()`，而必须是`new FormData(表单)`；

2. 添加配置`contentType`属性，取值为`false`；

3. 添加配置`processData`属性，取值为`false`。

为了使得打开页面时，就显示新上传的头像，应该将上传成功后得到的头像路径存储在本地！则需要使用Cookie技术！

在登录页面**login.html**的顶部引用了基于jQuery操作Cookie的文件：

	<script src="../bootstrap3/js/jquery.cookie.js" type="text/javascript" charset="utf-8"></script>

而在上传头像页面**upload.html**中默认并没有引用该文件，所以，需要先在**upload.html**中补充引用以上文件！

在上传头像成功后，需要将头像路径保存到Cookie中：

	// 将新图片的路径保存到Cookie中
    $.cookie("avatar", json.data, {"expires":7});

并且，在该页面打开时，就应该读取保存的头像并显示到控件中：

	$(document).ready(function() {
    	// 尝试从Cookie中读取用户的头像
    	let avatar = $.cookie("avatar");
    	console.log("读取Cookie中的头像路径：" + avatar);
    	// 将页面中的图片控件显示头像
    	if (avatar != null) {
      		$("#img-avatar").attr("src", avatar);
    	}
    });

最后，还应该在登录页面**login.html**中，当登录成功时，将用户的头像保存到Cookie中：

	if (json.data.avatar == undefined) {
    		$.cookie("avatar", null, {"expires":-1});
    } else {
    		$.cookie("avatar", json.data.avatar, {"expires":7});
    }

### 25. 关于上传文件的补充

**关于一次性上传多个文件**

首先，应该考虑上传的文件的数量和文件的定位是否能直接确定，例如“上传身份证的正反两张照片”就属性是可确定的，而“发朋友圈”要上传的图片的数量就是无法确定的！

如果是可以确定的，则在页面中添加多个`<input type="file">`控件，然后，在控制器，声明多个`MultipartFile`类的参数即可！

如果是无法确定的，则在页面的控件`<input type="file">`中添加`multiple="multiple"`属性，则该控件是可以选择多个文件的，当用户操作时，按住键盘的Ctrl键就可以选择多个文件！由于只使用了1个控件，所以，多个文件提交到服务器后，会得到一个`MultipartFile[]`格式的数据，然后，检查数据并遍历数组即可处理！

**关于在SpringMVC框架中处理文件上传**

在使用SpringBoot框架时，已经添加了常用的依赖，并完成了常规的配置，所以，可以直接处理上传！在使用普通的SpringMVC框架时，首先，需要自行添加依赖：

	<dependency>
		<groupId>commons-fileupload</groupId>
		<artifactId>commons-fileupload</artifactId>
		<version>1.4</version>
	</dependency>

然后，在Spring的配置文件中添加配置：

	<bean id="multipartResolver" class="xx.xx.xx.CommonsMultipartResolver">
		<!-- 按需配置上传文件的大小限制 -->
		<!-- 按需配置字符编码 -->
	</bean>

注意：以上配置中，`<bean>`节点的`id`必须是`multipartResolver`！

最后，在处理请求时，参数列表中的`MultipartFile file`参数需要添加`@RequestParam("file")`注解！

### 26. 收货地址-创建数据表

![](01.png)

	CREATE TABLE t_address (
		aid INT AUTO_INCREMENT COMMENT '收货地址id',
		uid INT NOT NULL COMMENT '用户id',
		receiver VARCHAR(20) COMMENT '收货人',
		province_name VARCHAR(15) COMMENT '省名称',
		province_code CHAR(6) COMMENT '省代号',
		city_name VARCHAR(15) COMMENT '市名称',
		city_code CHAR(6) COMMENT '市代号',
		area_name VARCHAR(15) COMMENT '区名称',
		area_code CHAR(6) COMMENT '区代号',
		zip CHAR(6) COMMENT '邮政编码',
		address VARCHAR(50) COMMENT '详细地址',
		phone VARCHAR(20) COMMENT '手机',
		tel VARCHAR(20) COMMENT '固话',
		tag VARCHAR(10) COMMENT '地址类型',
		is_default INT(1) COMMENT '是否默认：0-非默认，1-默认',
		created_user VARCHAR(20) COMMENT '创建人',
		created_time DATETIME COMMENT '创建时间',
		modified_user VARCHAR(20) COMMENT '最后修改人',
		modified_time DATETIME COMMENT '最后修改时间',
		PRIMARY KEY (aid)
	) DEFAULT CHARSET=utf8mb4;

### 27. 收货地址-创建实体类

在`cn.tedu.store.entity`包中创建`Address`类，继承自`BaseEntity`类：

	/**
	 * 收货地址数据的实体类
	 */
	public class Address extends BaseEntity {
	
		private static final long serialVersionUID = 6788614546638401469L;
	
		private Integer aid;
		private Integer uid;
		private String receiver;
		private String provinceName;
		private String provinceCode;
		private String cityName;
		private String cityCode;
		private String areaName;
		private String areaCode;
		private String zip;
		private String address;
		private String phone;
		private String tel;
		private String tag;
		private Integer isDefault;

		// SET/GET/hashCode/equals/toString
	
	}

### 28. 收货地址-功能分析

关于收货地址数据的管理，需要开发的功能有：增加收货地址、修改收货地址、删除收货地址、查询收货地址列表、设置默认收货地址。

以上功能的开发顺序应该是：增加收货地址 > 查询收货地址列表 > 设置默认收货地址 > 删除收货地址 > 修改收货地址。

### 29. 收货地址-增加-持久层

**(a) 规划所需要执行的SQL语句**

向数据表中插入新的收货地址数据需要执行的SQL语句大致是：

	insert into t_address (除了aid以外的所有字段) values (匹配的值列表);

在执行插入收货地址之前，还应该先获取并检查该用户的收货地址的数量，并限制每个用户可以创建的收货地址的数量，则获取该用户的收货地址的数据的SQL语句大致是：

	select count(*) from t_address where uid=?

然后，每个用户的多条收货地址数据中，应该有且仅有1条默认收货地址，在用户没有自行设置默认收货地址之前，可以添加规则“该用户创建的第1条收货地址是默认的”，要实现这个目标，依然通过以上查询来实现！

**(b) 接口与抽象方法**

在`cn.tedu.store.mapper`包中创建`AddressMapper`接口，并在接口中添加抽象方法：

	Integer insert(Address address);

	Integer countByUid(Integer uid);

**(c) 配置映射**

在**src/main/resources/mappers**下，将原有的**UserMapper.xml**复制并粘贴得**AddressMapper.xml**，在**AddressMapper.xml**中，删除原有的配置，修改根节点的`namespace`对应以上`AddressMapper`接口，然后，配置以上2个抽象方法的映射：

	<mapper namespace="cn.tedu.store.mapper.AddressMapper">
	
		<!-- 插入收货地址数据 -->
		<!-- Integer insert(Address address) -->
		<insert id="insert"
			useGeneratedKeys="true"
			keyProperty="aid">
			INSERT INTO t_address (
				uid, receiver,
				province_name, province_code,
				city_name, city_code,
				area_name, area_code,
				zip, address,
				phone, tel,
				tag, is_default,
				created_user, created_time,
				modified_user, modified_time
			) VALUES (
				#{uid}, #{receiver},
				#{provinceName}, #{provinceCode},
				#{cityName}, #{cityCode},
				#{areaName}, #{areaCode},
				#{zip}, #{address},
				#{phone}, #{tel},
				#{tag}, #{isDefault},
				#{createdUser}, #{createdTime},
				#{modifiedUser}, #{modifiedTime}
			)
		</insert>
		
		<!-- 统计某用户的收货地址数据的数量 -->
		<!-- Integer countByUid(Integer uid) -->
		<select id="countByUid"
			resultType="java.lang.Integer">
			SELECT
				COUNT(*)
			FROM
				t_address
			WHERE
				uid=#{uid}
		</select>
	
	</mapper>

在**src/test/java**的`cn.tedu.store.mapper`包中创建`AddressMapperTests`测试类，在测试类的声明之前添加2项所需的注解，在类中编写并执行接口中2个抽象方法的单元测试：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class AddressMapperTests {
	
		@Autowired
		private AddressMapper mapper;
		
		@Test
		public void insert() {
			Address address = new Address();
			address.setUid(1);
			address.setReceiver("小赵");
			Integer rows = mapper.insert(address);
			System.err.println("rows=" + rows);
		}
		
		@Test
		public void countByUid() {
			Integer uid = 10;
			Integer count = mapper.countByUid(uid);
			System.err.println("count=" + count);
		}
		
	}

### 30. 收货地址-增加-业务层

**(a) 规划可能出现的异常**

每个用户允许创建的收货地址的数量应该是有限的，如果已经达到上限，则不允许创建更多的收货地址，将抛出`AddressCountLimitException`；

在执行插入收货地址数据时，还可能抛出`InsertException`。

所以，需要在`cn.tedu.store.service.ex`包中创建`AddressCountLimitException`，继承自`ServcieException`。

**(b) 业务接口及抽象方法**

在`cn.tedu.store.service`包中创建`IAddressService`接口，并在接口中添加抽象方法：

	void addnew(Integer uid, String username, Address address);

**(c) 实现抽象方法**

在`cn.tedu.store.service.impl`包中创建`AddressServiceImpl`类，实现以上接口，在类的声明之前添加`@Service`注解，在类添加`@Autowired private AddressMapper addressMapper;`持久层对象，然后，在类中重写接口中定义的抽象方法：

	public void addnew(Integer uid, String username, Address address) {
		// 根据uid统计该用户的收货地址数量
		// 判断数量是否超出设置值(假设为3)
		// 是：抛出AddressCountLimitException

		// 根据以上统计的数量是否为0，得到isDefault值
		// 创建当前时间对象now

		// 补全数据：uid
		// 补全数据：is_default
		// 补全数据：4项日志(username, now)
		// 执行插入用户数据，并获取返回的受影响行数
		// 判断受影响行数是否不为1
		// 是：抛出InsertException
	}

在实际编写代码时，先将收货地址数量的上限设置在**application.properties**中，设置时，属性名是自定义的：

	project.address-max-count=6

然后，在业务层实现类中，声明全局属性，并通过`@Value`注解读取配置的值：

	@Value("${project.address-max-count}")
	private int addressMaxCount;

接下来，完成接口中的抽象方法：

	@Override
	public void addnew(Integer uid, String username, Address address) {
		// 根据uid统计该用户的收货地址数量
		Integer count = addressMapper.countByUid(uid);
		// 判断数量是否超出设置值(假设为3)
		if (count >= addressMaxCount) {
			// 是：抛出AddressCountLimitException
			throw new AddressCountLimitException(
				"增加收货地址失败！收货地址数量已经达到上限("+ addressMaxCount + ")！");
		}

		// 根据以上统计的数量是否为0，得到isDefault值
		Integer isDefault = count == 0 ? 1 : 0;
		// 创建当前时间对象now
		Date now = new Date();

		// 补全数据：uid
		address.setUid(uid);
		// 补全数据：is_default
		address.setIsDefault(isDefault);
		// 补全数据：4项日志(username, now)
		address.setCreatedUser(username);
		address.setCreatedTime(now);
		address.setModifiedUser(username);
		address.setModifiedTime(now);
		// 执行插入用户数据，并获取返回的受影响行数
		Integer rows = addressMapper.insert(address);
		// 判断受影响行数是否不为1
		if (rows != 1) {
			// 是：抛出InsertException
			throw new InsertException(
				"增加收货地址失败！插入收货地址数据时出现未知错误，请联系系统管理员！");
		}
	}

在**src/test/java**的`cn.tedu.store.service`包中创建`AddressServiceTests`类，添加测试类所需的2个注解，在类中编写并执行测试方法：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class AddressServiceTests {
	
		@Autowired
		private IAddressService addressService;
		
		@Test
		public void addnew() {
			try {
				Integer uid = 1;
				String username = "HAHA";
				Address address = new Address();
				address.setReceiver("小刘");
				addressService.addnew(uid, username, address);
				System.err.println("OK.");
			} catch (ServiceException e) {
				System.err.println(e.getClass().getName());
				System.err.println(e.getMessage());
			}
		}
		
	}

### 31. 收货地址-增加-控制器层

**(a) 处理新创建的异常**

在`GlobalExceptionHandler`中处理`AddressCountLimitException`。

**(b) 设计所需要处理的请求**

	请求路径：/addresses/addnew
	请求参数：Address address, HttpSession session
	请求方式：POST
	响应结果：JsonResult<Void>

**(c) 处理请求**

先在`cn.tedu.store.controller`包中创建`AddressController`类，继承自`BaseController`，在类的声明之前添加`@RestController`和`@RequestMapping("addresses")`注解，并在类中声明`@Autowired private IAddressService addressService;`业务接口：

	/**
	 * 处理收货地址数据相关请求的控制器类
	 */
	@RestController
	@RequestMapping("addresses")
	public class AddressController extends BaseController {
	
		@Autowired
		private IAddressService addressService;
		
	}

然后，在类中添加处理请求的方法：

	// http://localhost:8080/addresses/addnew?receiver=Jackson
	@RequestMapping("addnew")
	public JsonResult<Void> addnew(Address address, HttpSession session) {
		Integer uid = getUidFromSession(session);
		String username = getUsernameFromSession(session);
		addressService.addnew(uid, username, address);
		return new JsonResult<>(OK);
	}

### 32. 收货地址-增加-前端页面