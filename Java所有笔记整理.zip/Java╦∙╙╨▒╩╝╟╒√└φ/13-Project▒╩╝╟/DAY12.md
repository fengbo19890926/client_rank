### 81. 订单-创建订单-业务层

	@Override
	public Order create(Integer aid, Integer[] cids, Integer uid, String username) {
		// 创建当前时间对象now
		Date now = new Date();
		
		// 根据参数aid调用addressService的Address getByAid(Integer aid)方法查询收货地址数据
		Address address = addressService.getByAid(aid, uid);

		// 根据参数cids调用cartService的List<CartVO> getVOByCids(Integer[] cids, Integer uid)方法查询购物车中的数据，得到List<CartVO>类型的结果
		List<CartVO> carts = cartService.getVOByCids(cids, uid);
		// 声明totalPrice表示总价
		Long totalPrice = 0L;
		// 遍历以上查询结果，在遍历过程中，累加商品单价乘以数量的结果
		for (CartVO cart : carts) {
			totalPrice += cart.getRealPrice() * cart.getNum();
		}

		// 创建Order对象
		Order order = new Order();
		// 补全属性：uid
		order.setUid(uid);
		// 补全属性：收货地址相关的6个属性
		order.setRecvName(address.getReceiver());
		order.setRecvPhone(address.getPhone());
		order.setRecvProvince(address.getProvinceName());
		order.setRecvCity(address.getCityName());
		order.setRecvArea(address.getAreaName());
		order.setRecvAddress(address.getAddress());
		// 补全属性：price -> totalPrice
		order.setPrice(totalPrice);
		// 补全属性：order_time -> now
		order.setOrderTime(now);
		// 补全属性：pay_time -> null
		order.setPayTime(null);
		// 补全属性：status -> 0
		order.setStatus(0);
		// 补全属性：4个日志
		order.setCreatedUser(username);
		order.setCreatedTime(now);
		order.setModifiedUser(username);
		order.setModifiedTime(now);
		// 插入订单数据：insertOrder(order);
		insertOrder(order);

		// 遍历查询到的List<CartVO>对象
		for (CartVO cart : carts) {
			// 创建OrderItem对象
			OrderItem item = new OrderItem();
			// 补全属性：oid -> order.getOid();
			item.setOid(order.getOid());
			// 补全属性：pid, title, image, price, num -> CartVO中的属性
			item.setPid(cart.getPid());
			item.setTitle(cart.getTitle());
			item.setImage(cart.getImage());
			item.setPrice(cart.getRealPrice());
			item.setNum(cart.getNum());
			// 补全属性：4个日志
			item.setCreatedUser(username);
			item.setCreatedTime(now);
			item.setModifiedUser(username);
			item.setModifiedTime(now);
			// 插入若干条订单商品数据：insertOrderItem(orderItem)
			insertOrderItem(item);
		}
		
		// 返回
		return order;
	}

### 82. 订单-创建订单-控制器层

	/**
	 * 处理订单相关请求的控制器类
	 */
	@RestController
	@RequestMapping("orders")
	public class OrderController extends BaseController {
	
		@Autowired
		private IOrderService orderService;
		
		// http://localhost:8080/orders/create?aid=26&cids=8&cids=9&cids=10
		@RequestMapping("create")
		public JsonResult<Order> create(Integer aid, Integer[] cids, HttpSession session) {
			Integer uid = getUidFromSession(session);
			String username = getUsernameFromSession(session);
			Order data = orderService.create(aid, cids, uid, username);
			return new JsonResult<>(OK, data);
		}
		
	}

### 83. Spring AOP

AOP：面向切面编程。

其实，AOP并不是Spring独有的特性，更不是Spring所开发的特性，只是Spring能很好的支持AOP。

关于切面，首先得了解数据的处理流程：

	注册		View <--> Controller <--> Service <--> Mapper
	登录		View <--> Controller <--> Service <--> Mapper
	改密		View <--> Controller <--> Service <--> Mapper
	头像		View <--> Controller <--> Service <--> Mapper

假设有某个功能，需要在以上每个数据处理流程中都要执行，例如“统计业务方法的执行耗时”，即注册在Service中消耗了多少时间，登录在Service中消耗了多少时间……

在传统模式下，可以将“统计耗时”封装在一个方法中，然后，在每个业务方法中调用该方法即可！

但是，在比较大的系统中，业务方法的数量可能非常多，如果在每个方法中逐一添加，工作量较大，并且，也不易于维护代码！

所谓的“切面”是数据处理流程中的一个面！可以表现为是一个类，类中可以自定义方法，当数据处理流程执行到切面时，就会执行切面中的方法！

接下来，使用AOP在项目中实现“统计业务方法的执行耗时”！

首先，需要在项目中添加`aspectjtools`和`aspectjweaver`这2个关于AOP的依赖：

	<dependency>
		<groupId>org.aspectj</groupId>
		<artifactId>aspectjweaver</artifactId>
		<version>1.9.5</version>
	</dependency>

	<dependency>
		<groupId>org.aspectj</groupId>
		<artifactId>aspectjtools</artifactId>
		<version>1.9.5</version>
	</dependency>

接下来，在项目中创建`cn.tedu.store.aop.TimerAspect`切面类，注意：需要放在组件扫描的包中！另外，还需要添加`@Component`，表示它是组件类，这样，Spring框架才会创建该类的对象，同时，还需要添加`@Aspect`注解，表示它是切面类，后面切面的执行就需要这个注解：
	
	@Aspect
	@Component
	// @Controller, @Service, @Repository
	public class TimerAspect {
	
	}

然后，在切面类中编写切面方法，关于方法的声明：

1. 应该使用`public`权限；
2. 使用`Object`作为返回值；
3. 方法名称可以自定义；
4. 在参数列表中添加`ProceedingJoinPoint`类型的参数；
5. 在方法的声明之前添加`@Around`注解，以配置切面的应用位置。

所以，添加的方法大致是：

	@Around("execution(* cn.tedu.store.service.impl.*.*(..))")
	public Object aaaaa(ProceedingJoinPoint pjp) {
		return null;
	}

然后，在`@Around`注解中使用`execution`表达式，配置接下来的切面方法将应用于哪里：

	@Around("execution(* cn.tedu.store.service.impl.*.*(..))")
	public Object aaaaa(ProceedingJoinPoint pjp) {
		System.err.println("============");
		System.err.println("AOP!!!!!");
		System.err.println("============");
		return null;
	}

方法的参数列表中的`ProceedingJoinPoint`表示“连接点”，可以理解为就是Service中的注册方法或登录方法或其它方法，调用该参数对象的`proceed()`就相当于执行了业务方法！在切面方法中，务必需要调用该方法，否则，将相当于业务方法没有执行！并且，还要获取`proceed()`方法的返回值，作为切面方法的返回值，否则，相当于调用了业务方法但不获取返回值！

	@Around("execution(* cn.tedu.store.service.impl.*.*(..))")
	public Object aaaaa(ProceedingJoinPoint pjp) throws Throwable {
		// 记录开始时间
		long start = System.currentTimeMillis();
		
		// 相当于执行了Service中的注册或登录或其它方法
		// 调用的proceed()会抛出异常，必须继续抛出
		Object result = pjp.proceed();
		
		// 记录结束时间
		long end = System.currentTimeMillis();
		
		// 计算耗时
		System.err.println("耗时：" + (end - start) + "ms.");
		
		return result;
	}

其实，在切面方法之前还可以使用其它注解，例如使用`@Before`、`@After`注解，如果使用这2种注解，切面方法的返回值就可以使用`void`，并且，切面方法的参数列表中不需要`ProceedingJoinPoint`参数，在切面方法的实现过程更加不需要自己调用`pjp.proceed()`方法！

通常，不必关心`@Before`、`@After`注解的使用方式！只要在切面方法中，在`pjp.proceed()`方法之后不执行任何代码，就相当于`@Before`，反之，在切面方法中，直接执行`pjp.proceed()`然后再在后面添加自定义代码，就相当于`@After`！

### ------------------------------

### 补充： 购物车-增加商品数量-持久层

**(a) 规划需要执行的SQL语句**

先查询需要操作的购物车数据：

	select * from t_cart where cid=?

然后，计算出新的数据值，如果允许更新，则更新：

	update t_cart set num=? where cid=?

**(b) 接口与抽象方法**

在`CartMapper`中添加：

	Cart findByCid(Integer cid);

**(c) 配置SQL映射**

映射：

	<!-- 根据购物车数据id查询购物车数据详情 -->
	<!-- Cart findByCid(Integer cid) -->
	<select id="findByCid"
		resultMap="CartEntityMap">
		SELECT
			*
		FROM
			t_cart
		WHERE
			cid=#{cid}
	</select>

测试：

	@Test
	public void findByCid() {
		Integer cid = 10;
		Cart result = mapper.findByCid(cid);
		System.err.println(result);
	}

### 补充： 购物车-增加商品数量-业务层

**(a) 规划异常**

如果尝试访问的购物车数据不存在，则抛出`CartNotFoundException`；

如果尝试访问的数据并不是当前登录用户的数据，则抛出`AccessDeniedException`；

最终将执行更新操作，则可能抛出`UpdateException`；

则需要创建`cn.tedu.store.service.ex.CartNotFoundException`。

**(b) 接口与抽象方法**

在`ICartService`中添加抽象方法：

	Integer addNum(Integer cid, Integer uid, String username);

**(c) 实现抽象方法**

在`CartServiceImpl`中，先添加持久层的方法，私有实现：

	/**
	 * 根据购物车数据id查询购物车数据详情
	 * @param cid 购物车数据id
	 * @return 匹配的购物车数据详情，如果没有匹配的数据，则返回null
	 */
	private Cart findByCid(Integer cid) {
		return cartMapper.findByCid(cid);
	}

实现抽象方法：

	public Integer addNum(Integer cid, Integer uid, String username) {
		// 调用findByCid(cid)根据参数cid查询购物车数据
		// 判断查询结果是否为null
		// 是：抛出CartNotFoundException

		// 判断查询结果中的uid与参数uid是否不一致
		// 是：抛出AccessDeniedException

		// 可选：检查商品的数量是否大于多少(适用于增加数量)或小于多少(适用于减少数量)
		// 根据查询结果中的原数量增加1得到新的数量num

		// 创建当前时间对象，作为modifiedTime
		// 调用updateNumByCid(cid, num, modifiedUser, modifiedTime)执行修改数量
	}

实现代码：

	@Override
	public Integer addNum(Integer cid, Integer uid, String username) {
		// 调用findByCid(cid)根据参数cid查询购物车数据
		Cart result = findByCid(cid);
		// 判断查询结果是否为null
		if (result == null) {
			// 是：抛出CartNotFoundException
			throw new CartNotFoundException(
				"尝试访问的购物车数据不存在");
		}

		// 判断查询结果中的uid与参数uid是否不一致
		if (!result.getUid().equals(uid)) {
			// 是：抛出AccessDeniedException
			throw new AccessDeniedException("非法访问");
		}

		// 可选：检查商品的数量是否大于多少(适用于增加数量)或小于多少(适用于减少数量)
		// 根据查询结果中的原数量增加1得到新的数量num
		Integer num = result.getNum() + 1;

		// 创建当前时间对象，作为modifiedTime
		Date now = new Date();
		// 调用updateNumByCid(cid, num, modifiedUser, modifiedTime)执行修改数量
		updateNumByCid(cid, num, username, now);
		
		// 返回新的数量
		return num;
	}

测试：

	@Test
	public void addNum() {
		try {
			Integer cid = 12;
			Integer uid = 19;
			String username = "不知道";
			Integer num = service.addNum(cid, uid, username);
			System.err.println("OK. New num=" + num);
		} catch (ServiceException e) {
			System.err.println(e.getClass().getSimpleName());
			System.err.println(e.getMessage());
		}
	}

### 补充： 购物车-增加商品数量-控制器

**(a) 处理异常**

需要处理`CartNotFoundException`。

**(b) 设计请求**

设计用户提交的请求，并设计响应的方式：

	请求路径：/carts/{cid}/num/add
	请求参数：@PathVariable("cid") Integer cid, HttpSession session
	请求类型：POST
	响应结果：JsonResult<Integer>

**(c) 处理请求**

代码：

	@RequestMapping("{cid}/num/add")
	public JsonResult<Integer> addNum(@PathVariable("cid") Integer cid, HttpSession session) {
		// 从Session中获取uid和username
		Integer uid = getUidFromSession(session);
		String username = getUsernameFromSession(session);
		// 调用业务对象执行增加数量
		Integer data = cartService.addNum(cid, uid, username);
		// 返回成功
		return new JsonResult<>(OK, data);
	}

测试：

	http://localhost:8080/carts/10/num/add

### 补充： 购物车-增加商品数量-前端页面