### 70. 购物车-显示列表-持久层

**(a) 规划所需要执行的SQL语句**

显示购物车列表时，只会显示当前登录的用户的购物车数据，需要执行的SQL语句大致是：

	select 
		cid, uid, pid, t_cart.num, t_cart.price,
		title, t_product.price AS realPrice, image
	from 
		t_cart 
	left join 
		t_product 
	on 
		t_cart.pid=t_product.id
	where 
		uid=?
	order by 
		t_cart.created_time desc

**(b) 接口与抽象方法**

在`cn.tedu.store`包中创建子级的`vo`包，并在这个包中创建`CartVO`类：

	public class CartVO implements Serializable {
		private Integer cid;
		private Integer uid;
		private Integer pid;
		private Integer num;
		private String title;
		private String image;
		private Long price;
		private Long realPrice;
		// SET/GET/基于cid的hashCode和equals/toString
	}

在`CartMapper`中添加：

	List<CartVO> findVOByUid(Integer uid);

**(c) 配置映射**

映射：

	<!-- 查询某用户的购物车数据的列表 -->
	<!-- List<CartVO> findVOByUid(Integer uid) -->
	<select id="findVOByUid"
		resultType="cn.tedu.store.vo.CartVO">
		SELECT
			cid, uid,
			pid, t_cart.num,
			t_cart.price, title,
			image, t_product.price AS realPrice
		FROM
			t_cart
		LEFT JOIN
			t_product
		ON
			t_cart.pid=t_product.id
		WHERE
			uid=#{uid}
		ORDER BY
			t_cart.created_time DESC
	</select>

测试：

	@Test
	public void findVOByUid() {
		Integer uid = 18;
		List<CartVO> list = mapper.findVOByUid(uid);
		System.err.println("count=" + list.size());
		for (CartVO item : list) {
			System.err.println(item);
		}
	}

### 71. 购物车-显示列表-业务层

**(a) 规划可能出现的异常**

无

**(b) 业务接口及抽象方法**

	/**
	 * 查询某用户的购物车数据的列表
	 * @param uid 用户id
	 * @return 该用户的购物车数据的列表
	 */
	List<CartVO> getVOByUid(Integer uid);

**(c) 实现抽象方法**

代码：

	/**
	 * 查询某用户的购物车数据的列表
	 * @param uid 用户id
	 * @return 该用户的购物车数据的列表
	 */
	private List<CartVO> findVOByUid(Integer uid) {
		return cartMapper.findVOByUid(uid);
	}

	@Override
	public List<CartVO> getVOByUid(Integer uid) {
		return findVOByUid(uid);
	}

测试：

	@Test
	public void getVOByUid() {
		Integer uid = 18;
		List<CartVO> list = service.getVOByUid(uid);
		System.err.println("count=" + list.size());
		for (CartVO item : list) {
			System.err.println(item);
		}
	}

### 72. 购物车-显示列表-控制器层

**(a) 处理新创建的异常**

无

**(b) 设计所需要处理的请求**

	请求路径：/carts/
	请求参数：HttpSession session
	请求方式：GET
	响应结果：JsonResult<List<CartVO>>

**(c) 处理请求**

	// http://localhost:8080/carts/
	@GetMapping("")
	public JsonResult<List<CartVO>> getVOByUid(HttpSession session) {
		Integer uid = getUidFromSession(session);
		List<CartVO> data = cartService.getVOByUid(uid);
		return new JsonResult<>(OK, data);
	}

### 73. 购物车-显示列表-前端页面

### 74. 显示确认订单页-显示当前用户的收货地址列表-前端页面

目前，已经可以通过`http://localhost:8080/addresses`获取到当前登录的用户的收货地址列表数据！只需要将这些数据显示到页面**orderConfirm.html**中即可！

### 75. 显示确认订单页-显示前序页面勾选的即将购买的商品-持久层

需要执行的SQL语句大致是：

	select 字段列表 from t_cart left join t_product on pid=id where cid in (?,?,?) order by t_cart.created_time desc

在`CartMapper`接口添加抽象方法：

	List<CartVO> findVOByCids(Integer[] cids);

在**CartMapper.xml**中配置：

	<!-- 根据多个数据id查询购物车数据的列表 -->
	<!-- List<CartVO> findVOByCids(Integer[] cids) -->
	<select id="findVOByCids"
		resultType="cn.tedu.store.vo.CartVO">
		SELECT
			cid, uid,
			pid, t_cart.num,
			t_cart.price, title,
			image, t_product.price AS realPrice
		FROM
			t_cart
		LEFT JOIN
			t_product
		ON
			t_cart.pid=t_product.id
		WHERE
			cid IN
			<foreach collection="array"
				item="cid" separator=","
				open="(" close=")">
				#{cid}
			</foreach>
		ORDER BY
			t_cart.created_time DESC
	</select>

测试：

	@Test
	public void findVOByCids() {
		Integer[] cids = { 9, 10, 11, 800, 900 };
		List<CartVO> list = mapper.findVOByCids(cids);
		System.err.println("count=" + list.size());
		for (CartVO item : list) {
			System.err.println(item);
		}
	}

### 76. 显示确认订单页-显示前序页面勾选的即将购买的商品-业务层

在`ICartService`中添加：

	/**
	 * 根据多个数据id查询购物车数据的列表
	 * @param cids 多个购物车数据id
	 * @param uid 当前登录的用户的id
	 * @return 匹配的购物车数据的列表
	 */
	List<CartVO> getVOByCids(Integer[] cids, Integer uid);

在`CartServiceImpl`中，先把持久层的方法复制过来，改为私有方法并实现：

	/**
	 * 根据多个数据id查询购物车数据的列表
	 * @param cids 多个购物车数据id
	 * @return 匹配的购物车数据的列表
	 */
	private List<CartVO> findVOByCids(Integer[] cids) {
		return cartMapper.findVOByCids(cids);
	}

重写接口中的抽象方法：

	@Override
	public List<CartVO> getVOByCids(Integer[] cids, Integer uid) {
		List<CartVO> carts = findVOByCids(cids);
		
		// 遍历查询结果，判断集合中元素是否归属当前用户，如果不是，则移除
		Iterator<CartVO> it = carts.iterator();
		while (it.hasNext()) {
			CartVO cart = it.next();
			
			if (!cart.getUid().equals(uid)) {
				it.remove();
			}
		}
		
		return carts;
	}

测试：

	@Test
	public void getVOByCids() {
		Integer[] cids = {9,10,11,12,13,14,15,16};
		Integer uid = 19;
		List<CartVO> list = service.getVOByCids(cids, uid);
		System.err.println("count=" + list.size());
		for (CartVO item : list) {
			System.err.println(item);
		}
	}

### 77. 显示确认订单页-显示前序页面勾选的即将购买的商品-控制器层

	// http://localhost:8080/carts/get_by_cids?cids=6&cids=7&cids=8&cids=9&cids=10&cids=11&cids=12&cids=13&cids=14&cids=15
	@GetMapping("get_by_cids")
	public JsonResult<List<CartVO>> getVOByCids(Integer[] cids, HttpSession session) {
		Integer uid = getUidFromSession(session);
		List<CartVO> data = cartService.getVOByCids(cids, uid);
		return new JsonResult<>(OK, data);
	}

### 78. 订单-创建数据表

![](table_order.png)

	CREATE TABLE t_order (
		oid INT AUTO_INCREMENT COMMENT '订单id',
		uid INT COMMENT '归属用户id',
		recv_name VARCHAR(20) COMMENT '收货人',
		recv_phone VARCHAR(20) COMMENT '收货电话',
		recv_province VARCHAR(15) COMMENT '收货省',
		recv_city VARCHAR(15) COMMENT '收货市',
		recv_area VARCHAR(15) COMMENT '收货区',
		recv_address VARCHAR(50) COMMENT '收货详细地址',
		price BIGINT COMMENT '订单金额',
		order_time DATETIME COMMENT '下单时间',
		pay_time DATETIME COMMENT '支付时间',
		status INT(1) COMMENT '订单状态：0-未支付，1-已支付，2-已取消，3-已关闭',
		created_user VARCHAR(20) COMMENT '创建人',
		created_time DATETIME COMMENT '创建时间',
		modified_user VARCHAR(20) COMMENT '最后修改人',
		modified_time DATETIME COMMENT '最后修改时间',
		PRIMARY KEY (oid)
	) DEFAULT CHARSET=utf8mb4;

![](table_order_item.png)

	CREATE TABLE t_order_item (
		id INT AUTO_INCREMENT COMMENT 'id',
		oid INT COMMENT '归属订单的id',
		pid INT COMMENT '商品id',
		title VARCHAR(100) COMMENT '商品标题',
		image VARCHAR(500) COMMENT '商品图片',
		price BIGINT(20) COMMENT '商品单价',
		num INT COMMENT '购买数量',
		created_user VARCHAR(20) COMMENT '创建人',
		created_time DATETIME COMMENT '创建时间',
		modified_user VARCHAR(20) COMMENT '最后修改人',
		modified_time DATETIME COMMENT '最后修改时间',
		PRIMARY KEY (id)
	) DEFAULT CHARSET=utf8mb4;

### 79. 订单-创建实体类

	/**
	 * 订单数据的实体类
	 */
	public class Order extends BaseEntity {
	
		private static final long serialVersionUID = 3323753841025526108L;
		
		private Integer oid;
		private Integer uid;
		private String recvName;
		private String recvPhone;
		private String recvProvince;
		private String recvCity;
		private String recvArea;
		private String recvAddress;
		private Long price;
		private Date orderTime;
		private Date payTime;
		private Integer status;
	
	}
	
	/**
	 * 订单中的商品数据的实体类
	 */
	public class OrderItem extends BaseEntity {
	
		private static final long serialVersionUID = -8879247924788259070L;
	
		private Integer id;
		private Integer oid;
		private Integer pid;
		private String title;
		private String image;
		private Long price;
		private Integer num;
	
	}

### 80. 订单-创建订单-持久层

在创建订单时，需要向2张表中都插入数据：

	insert into t_order (除了oid以外的字段列表) values (值列表)

	insert into t_order_item (除了id以外的字段列表) values (值列表)

在编写代码时，需要先创建`OrderMapper`接口，并在接口中添加抽象方法：

	Integer insertOrder(Order order);

	Integer insertOrderItem(OrderItem orderItem);

复制得到**OrderMapper.xml**文件，并在该文件中配置映射：

	<mapper namespace="cn.tedu.store.mapper.OrderMapper">
	
		<!-- 插入订单数据 -->
		<!-- Integer insertOrder(Order order) -->
		<insert id="insertOrder"
			useGeneratedKeys="true"
			keyProperty="oid">
			INSERT INTO t_order (
				uid, recv_name,
				recv_phone, recv_province,
				recv_city, recv_area,
				recv_address, price,
				order_time, pay_time,
				status,
				created_user, created_time,
				modified_user, modified_time
			) VALUES (
				#{uid}, #{recvName},
				#{recvPhone}, #{recvProvince},
				#{recvCity}, #{recvArea},
				#{recvAddress}, #{price},
				#{orderTime}, #{payTime},
				#{status},
				#{createdUser}, #{createdTime},
				#{modifiedUser}, #{modifiedTime}
			)
		</insert>
	
		<!-- 插入订单商品数据 -->
		<!-- Integer insertOrderItem(OrderItem orderItem) -->
		<insert id="insertOrderItem"
			useGeneratedKeys="true"
			keyProperty="id">
			INSERT INTO t_order_item (
				oid, pid,
				title, image,
				price, num,
				created_user, created_time,
				modified_user, modified_time
			) VALUES (
				#{oid}, #{pid},
				#{title}, #{image},
				#{price}, #{num},
				#{createdUser}, #{createdTime},
				#{modifiedUser}, #{modifiedTime}
			)
		</insert>
		
	</mapper>

完成后，测试：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class OrderMapperTests {
	
		@Autowired
		private OrderMapper mapper;
		
		@Test
		public void insertOrder() {
			Order order = new Order();
			order.setUid(1);
			order.setRecvName("小吴同学");
			Integer rows = mapper.insertOrder(order);
			System.err.println("rows=" + rows);
		}
	
		@Test
		public void insertOrderItem() {
			OrderItem orderItem = new OrderItem();
			orderItem.setOid(1);
			orderItem.setPid(2);
			Integer rows = mapper.insertOrderItem(orderItem);
			System.err.println("rows=" + rows);
		}
		
	}

### 81. 订单-创建订单-业务层

由于后续将需要根据收货地址id查询收货地址详情，所以需要补充该功能！在处理收货地址的持久层已经开发了`Address findByAid(Integer aid)`，所以，只需要在`IAddressService`中添加抽象方法：

	Address getByAid(Integer aid, Integer uid);

并在`AddressServiceImpl`中实现该方法：

	public Address getByAid(Integer aid, Integer uid) {
		// 执行查询
		// 判断查询结果是否为null
		// 是：抛出AddressNotFoundException

		// 判断查询结果的数据归属是否错误
		// 是：抛出AccessDeniedException

		// 将查询结果中的某些属性设置为null
		// 返回查询结果
	}

具体代码为：

	@Override
	public Address getByAid(Integer aid, Integer uid) {
		// 根据参数aid查询收货地址数据
		Address result = findByAid(aid);
		// 判断查询结果是否为null
		if (result == null) {
			// 是：AddressNotFoundException
			throw new AddressNotFoundException(
				"查询收货地址失败！尝试访问的数据不存在！");
		}

		// 判断查询结果中的uid与参数uid是否不一致
		if (!result.getUid().equals(uid)) {
			// 是：AccessDeniedException
			throw new AccessDeniedException(
				"查询收货地址失败！非法访问已经被拒绝！");
		}
		
		// 将查询结果中的某些属性设置为null
		result.setUid(null);
		result.setProvinceCode(null);
		result.setCityCode(null);
		result.setAreaCode(null);
		result.setIsDefault(null);
		result.setCreatedUser(null);
		result.setCreatedTime(null);
		result.setModifiedUser(null);
		result.setModifiedTime(null);
		
		// 返回查询结果
		return result;
	}

测试：

	@Test
	public void getByAid() {
		try {
			Integer uid = 18;
			Integer aid = 26;
			Address result = service.getByAid(aid, uid);
			System.err.println(result);
		} catch (ServiceException e) {
			System.err.println(e.getClass().getName());
			System.err.println(e.getMessage());
		}
	}

创建`cn.tedu.store.service.IOrderService`接口，并在接口中添加抽象方法：

	Order create(Integer aid, Integer[] cids, Integer uid, String username);

创建`cn.tedu.store.service.impl.OrderServiceImpl`类，实现以上接口，并在类的声明之前添加`@Service`注解，在类中声明`@Autowired private OrderMapper orderMapper;`持久层对象，声明`@Autowired private IAddressService addressService;`处理收货地址的业务对象，声明`@Autowired private ICartService cartService;`处理购物车的业务对象：

	@Service
	public class OrderServiceImpl implements IOrderService {

		@Autowired private OrderMapper orderMapper;
		@Autowired private IAddressService addressService;
		@Autowired private ICartService cartService;

	}

将持久层中的2个方法复制到当前类，改为私有方法，并实现：

	/**
	 * 插入订单数据
	 * @param order 订单数据
	 */
	private void insertOrder(Order order) {
		Integer rows = orderMapper.insertOrder(order);
		if (rows != 1) {
			throw new InsertException(
				"创建订单失败！插入订单数据时出现未知错误，请联系系统管理员！");
		}
	}

	/**
	 * 插入订单商品数据
	 * @param orderItem 订单商品数据
	 */
	private void insertOrderItem(OrderItem orderItem) {
		Integer rows = orderMapper.insertOrderItem(orderItem);
		if (rows != 1) {
			throw new InsertException(
				"创建订单失败！插入订单商品数据时出现未知错误，请联系系统管理员！");
		}
	}

然后，重写接口中的抽象方法：

	public Order create(Integer aid, Integer[] cids, Integer uid, String username) {
		// 创建当前时间对象now

		// 根据参数cids调用cartService的List<CartVO> getVOByCids(Integer[] cids, Integer uid)方法查询购物车中的数据，得到List<CartVO>类型的结果
		// 声明totalPrice表示总价
		// 遍历以上查询结果，在遍历过程中，累加商品单价乘以数量的结果

		// 根据参数aid调用addressService的Address getByAid(Integer aid)方法查询收货地址数据

		// 创建Order对象
		// 补全属性：uid
		// 补全属性：收货地址相关的6个属性
		// 补全属性：price -> totalPrice
		// 补全属性：order_time -> now
		// 补全属性：pay_time -> null
		// 补全属性：status -> 0
		// 补全属性：4个日志
		// 插入订单数据：insertOrder(order);

		// 遍历查询到的List<CartVO>对象
		// -- 创建OrderItem对象
		// -- 补全属性：oid -> order.getOid();
		// -- 补全属性：pid, title, image, price, num -> CartVO中的属性
		// -- 补全属性：4个日志
		// -- 插入若干条订单商品数据：insertOrderItem(orderItem)
	}