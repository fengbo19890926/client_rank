### 42. 收货地址-显示列表-持久层

**(a) 规划所需要执行的SQL语句**

显示某用户的收货地址列表，需要执行的SQL语句大致是：

	select * from t_address where uid=? order by is_default desc, modified_time desc

**(b) 接口与抽象方法**

在`AddressMapper`接口中添加抽象方法：

	/**
	 * 查询某用户的收货地址列表
	 * @param uid 用户的id
	 * @return 该用户的收货地址列表
	 */
	List<Address> findByUid(Integer uid);

**(c) 配置映射**

在**AddressMapper.xml**中配置：

	<resultMap id="AddressEntityMap"
		type="cn.tedu.store.entity.Address">
		<id column="aid" property="aid" />
		<result column="province_code" property="provinceCode" />
		<result column="province_name" property="provinceName" />
		<result column="city_code" property="cityCode" />
		<result column="city_name" property="cityName" />
		<result column="area_code" property="areaCode" />
		<result column="area_name" property="areaName" />
		<result column="is_default" property="isDefault" />
		<result column="created_user" property="createdUser" />
		<result column="created_time" property="createdTime" />
		<result column="modified_user" property="modifiedUser" />
		<result column="modified_time" property="modifiedTime" />
	</resultMap>

	<!-- 查询某用户的收货地址列表 -->
	<!-- List<Address> findByUid(Integer uid) -->
	<select id="findByUid"
		resultMap="AddressEntityMap">
		SELECT
			*
		FROM
			t_address
		WHERE
			uid=#{uid}
		ORDER BY
			is_default DESC, modified_time DESC
	</select>

在`AddressMapperTests`中测试：

	@Test
	public void findByUid() {
		Integer uid = 18;
		List<Address> list = mapper.findByUid(uid);
		System.err.println("count=" + list.size());
		for (Address item : list) {
			System.err.println(item);
		}
	}

### 43. 收货地址-显示列表-业务层

**(a) 规划可能出现的异常**

无

**(b) 业务接口及抽象方法**

在`IAddressService`中添加：

	/**
	 * 查询某用户的收货地址列表
	 * @param uid 用户的id
	 * @return 该用户的收货地址列表
	 */
	List<Address> getByUid(Integer uid);

**(c) 实现抽象方法**

在`AddressServiceImpl`中实现：

	@Override
	public List<Address> getByUid(Integer uid) {
		List<Address> list = addressMapper.findByUid(uid);
		for (Address address : list) {
			address.setUid(null);
			address.setProvinceCode(null);
			address.setCityCode(null);
			address.setAreaCode(null);
			address.setIsDefault(null);
			address.setCreatedUser(null);
			address.setCreatedTime(null);
			address.setModifiedUser(null);
			address.setModifiedTime(null);
		}
		return list;
	}

在`AddressServiceTests`中测试：

	@Test
	public void getByUid() {
		Integer uid = 18;
		List<Address> list = service.getByUid(uid);
		System.err.println("count=" + list.size());
		for (Address item : list) {
			System.err.println(item);
		}
	}

### 44. 收货地址-显示列表-控制器层

**(a) 处理新创建的异常**

无

**(b) 设计所需要处理的请求**

	请求路径：/addresses/
	请求参数：HttpSession session
	请求方式：GET
	响应结果：JsonResult<List<Address>>

**(c) 处理请求**

	// http://localhost:8080/addresses
	@GetMapping("")
	public JsonResult<List<Address>> getByUid(HttpSession session) {
		Integer uid = getUidFromSession(session);
		List<Address> data = addressService.getByUid(uid);
		return new JsonResult<>(OK, data);
	}

### 45. 收货地址-显示列表-前端页面

### 46. 收货地址-设置默认-持久层

**(a) 规划所需要执行的SQL语句**

如果需要将某条收货地址设置为默认，需要执行的SQL语句大致是：

	update t_address set is_default=1, modified_user=?, modified_time=? where aid=?

除了将这条收货地址设置为默认，还应该将原来默认的收货地址设置为非默认！这项操作应该在以上“设置默认”之前执行，需要执行的SQL语句大致是：

	update t_address set is_default=0 where uid=?

另外，在执行更新之前，还应该检查被设置默认的收货地址是否存在，及数据归属是否正确！需要执行的SQL语句大致是：

	select * from t_address where aid=?

**(b) 接口与抽象方法**

在`AddressMapper`中添加：

	/**
	 * 将指定的收货地址设置为默认
	 * @param aid 收货地址的id
	 * @param modifiedUser 修改执行人
	 * @param modifiedTime 修改时间
	 * @return 受影响的行数
	 */
	Integer updateDefaultByAid(
			@Param("aid") Integer aid, 
			@Param("modifiedUser") String modifiedUser, 
			@Param("modifiedTime") Date modifiedTime);

	/**
	 * 将某用户的收货地址全部设置为非默认
	 * @param uid 用户id
	 * @return 受影响的行数
	 */
	Integer updateNonDefaultByUid(Integer uid);

	/**
	 * 根据收货地址id查询收货地址详情
	 * @param aid 收货地址id
	 * @return 匹配的收货地址详情，如果没有匹配的数据，则返回null
	 */
	Address findByAid(Integer aid);

**(c) 配置映射**

在**AddressMapper.xml**中配置映射：

	<!-- 将指定的收货地址设置为默认 -->
	<!-- Integer updateDefaultByAid(
			@Param("aid") Integer aid, 
			@Param("modifiedUser") String modifiedUser, 
			@Param("modifiedTime") Date modifiedTime) -->
	<update id="updateDefaultByAid">
		UPDATE
			t_address
		SET
			is_default=1,
			modified_user=#{modifiedUser},
			modified_time=#{modifiedTime}
		WHERE
			aid=#{aid}
	</update>
	
	<!-- 将某用户的收货地址全部设置为非默认 -->
	<!-- Integer updateNonDefaultByUid(Integer uid) -->
	<update id="updateNonDefaultByUid">
		UPDATE
			t_address
		SET
			is_default=0
		WHERE
			uid=#{uid}
	</update>

	<!-- 根据收货地址id查询收货地址详情 -->
	<!-- Address findByAid(Integer aid) -->
	<select id="findByAid"
		resultMap="AddressEntityMap">
		SELECT
			*
		FROM
			t_address
		WHERE
			aid=#{aid}
	</select>

在`AddressMapperTests`中测试：

	@Test
	public void updateDefaultByAid() {
		Integer aid = 28;
		String modifiedUser = "默认管理员";
		Date modifiedTime = new Date();
		Integer rows = mapper.updateDefaultByAid(aid, modifiedUser, modifiedTime);
		System.err.println("rows=" + rows);
	}
	
	@Test
	public void updateNonDefaultByUid() {
		Integer uid = 18;
		Integer rows = mapper.updateNonDefaultByUid(uid);
		System.err.println("rows=" + rows);
	}

	@Test
	public void findByAid() {
		Integer aid = 26;
		Address result = mapper.findByAid(aid);
		System.err.println(result);
	}

### 47. 收货地址-设置默认-业务层

**(a) 规划可能出现的异常**

在执行设置默认之前，应该先检查数据是否存在，如果不存在，则抛出`AddressNotFoundException`；

还需要判断数据归属是否正确，如果不正确，则抛出`AccessDeniedException`；

最终将执行更新数据的操作，则可能抛出`UpdateException`；

则需要创建`AddressNotFoundException`和`AccessDeniedException`！

**(b) 业务接口及抽象方法**

在`IAddressService`接口中添加抽象方法：

	void setDefault(Integer aid, Integer uid, String username);

**(c) 实现抽象方法**

在`AddressServiceImpl`中实现：

	@Transactional
	public void setDefault(Integer aid, Integer uid, String username) {
		// 根据参数aid查询收货地址数据
		// 判断查询结果是否为null
		// 是：AddressNotFoundException

		// 判断查询结果中的uid与参数uid是否不一致
		// 是：AccessDeniedException

		// 将该用户的所有收货地址设置为非默认，并获取返回值
		// 判断返回值是否小于1
		// 是：UpdateException

		// 将指定的收货地址设置为默认，并获取返回值
		// 判断返回值是否不为1
		// 是：UpdateException
	}

具体代码：

	@Override
	@Transactional
	public void setDefault(Integer aid, Integer uid, String username) {
		// 根据参数aid查询收货地址数据
		Address result = addressMapper.findByAid(aid);
		// 判断查询结果是否为null
		if (result == null) {
			// 是：AddressNotFoundException
			throw new AddressNotFoundException(
				"设置默认收货地址失败！尝试访问的数据不存在！");
		}

		// 判断查询结果中的uid与参数uid是否不一致
		if (!result.getUid().equals(uid)) {
			// 是：AccessDeniedException
			throw new AccessDeniedException(
				"设置默认收货地址失败！非法访问已经被拒绝！");
		}

		// 将该用户的所有收货地址设置为非默认，并获取返回值
		Integer rows = addressMapper.updateNonDefaultByUid(uid);
		// 判断返回值是否小于1
		if (rows < 1) {
			// 是：UpdateException
			throw new UpdateException(
				"设置默认收货地址失败[1]！更新收货地址数据时出现未知错误，请联系系统管理员！");
		}

		// 将指定的收货地址设置为默认，并获取返回值
		rows = addressMapper.updateDefaultByAid(aid, username, new Date());
		// 判断返回值是否不为1
		if (rows != 1) {
			// 是：UpdateException
			throw new UpdateException(
				"设置默认收货地址失败[2]！更新收货地址数据时出现未知错误，请联系系统管理员！");
		}
	}

然后，在`AddressServiceImpl`中测试：

	@Test
	public void setDefault() {
		try {
			Integer aid = 25;
			Integer uid = 18;
			String username = "收货地址管理员";
			service.setDefault(aid, uid, username);
			System.err.println("OK.");
		} catch (ServiceException e) {
			System.err.println(e.getClass().getName());
			System.err.println(e.getMessage());
		}
	}

### 48. 收货地址-设置默认-控制器层

**(a) 处理新创建的异常**

需要处理2个新的异常！

**(b) 设计所需要处理的请求**

	// SpringMVC框架是支持RESTful的
	请求路径：/addresses/{aid}/set_default
	请求参数：@PathVariable("aid") Integer aid, HttpSession session
	请求方式：GET/POST
	响应结果：JsonResult<Void>

**(c) 处理请求**

	// http://localhost:8080/addresses/21/set_default
	@RequestMapping("{aid}/set_default")
	public JsonResult<Void> setDefault(
			@PathVariable("aid") Integer aid,
			HttpSession session) {
		Integer uid = getUidFromSession(session);
		String username = getUsernameFromSession(session);
		addressService.setDefault(aid, uid, username);
		return new JsonResult<>(OK);
	}

### 49. 收货地址-设置默认-前端页面

















### -----------------------------------

### 附1：关于事务(Transaction)

事务是数据库领域中，能保证同一个业务中需要执行的多次增删改操作全部成功或全部失败的机制！

在基于SpringJDBC的开发模式下，对业务方法添加`@Transactional`注解，即可表示“该业务方法中将执行的多次增删改操作将以事务的方式执行”，可以达到“全部执行成功”或“全部执行失败”的效果！

框架在处理时，大致是：

	开启事务：begin
	try {
		执行若干次增删改操作
		提交事务：commit
	} catch(RuntimeException ex) {
		回滚事务：rollback
	}
	
所以，在编写代码时，必须做到：

1. 凡执行增、删、改操作，应该及时获取返回的受影响的行数，并判断受影响的行数是否与预期值相符，如果不相符，应该抛出`RuntimeException`或其子孙类异常；

2. 如果某个业务涉及超过1次的增、删、改操作(例如2次Update操作，或1次Insert加1次Delete操作)，则必须在业务方法之前添加`@Transactional`注解；

另外，`@Transactional`注解也可以添加在业务类的声明之前，则整个类的所有方法在执行时都是有事务保障的，但是，并不推荐这样使用！

关于事务，还应该了解它的**ACID特性**、**事务的传播**、**事务的隔离**。
