### 50. 收货地址-删除-持久层

**(a) 规划所需要执行的SQL语句**

删除收货地址需要执行的SQL语句大致是：

	delete from t_address where aid=?

在执行删除之前，还应该检查数据是否存在、数据归属是否正确，相关功能已经完成，无需重复开发！

如果删除的是默认收货地址，基于“每个用户始终有且仅有1条默认收货地址”的数据规则，还需要考虑“自动将剩余的某条收货地址设置为默认”，到底是哪一条，可以添加规则“将最后修改的收货地址设置为默认”，那么，就需要找出“最后修改的收货地址”，需要执行的SQL语句大致是：

	select * from t_address where uid=? order by modified_time desc limit 0,1

同时，如果用户删除的是默认收货地址，但是，这也是该用户的最后一条收货地址，则不需要执行以上操作！可以通过此前已经完成的`countByUid()`来实现！

最后，如果需要将剩余的某条收货地址设置为默认，可以直接通过此前已经完成的`updateDefaultByAid()`来实现！

**(b) 接口与抽象方法**

在`AddressMapper`接口中添加：

	Integer deleteByAid(Integer aid);

	Address findLastModifiedByUid(Integer uid);

**(c) 配置映射**

映射：

	<!-- 根据收货地址id删除数据 -->
	<!-- Integer deleteByAid(Integer aid) -->
	<delete id="deleteByAid">
		DELETE FROM 
			t_address 
		WHERE 
			aid=#{aid}
	</delete>

	<!-- 查询某用户最后修改的收货地址 -->
	<!-- Address findLastModifiedByUid(Integer uid) -->
	<select id="findLastModifiedByUid"
		resultMap="AddressEntityMap">
		SELECT
			*
		FROM
			t_address
		WHERE
			uid=#{uid}
		ORDER BY
			modified_time DESC
		LIMIT 0,1
	</select>

测试：

	@Test
	public void deleteByAid() {
		Integer aid = 25;
		Integer rows = mapper.deleteByAid(aid);
		System.err.println("rows=" + rows);
	}

	@Test
	public void findLastModifiedByUid() {
		Integer uid = 18;
		Address result = mapper.findLastModifiedByUid(uid);
		System.err.println(result);
	}

### 51. 收货地址-删除-业务层

**(a) 规划可能出现的异常**

需要创建`DeleteException`。

**(b) 业务接口及抽象方法**

在`IAddressService`中添加：

	void delete(Integer aid, Integer uid, String username);

**(c) 实现抽象方法**

在`AddressServiceImpl`中实现抽象方法，分析步骤：

	@Transactional
	public void delete(Integer aid, Integer uid, String username) {
		// 根据aid查询收货地址数据
		// 判断查询结果是否为null
		// 是：AddressNotFoundException

		// 判断查询结果中的uid与参数uid是否不同
		// 是：AccessDeniedException

		// 执行删除，并获取返回值
		// 判断返回值是否不为1
		// 是：DeleteException

		// 判断查询结果(对应刚刚删除的数据)中的isDefault是否不为1
		// return;

		// 统计当前用户还有多少收货地址
		// 判断统计结果是否为0
		// return;

		// 查询当前用户的最后修改的那一条收货地址
		// 从本次查询中取出数据的aid
		// 执行设置默认收货地址，获取返回值
		// 判断返回值是否不为1
		// 是：UpdateException
	}

代码：

	@Override
	@Transactional
	public void delete(Integer aid, Integer uid, String username) {
		// 根据参数aid查询收货地址数据
		Address result = addressMapper.findByAid(aid);
		// 判断查询结果是否为null
		if (result == null) {
			// 是：AddressNotFoundException
			throw new AddressNotFoundException(
				"设置默认收货地址失败！尝试访问的数据不存在！");
		}

		// 判断查询结果中的uid与参数uid是否不一致
		// 注意：对比Integer类型的值时，如果值的范围在 -128~127 之间，使用==或!=或equals()均可，如果超出这个范围，必须使用equals()
		if (!result.getUid().equals(uid)) {
			// 是：AccessDeniedException
			throw new AccessDeniedException(
				"设置默认收货地址失败！非法访问已经被拒绝！");
		}
		
		// 执行删除，并获取返回值
		Integer rows = addressMapper.deleteByAid(aid);
		// 判断返回值是否不为1
		if (rows != 1) {
			// 是：DeleteException
			throw new DeleteException(
				"删除收货地址失败！删除收货地址数据时出现未知错误，请联系系统管理员！");
		}

		// 判断查询结果(对应刚刚删除的数据)中的isDefault是否不为1
		if (result.getIsDefault() != 1) {
			return;
		}

		// 统计当前用户还有多少收货地址
		Integer count = addressMapper.countByUid(uid);
		// 判断统计结果是否为0
		if (count == 0) {
			return;
		}

		// 查询当前用户的最后修改的那一条收货地址
		Address address = addressMapper.findLastModifiedByUid(uid);
		// 从本次查询中取出数据的aid
		Integer lastModifiedAid = address.getAid();
		// 执行设置默认收货地址，获取返回值
		rows = addressMapper.updateDefaultByAid(lastModifiedAid, username, new Date());
		// 判断返回值是否不为1
		if (rows != 1) {
			// 是：UpdateException
			throw new UpdateException(
				"设置默认收货地址失败！更新收货地址数据时出现未知错误，请联系系统管理员！");
		}
	}

测试：

	@Test
	public void delete() {
		try {
			Integer aid = 30;
			Integer uid = 18;
			String username = "收货地址管理员";
			service.delete(aid, uid, username);
			System.err.println("OK.");
		} catch (ServiceException e) {
			System.err.println(e.getClass().getName());
			System.err.println(e.getMessage());
		}
	}

### 52. 收货地址-删除-控制器层

**(a) 处理新创建的异常**

需要处理`DeleteException`。

**(b) 设计所需要处理的请求**

	请求路径：/addresses/{aid}/delete
	请求参数：@PathVariable("aid") Integer aid, HttpSession session
	请求方式：GET/POST
	响应结果：JsonResult<Void>

**(c) 处理请求**

	// http://localhost:8080/addresses/21/delete
	@RequestMapping("{aid}/delete")
	public JsonResult<Void> delete(
			@PathVariable("aid") Integer aid,
			HttpSession session) {
		Integer uid = getUidFromSession(session);
		String username = getUsernameFromSession(session);
		addressService.delete(aid, uid, username);
		return new JsonResult<>(OK);
	}

### 53. 收货地址-删除-前端页面

### 54. 商品-导入数据表

### 55. 商品-创建实体类

	/**
	 * 商品数据的实体类
	 */
	public class Product extends BaseEntity {
	
		private static final long serialVersionUID = -199568590252555336L;
	
		private Integer id;
		private Integer categoryId;
		private String itemType;
		private String title;
		private String sellPoint;
		private Long price;
		private Integer num;
		private String image;
		private Integer status;
		private Integer priority;
	
	}

### 56. 商品-热销排行列表-持久层

**(a) 规划所需要执行的SQL语句**

	select * from t_product where status=1 order by priority desc limit 0, 4

**(b) 接口与抽象方法**

创建`ProductMapper`接口，并在接口中添加：

	List<Product> findHotList();

**(c) 配置映射**

复制得到**ProductMapper.xml**，并配置映射：

	<mapper namespace="cn.tedu.store.mapper.ProductMapper">
	
		<resultMap id="ProductEntityMap"
			type="cn.tedu.store.entity.Product">
			<id column="id" property="id" />
			<result column="category_id" property="categoryId" />
			<result column="item_type" property="itemType" />
			<result column="sell_point" property="sellPoint" />
			<result column="created_user" property="createdUser" />
			<result column="created_time" property="createdTime" />
			<result column="modified_user" property="modifiedUser" />
			<result column="modified_time" property="modifiedTime" />
		</resultMap>
	
		<!-- 查询热销商品 -->
		<!-- List<Product> findHotList() -->
		<select id="findHotList"
			resultMap="ProductEntityMap">
			SELECT
				*
			FROM
				t_product
			WHERE
				status=1
			ORDER BY
				priority DESC
			LIMIT 0, 4
		</select>
	
	</mapper>

创建单元测试类`ProductMapperTests`，并测试：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class ProductMapperTests {
	
		@Autowired
		private ProductMapper mapper;
		
		@Test
		public void findHotList() {
			List<Product> list = mapper.findHotList();
			System.err.println("count=" + list.size());
			for (Product item : list) {
				System.err.println(item);
			}
		}
		
	}

### 57. 商品-热销排行列表-业务层

**(a) 规划可能出现的异常**

无

**(b) 业务接口及抽象方法**

创建`IProductService`接口，添加：

	List<Product> getHotList();

**(c) 实现抽象方法**

创建`ProductServiceImpl`类，实现以上接口，在类的声明之前添加`@Service`注解，在类中声明`@Autowired private ProductMapper productMapper;`持久层对象，然后，将持久层中的方法复制到当前业务层实现类中改为私有方法并实现，然后，重写接口中的抽象方法，直接调用私有方法实现即可：

	/**
	 * 处理商品数据的业务层实现类
	 */
	@Service
	public class ProductServiceImpl implements IProductService {
		
		@Autowired
		private ProductMapper productMapper;
	
		@Override
		public List<Product> getHotList() {
			List<Product> list =  findHotList();
			for (Product product : list) {
				product.setCategoryId(null);
				product.setItemType(null);
				product.setSellPoint(null);
				product.setNum(null);
				product.setStatus(null);
				product.setPriority(null);
				product.setCreatedUser(null);
				product.setCreatedTime(null);
				product.setModifiedUser(null);
				product.setModifiedTime(null);
			}
			return list;
		}
		
		/**
		 * 查询热销商品
		 * @return 热销商品列表
		 */
		private List<Product> findHotList() {
			return productMapper.findHotList();
		}
	
	}

创建`ProductServiceTests`测试类，并测试：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class ProductServiceTests {
	
		@Autowired
		private IProductService service;
		
		@Test
		public void getHotList() {
			List<Product> list = service.getHotList();
			System.err.println("count=" + list.size());
			for (Product item : list) {
				System.err.println(item);
			}
		}
		
	}

### 58. 商品-热销排行列表-控制器层

**(a) 处理新创建的异常**

无

**(b) 设计所需要处理的请求**

	请求路径：/products/hot
	请求参数：无
	请求方式：GET
	响应结果：JsonResult<List<Product>>
	是否拦截：否，需要在登录拦截器的配置中将 /products/** 添加为白名单

**(c) 处理请求**

在`cn.tedu.store.controller`包中创建`ProductController`控制器类，继承自`BaseController`，在类的声明之前添加`@RestController`注解，并添加`@RequestMapping("products")`，在类中声明`@Autowired private IProductService productService;`业务层对象！

然后，在类中添加处理请求的方法：

	/**
	 * 处理商品数据相关请求的控制器类
	 */
	@RestController
	@RequestMapping("products")
	public class ProductController extends BaseController {
	
		@Autowired
		private IProductService productService;
		
		// http://localhost:8080/products/hot
		@GetMapping("hot")
		public JsonResult<List<Product>> getHotList() {
			List<Product> data = productService.getHotList();
			return new JsonResult<>(OK, data);
		}
	}

### 59. 商品-热销排行列表-前端页面

### 【作业】60. 商品-显示详情-持久层

**(a) 规划所需要执行的SQL语句**

	select * from t_product where id=?

**(b) 接口与抽象方法**

	Product findById(Integer id);

**(c) 配置映射**

映射：

	...

测试：

	...

### 【作业】61. 商品-显示详情-业务层

**(a) 规划可能出现的异常**

创建`ProductNotFoundException`。

**(b) 业务接口及抽象方法**

	Product getById(Integer id);

**(c) 实现抽象方法**

先将持久层的方法复制到实现类，实现为私有方法：

	...

然后，重写接口中的抽象方法：

	... // 先检查数据是否存在，如果存在，在返回之前，将不希望响应给客户端的属性设置为null

测试：

	...

### 【作业】62. 商品-显示详情-控制器层

**(a) 处理新创建的异常**

处理`ProductNotFoundException`。

**(b) 设计所需要处理的请求**

	// http://localhost:8080/products/10000002/details
	请求路径：/products/{id}/details
	请求参数：@PathVariable("id") Integer id
	请求方式：GET
	响应结果：JsonResult<Product>

**(c) 处理请求**


