### 32. 收货地址-增加-前端页面

### 33. 省市区-导入数据表及数据

下载`t_dict_district.zip`得到SQL脚本，然后，登录MySQL控制台，使用`tedu_store`数据库，并执行

	source 脚本文件的路径

### 34. 省市区-创建实体类

在`cn.tedu.store.entity`下创建`District`类，实现`Serializable`接口：

	public class District implements Serializable {
		private Integer id;
		private String parent;
		private String code;
		private String name;
		// SET/GET/基于id的hashCode和equals/toString
	}

### 35. 省市区-获取列表-持久层

获取全国所有省/获取某省所有市/获取某市所有区时，需要执行的SQL语句是相同的，大致是：

	select * from t_dict_district where parent=? order by code

则在编写代码时，先在`cn.tedu.store.mapper`下创建`DistrictMapper`接口，并在接口中添加抽象方法：

	/**
	 * 处理省/市/区数据的持久层接口
	 */
	public interface DistrictMapper {
	
		/**
		 * 查询全国所有省/某省所有市/某市所有区的列表
		 * @param parent 父级单位的行政代号，如果需要查询全国所有省，则使用"86"作为父级代号
		 * @return 匹配的全国所有省/某省所有市/某市所有区的列表
		 */
		List<District> findByParent(String parent);
	
	}

在**src/main/resources/mappers**下将**AddressMapper.xml**复制，并得到**DistrictMapper.xml**，在**DistrictMapper.xml**中，删除原有配置代码，并配置以上抽象方法的映射：

	<mapper namespace="cn.tedu.store.mapper.DistrictMapper">
	
		<!-- 查询全国所有省/某省所有市/某市所有区的列表 -->
		<!-- List<District> findByParent(String parent) -->
		<select id="findByParent"
			resultType="cn.tedu.store.entity.District">
			SELECT
				*
			FROM
				t_dict_district
			WHERE
				parent=#{parent}
			ORDER BY
				code ASC
		</select>
	
	</mapper>

在**src/test/java**的`cn.tedu.store.mapper`下创建`DistrictMapperTests`测试类，在测试类的声明之前添加2项注解，并测试以上抽象方法的功能：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class DistrictMapperTests {
	
		@Autowired
		private DistrictMapper mapper;
		
		@Test
		public void findByParent() {
			String parent = "86";
			List<District> list = mapper.findByParent(parent);
			System.err.println("count=" + list.size());
			for (District item : list) {
				System.err.println(item);
			}
		}
		
	}

### 36. 省市区-获取列表-业务层

在`cn.tedu.store.service`包中创建`IDistrictService`业务接口，并在接口中添加抽象方法：

	/**
	 * 处理省/市/区数据的业务层接口
	 */
	public interface IDistrictService {
	
		/**
		 * 查询全国所有省/某省所有市/某市所有区的列表
		 * @param parent 父级单位的行政代号，如果需要查询全国所有省，则使用"86"作为父级代号
		 * @return 匹配的全国所有省/某省所有市/某市所有区的列表
		 */
		List<District> getByParent(String parent);
	
	}

在`cn.tedus.store.service.impl`包中创建`DistrictServiceImpl`业务实现类，实现以上接口，添加`@Service`注解，添加`@Autowired private DistrictMapper districtMapper;`持久层对象，并重写抽象方法：

	public List<District> getByParent(String parent) {
		// 调用持久层对象的查询，得到列表
		// 遍历查询到的列表
		// -- 将列表项的id和parent设置为null
		// 返回列表
	}

具体代码为：

	/**
	 * 处理省/市/区数据的业务层实现类
	 */
	@Service
	public class DistrictServiceImpl implements IDistrictService {
		
		@Autowired
		private DistrictMapper districtMapper;
	
		@Override
		public List<District> getByParent(String parent) {
			// 调用持久层对象的查询，得到列表
			List<District> list = districtMapper.findByParent(parent);
			// 遍历查询到的列表
			for (District district : list) {
				// 将列表项的id和parent设置为null
				district.setId(null);
				district.setParent(null);
			}
			// 返回列表
			return list;
		}
	
	}

最后，在**src/test/java**的`cn.tedu.store.service`下创建`DistrictServiceTests`测试类，在测试类的声明之前添加2项注解，并测试以上抽象方法的功能：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class DistrictServiceTests {
	
		@Autowired
		private IDistrictService service;
		
		@Test
		public void getByParent() {
			String parent = "86";
			List<District> list = service.getByParent(parent);
			System.err.println("count=" + list.size());
			for (District item : list) {
				System.err.println(item);
			}
		}
		
	}

### 37. 省市区-获取列表-控制器层

关于需要处理的请求：

	请求路径：/districts/
	请求参数：String parent
	请求方式：GET
	响应结果：JsonResult<List<District>>
	是否拦截：否，不需要登录就可以访问

由于不需要拦截，所以，先在拦截器的配置类`InterceptorConfigurer`类中添加`/district/**`到白名单！

先在`cn.tedu.store.controller`包中创建`DistrictController`类，继承自`BaseController`，在类的声明之前添加`@RestController`和`@RequestMapping("districts")`注解，并在类中声明`@Autowired private IDistrictService districtService;`业务接口：

	/**
	 * 处理省/市/区数据相关请求的控制器类
	 */
	@RestController
	@RequestMapping("districts")
	public class DistrictController extends BaseController {
	
		@Autowired
		private IDistrictService districtService;
		
	}

然后，在类中添加处理请求的方法：

	// http://localhost:8080/districts/?parent=86
	@GetMapping({"", "/"})
	public JsonResult<List<District>> getByParent(String parent) {
		// 调用业务对象获取数据
		// 返回OK与数据
	}

### 38. 省市区-获取列表-前端页面

### 39. 省市区-根据行政代号获取名称-持久层

需要执行的SQL语句大致是：

	select name from t_dict_district where code=?

在`DistrictMapper`接口中添加抽象方法：

	/**
	 * 根据省/市/区的行政代号查询名称
	 * @param code 省/市/区的行政代号
	 * @return 匹配的省/市/区的名称，如果没有匹配的数据，则返回null
	 */
	String findNameByCode(String code);

在**DistrictMapper.xml**中配置映射：

	<!-- 根据省/市/区的行政代号查询名称 -->
	<!-- String findNameByCode(String code) -->
	<select id="findNameByCode"
		resultType="java.lang.String">
		SELECT
			name
		FROM
			t_dict_district
		WHERE
			code=#{code}
	</select>

在`DistrictMapperTests`中测试：

	@Test
	public void findNameByCode() {
		String code = "110000";
		String name = mapper.findNameByCode(code);
		System.err.println("name=" + name);
	}

### 40. 省市区-根据行政代号获取名称-业务层

在`IDistrictService`接口中添加：

	/**
	 * 根据省/市/区的行政代号查询名称
	 * @param code 省/市/区的行政代号
	 * @return 匹配的省/市/区的名称，如果没有匹配的数据，则返回null
	 */
	String getNameByCode(String code);

在`DistrictServiceImpl`类中实现以上方法：

	@Override
	public String getNameByCode(String code) {
		return districtMapper.findNameByCode(code);
	}

在`DistrictServiceTests`中测试：

	@Test
	public void getNameByCode() {
		String code = "110000";
		String name = service.getNameByCode(code);
		System.err.println("name=" + name);
	}

### 41. 收货地址-增加-业务-补

在增加收货地址的业务中，需要补全“根据已知的行政代号获取对应的名称”！

先在`AddressServiceImpl`中添加处理省市区数据的业务对象：

	@Autowired
	private IDistrictService districtService;

在插入收货地址数据之前，补充补全数据：

	String provinceCode = address.getProvinceCode();
	String provinceName = districtService.getNameByCode(provinceCode);
	address.setProvinceName(provinceName);
	String cityCode = address.getCityCode();
	String cityName = districtService.getNameByCode(cityCode);
	address.setCityName(cityName);
	String areaCode = address.getAreaCode();
	String areaName = districtService.getNameByCode(areaCode);
	address.setAreaName(areaName);

### 42. 收货地址-显示列表-持久层

显示某用户的收货地址列表，需要执行的SQL语句大致是：

	select * from t_address where uid=? order by is_default desc, modified_time desc

作业：参考“获取全国所有省”的功能，开发至控制器层，通过`http://localhost:8080/addresses`可以获取当前登录的用户的收货地址列表数据！









