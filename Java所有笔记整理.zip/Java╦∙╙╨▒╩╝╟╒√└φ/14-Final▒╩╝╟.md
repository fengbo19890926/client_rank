
# 1.数据结构
## (1)数据结构是什么?
计算机组织与存储数据的逻辑结构。

	常见的数据结构有数组、链表、队列、栈、散列表、二叉树。

## (2)双向循环链表

	双向循环链表由一系列节点构成。其中，每个节点包含两部分数据，
	分别是元素值和指向前驱节点和后继节点的指针。
	头节点和尾节点也彼此指向。

![](linkedlist2.png)

	1)public boolean add(E e)

![](add.png)

	2)public String toString()

![](toString.png)

	3)public E get(int index)

![](get.png)

	4)public E remove(int index)

![](remove.png)

	5)public void add(int index,E e)

![](add2.png)


## (3)链表与数组的区别

	数组：
		优点: 依据下标(索引)快速找到对应位置处的元素。
		缺点: 删除或者添加元素时需要对整个数组进行调整。

	链表:
		优点: 可以快速地添加或者删除元素。
		缺点: 只能顺序查找元素。


# 练习1
给双向循环链表添加一个add方法，该方法会将元素添加到链表的末尾。

	public boolean add(E e);

# 练习2
给双向循环链表添加一个get方法,该方法返回指定位置的节点的元素值。

	public E get(int index);

# 练习3
给双向循环链表添加一个remove方法,该方法删除指定位置的节点，并返回
删除的节点的元素值。

	public E remove(int index);

# 练习4
给双向循环链表添加一个add方法，该方法在指定位置添加一个新的节点。

	public void add(int index,E e);


