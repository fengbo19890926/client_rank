# Who am I.

刘苍松
VX: `cang_lao_shi`

# 二进制

## 什么2进制

10进制与2进制

![](bin.png)

数学理论上有 2 3 4 5 ... n进制, 计算为了节省成本设计为2进制.

Java提供了API, 解决了10进制与2进制直接的转换

![](bin2.png)

案例:

	public static void main(String[] args) {
		/*
		 * 2进制
		 */
		int n = 50; //110010
		System.out.println(n);//110010 -> "50"
		//显示n在内存中实际2进制存储情况
		System.out.println(
				Integer.toBinaryString(n));
		//显示0~100的2进制数字
		for(int i=0; i<=100; i++) {
			System.out.println(
					Integer.toBinaryString(i)); 
		}
	}


## 16进制

在计算机科学中采用16进制缩写2进制

1. 2进制数直接书写, 繁琐,复杂,易错
2. 16进制的基数是2进制基数的4次幂, 造成2进制可以4位缩写为1位16进制
3. 缩写规则: 2进制数从最低位到最高位,每4位数缩写为1位16进制

![](hex.png)

案例:

	public static void main(String[] args) {
		/*
		 * java 7 提供2进制直接量写法0b前缀
		 */
		int n = 0b110010;//50
		System.out.println(n);
		/*
		 * 2进制数直接书写, 繁琐,复杂,易错
		 * 16进制可以方便的缩写2进制
		 * Java 7 以前就是利用16进制缩写2进制
		 */
		n = 0b110100111010111111010001001101;
		int m = 0x34ebf44d;
		System.out.println(
				Integer.toBinaryString(n));
		System.out.println(
				Integer.toBinaryString(m));
		
	}


## 补码

补码是计算中为了解决"负数"问题设计的一种数字编码,期设计思路是将固定位数的2进制分一半作为负数的编码.

4位补码编码规则
1. 计算时候始终保持4位不变, 多出位数自动溢出舍弃
2. 将高位为0的数作为正数, 高位为1的作为负数
	- 将最高位称为符号位, 1时候是负数, 0 时候是正数, 符号位参与运算
3. 从0开始倒推负数编码
4. 补码是计算机底层编码. 与人交互时候进行转换

![](4.png)

案例:

	public static void main(String[] args) {
		int n = -3;
		System.out.println(
				Integer.toBinaryString(n)); 
		//验证补码的最大值
		int max = Integer.MAX_VALUE;
		long l  = Long.MAX_VALUE;
		System.out.println(max);
		System.out.println(l);
		System.out.println(
				Integer.toBinaryString(max)) ;
		System.out.println(
				Long.toBinaryString(l)); 
		
		//验证补码的最小值
		int min = Integer.MIN_VALUE;
		System.out.println(
				Integer.toBinaryString(min)); 
		min = 0x80000000;
		System.out.println(
				Integer.toBinaryString(min));
		
		int m = max+1;
		System.out.println(
				Integer.toBinaryString(m));
		
	}

负数不补码:

	public static void main(String[] args) {
		/**
		 * 1. 负数的补码
		 */
		int n = -1;
		System.out.println(
				Integer.toBinaryString(n)); 
		int m = -15;
		System.out.println(
				Integer.toBinaryString(m));
		
		for(int i=-100; i<0; i++) {
			System.out.println(
					Integer.toBinaryString(i)); 
		}
	}


互补对称现象:

1. 补码编码有互补对称现象(巧合), 不是补码的设计目的. 
2. 互补对称公式 -n = ~n + 1, 最小值除外

![](5.png)

栗子:

	00000000000000000000000000001000    8    8
	11111111111111111111111111110111   ~8   -9
	11111111111111111111111111111000   ~8+1 -8

案例:

	public static void main(String[] args) {
		/**
		 * -n=~n+1 验证补码的互补对称公式
		 */
		int n = 8;
		int m = ~n+1;
		System.out.println(m); 
		//验证过程
		System.out.println(
				Integer.toBinaryString(n));
		System.out.println(
				Integer.toBinaryString(~n));
		System.out.println(
				Integer.toBinaryString(~n+1));
		
	}

经典面试题目: 

	System.out.println(~80+1); 
	如上代码的输出结果( B ) A.-79 B.-80 C.-81 D.-82
	
	System.out.println(~-80+1); 
	如上代码的输出结果( B ) A.79 B.80 C.81 D.82

	System.out.println(~-80); 
	如上代码的输出结果( A ) A.79 B.80 C.81 D.82

> 记住: 整数编码(int long) 是环形编码. 

## 2进制运算

运算符(按位运算):

	~ 取反
	& 与运算
	| 或运算
	>>> 右移位运算
	>>  数学右移位运算
	<<  左移位运算

### & 与运算(逻辑乘法)

基本规则: 有0则0
	
	0 & 0 = 0
	0 & 1 = 0
	1 & 0 = 0
	1 & 1 = 1

计算时候两个数字对齐位数, 对应位进行与计算

举个例子:

	n  =       01110100 00110011 11110101 01100101
	m  =       00000000 00000000 00000000 11111111  面具 mask
	k=n&m      00000000 00000000 00000000 01100101 

如上运算的意义: 经过如上运算k中的数据是n的最后8位数. 这个计算称为掩码(Mask 面具)计算. 其中m称为掩码(Mask), 惯例按照从低位到高位的1的个数称呼掩码:m是8位掩码.

代码:

	public static void main(String[] args) {
		/**
		 * & 掩码计算
		 */
		int n = 0x7433f565;
		int m = 0xff;
		int k = n&m;
		System.out.println(
				Integer.toBinaryString(n));
		System.out.println(
				Integer.toBinaryString(m));
		System.out.println(
				Integer.toBinaryString(k));
  
	}

### 经典案例: 将一个整数拆分为4个byte

例子

				  b1       b2       b3       b4
	n  =       01110100 00110011 11110101 01100101
	b1 =       00000000 00000000 00000000 01110100 
	b2 =       00000000 00000000 00000000 00110011
	b3 =       00000000 00000000 00000000 11110101
	b4 =       00000000 00000000 00000000 01100101

	b1=(n>>>24)&0xff
	b2=(n>>>16)&0xff
	b3=(n>>>8)&0xff
	b4=n&0xff   

代码:

	int n = 0x7433f565;
	int b1 = (n>>>24) & 0xff;
	int b2 = (n>>>16) & 0xff;
	int b3 = (n>>>8) & 0xff;
	int b4 = (n>>>0) & 0xff;
	
### 右移位计算 `>>>`

运算规则: 将2进制数字的整体向右移动, 低位多出的位数自动溢出, 高位补0

举个栗子: 

	n =       01110100 00110011 11110101 01100101
	m =n>>>1  001110100 00110011 11110101 0110010
	k =n>>>2  0001110100 00110011 11110101 011001
	i =n>>>8  00000000 01110100 00110011 11110101 
	b3=(n>>>8)&0xff

代码:

	int n = 0x7433f565;
	int m = n>>>1;
	int k = n>>>2;
	int i = n>>>8;
	int b3 = (n>>>8) & 0xff;
	//按照2进制输出 n m k i b3 
	
### 将4个byte数据合并为一个int

栗子:

	b1 =         00000000 00000000 00000000 11110111
	b2 =         00000000 00000000 00000000 11000010
	b3 =         00000000 00000000 00000000 10111101
	b4 =         00000000 00000000 00000000 10011111

	b1<<24       11110111 00000000 00000000 00000000
	b2<<16       00000000 11000010 00000000 00000000 
	b3<<8        00000000 00000000 10111101 00000000
	b4 =         00000000 00000000 00000000 10011111
	n  =         11110111 11000010 10111101 10011111
	                b1       b2       b3       b4
	int n = (b1<<24)|(b2<<16)|(b3<<8)|b4        

代码:
	
	int b1 = 0xf7;
	int b2 = 0xc2;
	int b3 = 0xbd;
	int b4 = 0x9f;
	int n = (b1<<24)|(b2<<16)|(b3<<8)|b4;
	//按照2进制输出 b1 b2 b3 b4 b1<<24 b2<<16 b3<<8 b4 n
	
### 或运算 | (逻辑加法)

基本规则: 有1则1

	0 | 0 = 0
	0 | 1 = 1
	1 | 0 = 1
	1 | 1 = 1

计算时候需要将两个数字对齐位数, 对应位置计算或

栗子:

	n=       00000000 00000000 00000000 10011110
	m=       00000000 00000000 11011110 00000000
	k=n|m    00000000 00000000 11011110 10011110

如上运算的意义: n和m拼接为k

代码:
	
	请自行补充实验代码.

### 移位计算的数学意义

左移位: 2进制数字每向左移移动一位,数值乘法2.
右移位: 2进制数字每向右移移动一位,数值除以2.

举个栗子:

	n =    00000000 00000000 00000000 00110010   50
	m=n<<1 0000000 00000000 00000000 001100100  100 
    k=n<<2 000000 00000000 00000000 0011001000  200  
	
代码:

	int n = 50;
	int m = n<<1;
	int k = n<<2;
	//按照10进制输出, 50 100 200 

代码:
	
	请自行补充实验代码.

经典面试:

	优化计算: n*8 可以 替换为 (    ) 答案: n<<3 
	//提示: 被乘数是2的整次幂.

	int n = 9;
	n *= 1.5  可以替换为 n += n>>1; 

代码:
	
	请自行补充实验代码进行测试.

### `>>` 和 `>>>` 的区别 

`>>`  数学右移位计算: 正数时候,高位补0,负数时候高位补1, 结果是数值除以2, 向小方向取整数

`>>>` 逻辑右移位计算: 高位总是补0, 不是数学结果, 目的是数字整体向右移动. 

用途: 如果用于替代数学计算,请使用`>>` 如果是单纯将数位右移动使用`>>>`

举个栗子:

	n =         11111111 11111111 11111111 11001110  -50
	m = n>>1    111111111 11111111 11111111 1100111  -25
	k = n>>2    1111111111 11111111 11111111 110011  -13 
	g = n>>>1   011111111 11111111 11111111 1100111  比最大值少24

代码:
	
	请自行补充实验代码.
	
