# Servlet

## 过滤器

什么是过滤器

1. Java Web API
2. 可以过滤拦截Web请求
3. 可以在拦截时候增加业务逻辑

栗子: 防止图片盗链

1. 网页/浏览器天生支持跨服务器下载资源, 可以提高网页加载效率,提高网站并发性能.
2. 一些敏感资源跨站下载就有安全问题了!

![](1.png)

如何使用过滤器

1. 创建过滤器类, 必须实现Filter接口
2. 核心方法 doFilter 中添加业务规则
3. 将过滤器类配置到 web.xml 上
4. web请求发起时候,就会执行doFilter

过滤器工作原理:

![](2.png)

案例DemoFilter:

1. 编写过滤器类:

		public class DemoFilter implements Filter {
		
			@Override
			public void init(FilterConfig filterConfig) throws ServletException {
			}
		
			@Override
			public void doFilter(
					ServletRequest request, 
					ServletResponse response, 
					FilterChain chain)
					throws IOException, ServletException {
				System.out.println("Hello");
				//放过请求,进行后续资源处理
				chain.doFilter(request, response);
				System.out.println("World!"); 
			}
		
			@Override
			public void destroy() {
			}
			
		}

2. 配置:
		
		<filter>
			<filter-name>demo</filter-name>
			<filter-class>cn.tedu.web.DemoFilter</filter-class>
		</filter>
		<filter-mapping>
			<filter-name>demo</filter-name>
			<url-pattern>/photo/img.png</url-pattern>
		</filter-mapping>

3. 准备图片素材: /photo/img.png 放到 webapp文件夹
4. 测试.

实现登录才能看图片功能:

1. 编写过滤器类:

		/*
		 * 访问控制过滤器:
		 * 1. 如果没有登录就重定向到登录页面
		 * 2. 如果登录过就放过资源请求
		 */
		public class AccessFilter implements Filter {
		
			@Override
			public void init(FilterConfig filterConfig) throws ServletException {
			}
		
			@Override
			public void doFilter(
					ServletRequest request, 
					ServletResponse response, 
					FilterChain chain)
					throws IOException, ServletException {
				HttpServletRequest req =
						(HttpServletRequest)request;
				HttpServletResponse res =
						(HttpServletResponse)response;
				//获取用户的登录信息
				HttpSession session=req.getSession();
				User user=
					(User)session.getAttribute("user");
				if(user==null) {
					//重定向到登录页面
					System.out.println("没有登录,重定向到登录页面");
					String path = req.getContextPath()+
							"/ShowLoginServlet";
					res.sendRedirect(path);
					return;
				}
				System.out.println("已经登录,放过请求");
				chain.doFilter(request, response); 
			}
		
			@Override
			public void destroy() {
			}
			
		}

2. 配置:

		<filter>
			<filter-name>access</filter-name>
			<filter-class>cn.tedu.web.AccessFilter</filter-class>
		</filter>
		<filter-mapping>
			<filter-name>access</filter-name>
			<url-pattern>/photo/img.png</url-pattern>
		</filter-mapping>

3. 测试

配置Filter规则:

1. 可以写多个 filter-mapping

		<filter>
			<filter-name>access</filter-name>
			<filter-class>cn.tedu.web.AccessFilter</filter-class>
		</filter>
		<filter-mapping>
			<filter-name>access</filter-name>
			<url-pattern>/photo/img.png</url-pattern>
		</filter-mapping>
		<filter-mapping>
			<filter-name>access</filter-name>
			<url-pattern>/photo/demo.png</url-pattern>
		</filter-mapping>

2. 可以写多个 url-pattern

		<filter>
			<filter-name>access</filter-name>
			<filter-class>cn.tedu.web.AccessFilter</filter-class>
		</filter>
		<filter-mapping>
			<filter-name>access</filter-name>
			<url-pattern>/photo/img.png</url-pattern>
			<url-pattern>/photo/demo.png</url-pattern>
		</filter-mapping>

3. 可以使用规则:

		<filter>
			<filter-name>access</filter-name>
			<filter-class>cn.tedu.web.AccessFilter</filter-class>
		</filter>
		<filter-mapping>
			<filter-name>access</filter-name>
			<url-pattern>/photo/*</url-pattern>
		</filter-mapping>

4. url-pattern 规则:
	1. 全路径匹配 /photo/img.png,  /photo/index.html
	2. 路径匹配:  `/photo/*`,  `/user/*`, `/login/*`
	3. 后缀匹配:  `*.css` , `*.png` , `*.do`, `*.html`
	4. 全匹配: `/*`
	5. 路径匹配不能和后缀匹配同时使用!!! 

过滤器的常见用途:

1. 权限检查(如:防止图片盗链)
2. 日志记录,如:记录用户的访问行为
3. 编码过滤器

# Spring

Spring 春天 

Spring 框架

1. 由一系列组件组成的框架, 是软件的半成品, 包含了软件常用组件,可以作为软件的基石快速搭建开发软件.
2. 其核心功能: IOC(控制反转) AOP(面向切面儿编程)
3. 使用Spring 必须遵守Spring约定的规则

## IOC控制反转

控制反转: 相对主动控制管理对象而言, 将对象的控制交给容器控制的现象叫控制反转.

Spring 核心功能IOC, 可以帮助我们管理对象, 使用者只需要从Spring得到对象, 然后使用对象. 

测试SpringIOC功能:

1. 导入Spring
2. 创建一个类
3. 编写配置文件: 将类名告诉Spring
4. 启动Spring, Spring会自动创建管理对象
5. 通过Spring获得对象, 测试对象

> Maven 仓库搜索网站 https://mvnrepository.com/

Spring HelloWorld

1. 创建Mavne项目, 导入Spring组件:

		<dependencies>
			<dependency>
				<groupId>org.springframework</groupId>
				<artifactId>spring-context</artifactId>
				<version>4.3.24.RELEASE</version>
			</dependency>
			<dependency>
				<groupId>junit</groupId>
				<artifactId>junit</artifactId>
				<version>4.12</version>
			</dependency>
		</dependencies>

2. 创建被管理的类

		public class DemoBean {
		
			public String toString() {
				return "Hello World!";
			}
		}

3. 编写配置文件

		<?xml version="1.0" encoding="UTF-8"?>
		<beans xmlns="http://www.springframework.org/schema/beans" 
			xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
			xmlns:context="http://www.springframework.org/schema/context" 
			xmlns:jdbc="http://www.springframework.org/schema/jdbc"  
			xmlns:jee="http://www.springframework.org/schema/jee" 
			xmlns:tx="http://www.springframework.org/schema/tx"
			xmlns:aop="http://www.springframework.org/schema/aop" 
			xmlns:mvc="http://www.springframework.org/schema/mvc"
			xmlns:util="http://www.springframework.org/schema/util"
			xmlns:jpa="http://www.springframework.org/schema/data/jpa"
			xsi:schemaLocation="
				http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.2.xsd
				http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-3.2.xsd
				http://www.springframework.org/schema/jdbc http://www.springframework.org/schema/jdbc/spring-jdbc-3.2.xsd
				http://www.springframework.org/schema/jee http://www.springframework.org/schema/jee/spring-jee-3.2.xsd
				http://www.springframework.org/schema/tx http://www.springframework.org/schema/tx/spring-tx-3.2.xsd
				http://www.springframework.org/schema/data/jpa http://www.springframework.org/schema/data/jpa/spring-jpa-1.3.xsd
				http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop-3.2.xsd
				http://www.springframework.org/schema/mvc http://www.springframework.org/schema/mvc/spring-mvc-3.2.xsd
				http://www.springframework.org/schema/util http://www.springframework.org/schema/util/spring-util-3.2.xsd">
			
			<bean id="demo" class="demo.DemoBean"></bean>
		</beans>

4. 编写测试类:

		public class Test {
		
			public static void main(String[] args) {
				//创建Spring容器
				ClassPathXmlApplicationContext ctx=
					new ClassPathXmlApplicationContext(
					"applicationContext.xml");
				//从Spring容器中获取被管理的对象
				DemoBean bean=
					(DemoBean)ctx.getBean("demo");
				//输出对象时候,自动调用其toString() 
				System.out.println(bean);
			}
		}


## Java Bean 

Spring建议被管理的对象是JavaBean对象. Spring 可宽泛的支持任何Java对象.

Java Bean : 符合一定规范的Java对象

1. 有Package
2. 有无参数构造器
3. 实现序列化接口
4. 可以使用getXxx/setXxx定义"Bean属性"
	1. 可以利用开发工具自动生成

Bean属性: 是指getXxx和setXxx, bean属性名xxx

对象属性: 是指对象的实例变量

举个例子:

	class Person{
		String name; //实例变量, 对象属性
		String getName(){ //Bean属性, 属性名 name
			return name;
		}
		void setName(String name){
			this.name=name;
		}
	}

## Spring IOC 容器提供了丰富的Bean管理功能

Spring为了支持任何软件, 提供丰富的Bean对象管理功能.

### 单例

单例: 软件运行期间只有唯一不变的一个实例.

Spring默认情况下按照单例规则管理对象

测试:

	public class TestCase {
		ClassPathXmlApplicationContext ctx;
		@Before //在...之前, 在测试案例之前
		public void init() {
			System.out.println("init");
			ctx=new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		}
		@After //在...之后, 在测试案例之后
		public void destroy() {
			System.out.println("destroy");
			ctx.close();
		}
		@Test
		public void testDemoBean() {
			DemoBean bean = (DemoBean)
					ctx.getBean("demo");
			System.out.println(bean); 
		}
		@Test
		public void testSingleton() {
			// 单例测试
			DemoBean bean1 = 
				(DemoBean)ctx.getBean("demo");
			DemoBean bean2 = 
				(DemoBean)ctx.getBean("demo");
			System.out.println(bean1==bean2);
		}
		
	}

多个实例测试:

1. 编写配置文件:

		<!-- 设置了属性 scope="prototype"
		以后就是多个实例,每次使用对象时候
		都会创建一个新的实例 -->
		<bean id="demo2" scope="prototype"  
			class="demo.DemoBean"></bean>	
	
2. 测试:

		@Test
		public void testPrototype() {
			// 多例测试
			DemoBean bean1 = 
				(DemoBean)ctx.getBean("demo2");
			DemoBean bean2 = 
				(DemoBean)ctx.getBean("demo2");
			System.out.println(bean1==bean2);
		}
		