# Spring

## 关于Spring的概念

对象容器: 集合

Web容器, Servlet容器: Java Web 服务器

Java Bean 容器, Bean容器, IOC容器, Spring容器: Spring IOC 

# 注解

Spring支持注解方式声明Bean组件, 这种方式的好处是可以利用编译期对注解进行检查, 减少错误的发生.

## 利用注解创建Bean组件

1. 创建项目, 导入Spring

		<dependency>
			<groupId>org.springframework</groupId>
			<artifactId>spring-context</artifactId>
			<version>4.3.24.RELEASE</version>
		</dependency>
		<dependency>
			<groupId>junit</groupId>
			<artifactId>junit</artifactId>
			<version>4.12</version>
		</dependency>
		<dependency>
			<groupId>mysql</groupId>
			<artifactId>mysql-connector-java</artifactId>
			<version>5.1.6</version>
		</dependency>
		<!-- 数据库连接池坐标 -->
		<dependency>
			<groupId>commons-dbcp</groupId>
			<artifactId>commons-dbcp</artifactId>
			<version>1.4</version>
		</dependency>

2. 在配置文件中开启组件扫描

		<!-- 开启组件扫描功能: Spring会递归
		扫描cn.tedu.beans包中的全部类, 查找
		相关注解, 如果找到就将注解标注的类
		创建为Java Bean对象. -->
		<context:component-scan 
			base-package="cn.tedu.beans"/>
	
3. 在被扫描到的包中声明类!

		@Component
		public class DemoBean {
		
			@Override
			public String toString() {
				return "Hello World!";
			}
		}

4. 测试:

		public class TestCase {
			ClassPathXmlApplicationContext ctx;
			@Before
			public void init() {
				ctx=new ClassPathXmlApplicationContext("beans1.xml");
			}
			@After
			public void destroy() {
				ctx.close();
			}	
			@Test
			public void testDemoBean() {
				/*
				 * 测试利用注解声明的Bean组件
				 */
				DemoBean bean = ctx.getBean(
						"demoBean", DemoBean.class);
				System.out.println(bean);
			}
		}

## 注解有4个

- @Component  组件, 用于标注通用组件
- @Repository 仓储, 用于标注存储组件
- @Service    服务, 用于标注业务功能组件
- @Controller 控制器, 用于标注控制器组件

功能相同, 但是"语义"不同, 建议按照语义使用, 目的是写出"人能够看懂的代码"!

## 懒惰加载

默认时候组采用立即初始化方式, 也就是Spring容器启动时候立即创建Bean对象, 标注 @Lazy 注解后采用懒惰方式创建对象, 也就是使用时候才创建对象.

案例:

	@Component
	@Lazy
	public class DemoBean {
		
		public DemoBean() {
			System.out.println("init DemoBean");
		}
	
		@Override
		public String toString() {
			return "Hello World!";
		}
	}

测试:

	@Test
	public void testLazy() {
		/*
		 * 懒惰方式测试
		 */
		System.out.println("OK"); 
		DemoBean bean=ctx.getBean(
				"demoBean", DemoBean.class);
		System.out.println(bean); 
	}

## 多个实例

Spring默认情况下组件是单例的, 利用注解@Scope设为prototype时则创建多个实例. 

案例

	@Component
	@Scope("prototype") //创建多个实例
	public class ExampleBean {
		
		@Override
		public String toString() {
			return "ExampleBean";
		}
	}

测试:

	@Test
	public void testExampleBean() {
		/*
		 * @Scope("prototype") //创建多个实例
		 */
		ExampleBean bean1=ctx.getBean(
			"exampleBean", ExampleBean.class);
		ExampleBean bean2=ctx.getBean(
			"exampleBean", ExampleBean.class);
		System.out.println(bean1==bean2); 
	}

## 自定义组件ID

案例:

	@Component("myBean") //自定义组件ID
	public class TestBean {
		@Override
		public String toString() {
			return "TestBean";
		}
	}

测试:

	@Test
	public void testMyBean() {
		/*
		 * @Component("myBean") //自定义组件ID
		 */
		TestBean bean=ctx.getBean(
				"myBean", TestBean.class);
		System.out.println(bean); 
	}

## 生周期管理

需要使用 javax 注解

	<dependency>
		<groupId>javax.annotation</groupId>
		<artifactId>javax.annotation-api</artifactId>
		<version>1.3.2</version>
	</dependency>

案例:
	
	@Component
	public class LifeDemo {
		@PostConstruct//在构造(Construct)以后执行
		public void open() {
			System.out.println("open()");
		}
		public String toString() {
			return "LifeDemo";
		}
		@PreDestroy//Destroy销毁, 销毁对象之前执行
		public void close() {
			System.out.println("我还会回来的!");
		}
	}

测试:

	@Test
	public void testLifeDemo() {
		/*
		 * 测试对象生命周期管理功能
		 */
		LifeDemo bean=ctx.getBean(
				"lifeDemo", LifeDemo.class);
		System.out.println(bean); 
	}

## DI

Spring 提供了自动注入注解

首先按照类型自动注入, 如果有多个类型相同的, 再按照ID和名称进行匹配

原理:

![](1.png)

案例

1. 创建Bean组件

		public interface Tool {
		
		}
		
		@Component
		public class Axe implements Tool,Serializable {
			private String name = "斧子"; 
			
			@Override
			public String toString() {
				return name;
			}
		}

		@Component("tool")
		public class Saw implements Tool,Serializable{
			private String name="电锯";
			
			@Override
			public String toString() {
				return name;
			}
		}

		@Component
		public class Worker implements Serializable{
			private String name="光头强"; 
			
			private Tool tool;
			
			@Autowired
			public void setTool(Tool tool) {
				this.tool = tool;
				System.out.println("setTool");
			}
			
			public void work() {
				System.out.println(
					name+"使用"+tool+"砍树"); 
			}
		}

2. 测试:

		@Test
		public void testWorker() {
			/*
			 * 测试自动注入功能
			 */
			Worker worker = ctx.getBean(
					"worker", Worker.class);
			worker.work();
		}

## XML 文件中的Bean可以与@Autowired一起工作

XML配置文件和注解都是在同一个Spring容器中工作, 可以相互注入.

案例:

1. xml中声明Bean组件

		<!-- 配置DBCP连接池对象 -->
		<bean id="ds" 
			class="org.apache.commons.dbcp.BasicDataSource"
			destroy-method="close">
			<property name="driverClassName" 
				value="#{jdbc.driver}"/>
			<property name="url" 
				value="#{jdbc.url}"/>
			<property name="username"
				value="#{jdbc.username}"/>
			<property name="password"
				value="#{jdbc.password}"/>
			<property name="initialSize" 
				value="#{jdbc.initialSize}"/>
			<property name="maxActive"
				value="#{jdbc.maxActive}"/> 
		</bean>
		
		<!-- Spring 读取Properties -->
		<util:properties  
			id="jdbc" 
			location="classpath:jdbc.properties"/>	

2. 配置 jdbc.properties

		url=jdbc:mysql://localhost:3306/smartblogs?useUnicode=true&characterEncoding=UTF-8
		username=root
		password=root
		driver=com.mysql.jdbc.Driver
		initialSize=3
		maxActive=5

3. 编写Bean  注入DataSource

		@Component
		public class DbDemo {
			
			@Autowired
			private DataSource dataSource;
			
			public void test() {
				try(Connection conn=dataSource.getConnection()){
					String sql = "select 'Hello World!' as s";
					Statement st=conn.createStatement();
					ResultSet rs=st.executeQuery(sql);
					while(rs.next()) {
						System.out.println(rs.getString("s"));
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
			
		}

4. 测试

		@Test
		public void TestDbDemo() {
			/*
			 * XML 文件和注解可以和谐工作
			 */
			DbDemo demo=ctx.getBean("dbDemo",
					DbDemo.class);
			demo.test();
		}

# Spring MVC

## Spring MVC 

Spring 提供的Web编程框架, 是Web程序的半成品, 相对于Servlet开发Web程序简化很多倍!

## 搭建 Spring MVC

1. 导入Spring MVC
	
		<properties>
			<maven.compiler.target>1.8</maven.compiler.target>
			<maven.compiler.source>1.8</maven.compiler.source>
		</properties>
		<dependencies>
			<dependency>
				<groupId>org.springframework</groupId>
				<artifactId>spring-webmvc</artifactId>
				<version>4.3.24.RELEASE</version>
			</dependency>
			<dependency>
				<groupId>junit</groupId>
				<artifactId>junit</artifactId>
				<version>4.12</version>
			</dependency>
		</dependencies>

2. 配置web.xml

		<servlet>
			<servlet-name>DispatcherServlet</servlet-name>
			<servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
			<init-param>
				<param-name>contextConfigLocation</param-name>
				<param-value>classpath:beans.xml</param-value>
			</init-param>
			<load-on-startup>1</load-on-startup>
		</servlet>
		<servlet-mapping>
			<servlet-name>DispatcherServlet</servlet-name>
			<url-pattern>*.do</url-pattern>
		</servlet-mapping>

	> 注意需要配置 load-on-startup 属性, 表示在Web服务器启动时候立即创建DispatcherServlet的实例.

3. 在resources文件夹添加 beans.xml

		<?xml version="1.0" encoding="UTF-8"?>
		<beans xmlns="http://www.springframework.org/schema/beans" 
			xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
			xmlns:context="http://www.springframework.org/schema/context" 
			xmlns:jdbc="http://www.springframework.org/schema/jdbc"  
			xmlns:jee="http://www.springframework.org/schema/jee" 
			xmlns:tx="http://www.springframework.org/schema/tx"
			xmlns:aop="http://www.springframework.org/schema/aop" 
			xmlns:mvc="http://www.springframework.org/schema/mvc"
			xmlns:util="http://www.springframework.org/schema/util"
			xmlns:jpa="http://www.springframework.org/schema/data/jpa"
			xsi:schemaLocation="
				http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.2.xsd
				http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-3.2.xsd
				http://www.springframework.org/schema/jdbc http://www.springframework.org/schema/jdbc/spring-jdbc-3.2.xsd
				http://www.springframework.org/schema/jee http://www.springframework.org/schema/jee/spring-jee-3.2.xsd
				http://www.springframework.org/schema/tx http://www.springframework.org/schema/tx/spring-tx-3.2.xsd
				http://www.springframework.org/schema/data/jpa http://www.springframework.org/schema/data/jpa/spring-jpa-1.3.xsd
				http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop-3.2.xsd
				http://www.springframework.org/schema/mvc http://www.springframework.org/schema/mvc/spring-mvc-3.2.xsd
				http://www.springframework.org/schema/util http://www.springframework.org/schema/util/spring-util-3.2.xsd">
		
				
		</beans>

4. 部署测试: 服务器控制台出现如下信息则表示成功!
	
		FrameworkServlet 'DispatcherServlet': initialization completed in 257 ms

## HelloWorld

![](helloworld.png)

1. 修改配置文件 beans.xml

		<context:component-scan 
			base-package="cn.tedu.web"/>
		
		<mvc:annotation-driven/>	
		
2. 添加控制器

		@Controller
		public class DemoController {
			
			@RequestMapping("/hello.do")
			@ResponseBody
			public String hello() {
				System.out.println("Hello World!");
				return "OK";
			}
		}

3. 部署测试:

		http://localhost:8080/springmvc1/hello.do

## 什么是MVC

MVC是经典GUI用户界面设计模式. 几乎所有的GUI都采用了MVC模式.

Web界面开发时也普遍采用了MVC模式. 

SpringMVC 是Spring按照MVC模式设计的一套WEB用户界面框架! SpringMVC是半成品, 可以快速的开发Web用户界面. 

- M Model 模型, 业务模型, 封装软件的业务功能
- V Viwe 视图, 就是用户看到的界面
- C Controller 控制器, 处理用户的请求, 将请求发送到模型, 再根据模型反馈 的结果, 选择适当视图显示.


![](mvc.png)

## 接收表单参数

SpringMVC提供自动化的表单参数处理功能

![](param.png)

1. 编写表单 login.html

		<!DOCTYPE html>
		<html>
		<head>
		<meta charset="UTF-8">
		<title>Insert title here</title>
		</head>
		<body>
		  <h1>登录</h1>
		  <form action="login.do" method="post">
		    <div>
		      <label>用户</label>
		      <input type="text" name="username"> 
		    </div>
		    <div>
		      <label>密码</label>
		      <input type="password" name="password">
		    </div>
		    <input type="submit" value="登录"> 
		  </form>
		</body>
		</html>

2. 编写控制器

		@RequestMapping("/login.do")
		@ResponseBody
		public String login(
				String username,
				String password) {
			System.out.println(username);
			System.out.println(password);
			if("Tom".equals(username) &&
				"123".equals(password)) {
				return "OK";
			}else {
				return "HeHe";
			}
		}

3. 测试:

		http://localhost:8080/springmvc1/login.html






