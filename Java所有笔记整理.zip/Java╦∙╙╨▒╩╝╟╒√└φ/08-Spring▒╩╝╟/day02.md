# Spring

## Spring IOC

## 对象生命周期管理方法

- 可以在对象的创建以后自动执行其初始化方法,用于初始化资源
- 可以在对象销毁之前自动执行其销毁方法, 用于回收资源

注意: 单例时候Spring容器或调用销毁方法, 但是多个实例时候, Spring不会管理销毁方法. 也就是设置 scope="prototype" 则 destroy-method="close" 失效

利用Spring调用对象的生命周期管理方法

1. 创建需要管理生命周期的JavaBean

		public class Logger {
			private PrintWriter out;
			public void open() throws IOException {
				out = new PrintWriter("log.txt");
				System.out.println("打开文件");
			}	
			public void log(String msg) {
				out.println(new Date()+":"+msg);
				out.flush();
			}
			public void close() {
				out.close();
				System.out.println("关闭文件");
			}
		}

2. 配置 Spring applicationContext.xml

		<!-- 利用Spring调用对象的生命周期管理方法 -->
		<bean id="logger" class="day02.Logger"
		      init-method="open" 
		      lazy-init="true"
		      destroy-method="close"/> 

3. 测试:

		@Test
		public void testInitDestroy() {
			/*
			 * 测试对象生命周期管理方法
			 */
			Logger logger=ctx.getBean("logger",
					Logger.class);
			logger.log("今天天气不错");
			logger.log("山中无老虎");
		}

## DI 依赖注入

IOC/DI 控制反转/依赖注入

依赖: 软件功能执行期间使用了另外一个对象, 称为依赖另外一个对象

依赖注入: 是指在使用组件之前, 将被依赖的组件赋值到目标位置

Spring 提供了依赖注入功能

包含依赖注入关系类:

![](1.png)

案例:

1. 编写斧子类

		public class Axe implements Serializable{
			private String name="开天斧";
			
			@Override
			public String toString() {
				return name;
			}
		}

2. 编写工人类

		public class Worker implements Serializable {
			private String name = "光头强";
			private Axe axe;//拥有axe
			public void setAxe(Axe axe) {
				System.out.println("注入axe对象");
				this.axe = axe;
			}
			public void work() {
				//work()方法依赖axe对象
				System.out.println(
						name+"使用"+axe+"砍树");
			}
		}

3. 配置

		<!-- 依赖注入DI -->
		<bean id="a1" class="day02.Axe"></bean>
		<bean id="qiang" class="day02.Worker">
			<!-- 注入属性 name="axe" 则自动查找
			setAxe方法-->
			<property name="axe" ref="a1"></property>
		</bean>

4. 测试:

		@Test
		public void testQiang() {
			/*
			 * 测试依赖注入
			 */
			Worker qiang=ctx.getBean(
					"qiang", Worker.class);
			//如果axe属性不为null,则注入成功
			qiang.work();
			/*
			 * 测试懒惰初始化 
			 */
			Logger logger = ctx.getBean(
					"logger", Logger.class);
			logger.log("OK");
		}

## 利用Spring和接口实现解耦

解耦: 将紧耦合调整为松耦合

![](2.png)

案例:

1. 编写接口

		public interface Tool {
		
		}

2. 编写斧子

		public class Axe 
			implements Tool, Serializable{
			
			private String name = "斧头";
			
			public String toString() {
				return name;
			}
		}

3. 编写锯

		public class Saw 
			implements Tool, Serializable{
			
			private String name = "电锯";
			@Override
			public String toString() {
				return name;
			}
		}

4. 编写工人, 工人依赖于工具接口
		
		public class Worker implements Serializable {
			private String name="光头强";
			private Tool tool;
			public void setTool(Tool tool) {
				this.tool = tool;
			}
			public void setName(String name) {
				this.name = name;
			}
			public void work() {
				System.out.println(
					name+"使用"+tool+"砍树");
			}
		}

5. 配置

		<!-- 解耦: Spring和接口配合, 实现组件之间
		解耦, 也就是紧耦合转换为松耦合关系 -->
		<bean id="ax" class="day02.demo.Axe"/>
		<bean id="sw" class="day02.demo.Saw"/>
		<bean id="worker" class="day02.demo.Worker">
			<!-- property 可以注入Bean对象 -->
			<property name="tool" ref="ax"/>
			<!-- property 可以注入基本值 -->
			<property name="name" value="强哥"/>
		</bean>

6. 测试:

		@Test
		public void testWorker() {
			/*
			 * 测试解耦
			 */
			day02.demo.Worker worker =
					ctx.getBean("worker",
					day02.demo.Worker.class);
			worker.work();
		}

## 立即初始化和懒惰初始化

Spring中单例对象默认时候采用立即初始化, 也就是在Spring启动时候立即初始化全部单例对象, 如果有初始化方法就立即执行初始化方法.

懒惰初始化: Spring启动时候不会立即创建对象, 在使用对象时候才创建对象. lazy-init="true"

配置:

	<!-- 利用Spring调用对象的生命周期管理方法 -->
	<bean id="logger" class="day02.Logger"
	      init-method="open" 
	      lazy-init="true"
	      destroy-method="close"/>

## 案例: 利用Spring IOC/DI功能管理 DBCP 连接池

1. 导入DBCP和MySQL驱动
2. 配置Spring文件, 管理DBCP连接池
3. 从Spring得到DBCP连接池对象
4. 编写测试案例, 连接到数据库执行SQL

Spring可以读取Properties
利用Spring表达式将Properties属性注入到Bean

1. 导入DBCP和MySQL驱动

		<dependency>
			<groupId>mysql</groupId>
			<artifactId>mysql-connector-java</artifactId>
			<version>5.1.6</version>
		</dependency>
		<!-- 数据库连接池坐标 -->
		<dependency>
			<groupId>commons-dbcp</groupId>
			<artifactId>commons-dbcp</artifactId>
			<version>1.4</version>
		</dependency>		

2. 设置 JDK 版本

	    <properties>
	        <maven.compiler.target>1.8</maven.compiler.target>
	        <maven.compiler.source>1.8</maven.compiler.source>
	    </properties>  

3. 添加 jdbc.propertis

		url=jdbc:mysql://localhost:3306/smartblogs?useUnicode=true&characterEncoding=UTF-8
		username=root
		password=root
		driver=com.mysql.jdbc.Driver
		initialSize=3
		maxActive=5

4. 配置读取jdbc.properties

		<!-- Spring 读取Properties -->
		<util:properties  
			id="jdbc" 
			location="classpath:jdbc.properties"/>	

5. 测试 jdbc.properties

		@Test
		public void testJdbc() {
			/*
			 * 测试Spring读取jdbc.properties
			 */
			Properties jdbc=ctx.getBean("jdbc",
					Properties.class);
			System.out.println(jdbc); 
		}

6. 配置 DBCP
	
		<!-- 配置DBCP连接池对象 -->
		<bean id="ds" 
			class="org.apache.commons.dbcp.BasicDataSource"
			destroy-method="close">
			<property name="driverClassName" 
				value="#{jdbc.driver}"/>
			<property name="url" 
				value="#{jdbc.url}"/>
			<property name="username"
				value="#{jdbc.username}"/>
			<property name="password"
				value="#{jdbc.password}"/>
			<property name="initialSize" 
				value="#{jdbc.initialSize}"/>
			<property name="maxActive"
				value="#{jdbc.maxActive}"/> 
		</bean>
	
	> 利用 Spring 表达式 读取 jdbc.properties 中的数据

7. 测试:
	
		@Test
		public void testDS() {
			/*
			 * 测试数据库连接池
			 */
			// BasicDataSource的父类型是 
			// java.sql.DataSource, 所以DataSource
			// 定义的变量可以引用BasicDataSource
			// 类型的实例.
			DataSource ds = ctx.getBean("ds",
					DataSource.class);
			try(Connection conn=ds.getConnection()){
				String sql = 
					"select 'Hello World' as s ";
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery(sql);
				while(rs.next()) {
					String s=rs.getString("s");
					System.out.println(s); 
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}

## 自动注入功能

