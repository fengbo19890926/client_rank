### 1. 使用<resultMap>配置1对多的查询

需求：根据id查询部门信息，并且，同时查出该部门的员工信息。

分析：需要执行的SQL语句大致是：

	SELECT
		*
	FROM
		t_department
	LEFT JOIN
		t_user
	ON
		t_department.id=t_user.department_id
	WHERE
		t_department.id=?

在开发功能时，必须先创建VO类，用于封装此次的查询结果：

	public class DepartmentVO {
		private Integer id;
		private String name;
		private List<User> users;
	}

然后在`DepartmentMapper`接口中添加抽象方法：

	DepartmentVO findVOById(Integer id);

接下来，在**DepartmentMapper.xml**中配置以上抽象方法的映射：

	<select id="findVOById" 
		resultType="cn.tedu.mybatis.DepartmentVO">
		SELECT
			t_department.id AS did, name,
			t_user.*
		FROM
			t_department
		LEFT JOIN
			t_user
		ON
			t_department.id=t_user.department_id
		WHERE
			t_department.id=#{id}
	</select>

目前，MyBatis框架并不知道如何将找到的若干条结果正确的封装到返回的`DepartmentVO`对象中！所以，需要配置`<resultMap>`！配置代码如下：

	<resultMap id="DepartmentVOMap"
		type="cn.tedu.mybatis.DepartmentVO">
		<id column="did" property="id" />
		<result column="name" property="name" />
		<!-- collection节点：用于配置1对多的查询结果 -->
		<!-- property属性：类中的哪个属性用于封装多个结果中的数据 -->
		<!-- ofType属性：集合属性中的元素的类型，即：这个List集合中放的是什么类型的数据 -->
		<collection property="users"
			ofType="cn.tedu.mybatis.User">
			<id column="id" property="id" />
			<result column="username" property="username" />
			<result column="password" property="password" />
			<result column="age" property="age" />
			<result column="phone" property="phone" />
			<result column="email" property="email" />
			<result column="department_id" property="departmentId" />
		</collection>
	</resultMap>

**注意：此次涉及多表查询，即使名称对应(查询结果的列名与期望封装到的对象的属性名是相同的)，也必须显式的配置！**

则对应的查询节点就应该使用`resultMap`属性来配置，并且，在查询时，为了避免出现2个`id`列，会导致无法正确的封装查询结果，所以，需要为至少其中1列定义别名：

	<select id="findVOById" resultMap="DepartmentVOMap">
		SELECT
			t_department.id AS did, name,
			t_user.*
		FROM
			t_department
		LEFT JOIN
			t_user
		ON
			t_department.id=t_user.department_id
		WHERE
			t_department.id=#{id}
	</select>

### 2. 关于自定义别名和使用<resultMap>

在单表查询时，如果查询结果中的列名与封装结果的属性名不一致时，可以自定义别名；在多表联合查询时，如果查询结果中有多个相同的列名，为了保证正确的配置并封装查询结果数据，也应该自定义别名，使得查询结果的每个列名都不相同！

在单表查询时，如果查询结果中的列名与封装结果的属性名不一致时，可以使用`<resultMap>`进行配置；在多表联合查询时，如果出现1对多的关系，则必须配置`<resultMap>`！

综上所述，如果是单表查询，且存在名称不匹配的问题，使用自定义别名，或配置`<resultMap>`，都可以解决问题！如果多表联合查询，查询结果中有相同的列名，必须自定义别名，使得列名不同！如果多表联合查询，存在1对多关系，必须配置`<resultMap>`！

